"""Extração do áudio de trabalho (cópia em 16 kHz mono). O original não é tocado."""
import shutil
import subprocess
from pathlib import Path

import soundfile as sf

from .config import TAXA_AMOSTRAGEM


def ffmpeg():
    try:
        import imageio_ffmpeg

        return imageio_ffmpeg.get_ffmpeg_exe()
    except Exception:
        caminho = shutil.which("ffmpeg")
        if not caminho:
            raise RuntimeError("ffmpeg não encontrado. Instale com: pip install imageio-ffmpeg")
        return caminho


def extrair_audio(origem, destino):
    """Converte áudio ou vídeo em WAV 16 kHz mono, sem filtros de melhoria."""
    destino = Path(destino)
    destino.parent.mkdir(parents=True, exist_ok=True)
    cmd = [ffmpeg(), "-nostdin", "-hide_banner", "-loglevel", "error", "-y",
           "-i", str(origem), "-vn", "-ac", "1", "-ar", str(TAXA_AMOSTRAGEM),
           "-c:a", "pcm_s16le", str(destino)]
    resultado = subprocess.run(cmd, capture_output=True, text=True)
    if resultado.returncode != 0:
        raise RuntimeError(f"Não foi possível ler o áudio do arquivo: {resultado.stderr.strip()}")
    return destino


def duracao(caminho_wav):
    return sf.info(str(caminho_wav)).duration


def carregar(caminho_wav):
    audio, _ = sf.read(str(caminho_wav), dtype="float32")
    return audio


def extrair_audio_revisao(origem, destino):
    """Cópia para ouvir na revisão: WAV na taxa e nos canais originais (sem perder
    qualidade para o ouvido), sem filtros. Começa no mesmo instante do áudio dos motores."""
    destino = Path(destino)
    cmd = [ffmpeg(), "-nostdin", "-hide_banner", "-loglevel", "error", "-y",
           "-i", str(origem), "-vn", "-c:a", "pcm_s16le", str(destino)]
    resultado = subprocess.run(cmd, capture_output=True, text=True)
    if resultado.returncode != 0:
        raise RuntimeError(f"Não foi possível ler o áudio do arquivo: {resultado.stderr.strip()}")
    return destino


# Item 6: melhoria opcional, só com filtros do ffmpeg (redução de ruído por FFT, corte de
# graves e normalização de volume). Sempre gera uma CÓPIA; o original nunca é tocado.
MELHORIAS = {
    "leve": {"descricao": "redução de ruído leve e normalização de volume",
             "filtro": "highpass=f=80,afftdn=nr=10:nf=-25,loudnorm=I=-18:TP=-2"},
    "medio": {"descricao": "redução de ruído média e normalização de volume",
              "filtro": "highpass=f=100,afftdn=nr=20:nf=-30,loudnorm=I=-18:TP=-2"},
    "forte": {"descricao": "redução de ruído forte e normalização de volume",
              "filtro": "highpass=f=120,afftdn=nr=33:nf=-35:tn=1,loudnorm=I=-18:TP=-2"},
}


def melhorar(origem, destino, nivel, inicio=None, fim=None, taxa=48000):
    """Cópia melhorada de `origem` (inteira ou só de `inicio` a `fim`, em segundos).

    `taxa` é obrigatória porque o loudnorm devolve 192 kHz se ninguém fixar outra:
    48000 (canais originais) para ouvir; TAXA_AMOSTRAGEM (mono) para os motores.
    """
    if nivel not in MELHORIAS:
        raise ValueError(f"Nível de melhoria desconhecido: {nivel}")
    destino = Path(destino)
    cmd = [ffmpeg(), "-nostdin", "-hide_banner", "-loglevel", "error", "-y"]
    if inicio is not None:
        cmd += ["-ss", f"{max(0.0, inicio):.3f}"]
    if fim is not None:
        cmd += ["-to", f"{fim:.3f}"]
    cmd += ["-i", str(origem), "-vn", "-af", MELHORIAS[nivel]["filtro"]]
    cmd += ["-ar", str(taxa)]
    if taxa == TAXA_AMOSTRAGEM:
        cmd += ["-ac", "1"]
    cmd += ["-c:a", "pcm_s16le", str(destino)]
    resultado = subprocess.run(cmd, capture_output=True, text=True)
    if resultado.returncode != 0:
        raise RuntimeError(f"Não foi possível melhorar o áudio: {resultado.stderr.strip()}")
    return destino


def recortar(origem, destino, inicio, fim):
    """Cópia de um trecho do áudio de trabalho (16 kHz mono), sem filtros."""
    cmd = [ffmpeg(), "-nostdin", "-hide_banner", "-loglevel", "error", "-y", "-ss", f"{max(0.0, inicio):.3f}",
           "-to", f"{fim:.3f}", "-i", str(origem), "-ac", "1", "-ar", str(TAXA_AMOSTRAGEM),
           "-c:a", "pcm_s16le", str(destino)]
    resultado = subprocess.run(cmd, capture_output=True, text=True)
    if resultado.returncode != 0:
        raise RuntimeError(f"Não foi possível recortar o áudio: {resultado.stderr.strip()}")
    return destino
