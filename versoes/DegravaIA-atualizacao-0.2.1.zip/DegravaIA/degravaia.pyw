"""DegravaIA em janela própria do Windows (o atalho da Área de Trabalho abre este arquivo).

Mesmo modelo do RealceIA:
    atalho "DegravaIA" ─► python\\pythonw.exe degravaia.pyw   (pythonw: sem a janela preta)
        1. abre a janela (pywebview → WebView2, o componente do Edge que vem no Windows 10 e 11)
           mostrando "Abrindo o DegravaIA…";
        2. sobe o servidor do app em segundo plano, só neste computador (127.0.0.1);
        3. quando ele fica pronto, a janela carrega a tela;
        4. fechou a janela → encerra o servidor e o programa.

As mensagens vão para registro.txt. Se o servidor cair, ele é aberto de novo sozinho (e a
tela se reconecta); depois de uma atualização, abre a versão nova.
Sem o pywebview ou sem o WebView2, ou com --navegador, abre como antes: janela preta e
navegador (abrir.py).
"""
import os
import subprocess
import sys
import threading
import time
from pathlib import Path
from urllib.request import urlopen

sys.path.insert(0, str(Path(__file__).resolve().parent))
from abrir import GRUPO_PROPRIO, REINICIAR, abrir_registro, anotar  # noqa: E402
from instalar import AQUI, ambiente_nvidia, python_do_app  # noqa: E402

PORTA = 8765
ENDERECO = f"http://127.0.0.1:{PORTA}/"
SEM_CONSOLE = 0x08000000 if os.name == "nt" else 0  # CREATE_NO_WINDOW: o servidor não abre janela preta
DADOS_JANELA = AQUI / "dados-janela"  # tema, guia fechado… (o que a página guarda no navegador)

ESTILO = """<style>html,body{height:100%;margin:0;background:#0c1716;color:#e6f0ee;
font-family:"Segoe UI",system-ui,sans-serif}body{display:grid;place-items:center}
.caixa{text-align:center;max-width:560px;padding:24px}.logo{width:64px;height:64px;border-radius:16px;
background:#3fd0b8;margin:0 auto 18px}.giro{width:28px;height:28px;margin:18px auto 0;border-radius:50%;
border:3px solid #23403b;border-top-color:#3fd0b8;animation:g 1s linear infinite}
@keyframes g{to{transform:rotate(360deg)}}p{color:#9ab0ab;line-height:1.5}code{color:#3fd0b8}</style>"""
CARREGANDO = f"""<!doctype html><meta charset="utf-8">{ESTILO}<div class="caixa"><div class="logo"></div>
<h2>Abrindo o DegravaIA…</h2><p>Tudo roda no seu computador. Nenhum dado é enviado para a internet.</p>
<div class="giro"></div></div>"""


def pagina_de_erro(texto):
    return f"""<!doctype html><meta charset="utf-8">{ESTILO}<div class="caixa"><div class="logo"></div>
<h2>Não foi possível abrir o DegravaIA</h2><p>{texto}</p>
<p>O detalhe está no arquivo <code>registro.txt</code>, na pasta do DegravaIA:<br><code>{AQUI}</code></p>
<p>Feche esta janela e tente de novo. Se continuar, envie o registro.txt para o suporte.</p></div>"""


def no_ar():
    try:
        with urlopen(ENDERECO + "api/projetos", timeout=1) as r:
            return r.status == 200
    except Exception:
        return False


class Servidor:
    """Roda `python -m degravaia revisar` sem janela, grava a saída no registro e o reabre se
    cair ou se uma atualização pedir (mesma lógica do abrir.py)."""

    def __init__(self, registro):
        self.registro = registro
        self.proc = None
        self.fechando = False
        self.desistiu = False

    def iniciar(self):
        threading.Thread(target=self._vigiar, daemon=True).start()

    def _rodar(self):
        self.proc = subprocess.Popen(
            [str(python_do_app()), "-u", "-m", "degravaia", "revisar", "--nao-abrir", "--porta", str(PORTA)],
            env=ambiente_nvidia(), cwd=AQUI, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True,
            encoding="utf-8", errors="replace", creationflags=GRUPO_PROPRIO | SEM_CONSOLE)
        for linha in self.proc.stdout:
            self.registro.write(f"{time.strftime('%Y-%m-%d %H:%M:%S')} {linha}")
            self.registro.flush()
        return self.proc.wait()

    def _vigiar(self):
        quedas = []
        while not self.fechando:
            codigo = self._rodar()
            if self.fechando:
                return
            if codigo == REINICIAR:
                anotar(self.registro, "Abrindo a versão nova…")
                continue
            quedas = [t for t in quedas if time.time() - t < 600] + [time.time()]
            anotar(self.registro, f"O programa da tela parou (código {codigo}).")
            if len(quedas) > 5:
                anotar(self.registro, "Parou várias vezes seguidas; desistindo.")
                self.desistiu = True
                return
            time.sleep(2)

    def parar(self):
        self.fechando = True
        if self.proc and self.proc.poll() is None:
            if os.name == "nt":  # a árvore toda: inclusive uma importação em andamento (processo filho)
                subprocess.run(["taskkill", "/T", "/F", "/PID", str(self.proc.pid)], capture_output=True,
                               creationflags=SEM_CONSOLE)
            else:
                self.proc.terminate()
            try:
                self.proc.wait(timeout=5)
            except subprocess.TimeoutExpired:
                self.proc.kill()


def modo_navegador():
    """Como antes: janela preta + navegador padrão (abrir.py)."""
    novo_console = subprocess.CREATE_NEW_CONSOLE if os.name == "nt" else 0
    subprocess.Popen([str(python_do_app()), str(AQUI / "abrir.py"), "--navegador"], cwd=AQUI,
                     creationflags=novo_console)


def principal():
    os.chdir(AQUI)
    if "--navegador" in sys.argv:
        return modo_navegador()
    try:
        import webview
    except ImportError:
        return modo_navegador()

    registro = abrir_registro()
    anotar(registro, "=== DegravaIA aberto (janela própria)")
    servidor = None
    if not no_ar():  # se já houver um DegravaIA aberto, esta janela usa o mesmo servidor
        servidor = Servidor(registro)
        servidor.iniciar()

    webview.settings["ALLOW_DOWNLOADS"] = True  # documentos exportados
    webview.settings["OPEN_EXTERNAL_LINKS_IN_BROWSER"] = True  # "Doar pelo Mercado Pago" abre no navegador
    icone = AQUI / "degravaia" / "web" / "degravaia.ico"
    janela = webview.create_window("DegravaIA", html=CARREGANDO, width=1400, height=900, min_size=(1000, 680),
                                   background_color="#0c1716")

    def por_icone():  # no Windows, o ícone da janela e da barra de tarefas (o parâmetro icon é só do Linux)
        try:
            from System import Action
            from System.Drawing import Icon

            formulario = janela.native
            formulario.Invoke(Action(lambda: setattr(formulario, "Icon", Icon(str(icone)))))
        except Exception:
            pass

    janela.events.shown += por_icone

    def esperar_servidor():
        limite = time.time() + 180
        while time.time() < limite:
            if no_ar():
                janela.load_url(ENDERECO)
                return
            if servidor and servidor.desistiu:
                break
            time.sleep(0.5)
        anotar(registro, "A tela não ficou pronta.")
        janela.load_html(pagina_de_erro("O programa da tela não respondeu."))

    try:
        DADOS_JANELA.mkdir(exist_ok=True)
        webview.start(esperar_servidor, gui="edgechromium" if os.name == "nt" else None, private_mode=False,
                      storage_path=str(DADOS_JANELA), icon=str(icone))
    except Exception as erro:  # sem WebView2 (raro no Windows 10/11): cai para o navegador
        anotar(registro, f"Janela própria indisponível ({erro}); abrindo no navegador.")
        if servidor:
            servidor.parar()
        registro.close()
        return modo_navegador()
    anotar(registro, "Janela fechada.")
    if servidor:
        servidor.parar()
    registro.close()


if __name__ == "__main__":
    principal()
