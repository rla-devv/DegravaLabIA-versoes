# Como publicar uma versão nova (atualização automática)

Ao abrir, o Degrava IA consulta o arquivo `atualizacao.json` do repositório
**público** `rla-devv/degravaia-versoes` (definido em `REPO_VERSOES`, no
`degravaia/config.py`). Se houver uma versão mais nova, mostra um aviso na
página inicial e só instala quando o usuário clica em **Atualizar agora**.

- **Bloqueio:** a atualização é recusada enquanto houver um projeto aberto em
  qualquer aba ou um processamento em andamento.
- **O que é trocado:** só o código do app. As pastas `python/`, `modelos/` e
  `projetos/` nunca são tocadas.
- **Versão anterior:** os arquivos que mudam ficam guardados em
  `versoes-anteriores/<versão>/`. Para voltar, rode
  `python\python.exe -m degravaia restaurar-versao`.

## Por que um repositório separado
O app de cada usuário precisa baixar a versão sem senha. Um repositório
privado, mesmo num plano pago do GitHub, sempre exige senha para baixar.
Por isso:
- o código fica privado em `rla-devv/degravaia`;
- só os pacotes prontos vão para `rla-devv/degravaia-versoes`, que é público e
  não tem código-fonte.

## A cada versão
1. Aumente `VERSAO` em `degravaia/config.py` (ex.: `0.1.5` → `0.1.6`) e faça o
   commit e o push do código.
2. Com o repositório de versões clonado ao lado (`../degravaia-versoes`), rode:

   ```
   python publicar.py --novidades "O que mudou, em palavras do usuário."
   ```

   Ele:
   - gera os pacotes;
   - copia o pacote de código para `versoes/` e o `atualizacao.json` para a
     raiz do repositório de versões;
   - faz o commit e o push.

   Em poucos minutos os Degrava IA abertos mostram o aviso.
3. O pacote completo para instalações novas (`downloads/DegravaIA.zip`, cerca
   de 43 MB) não vai para o repositório. Ele é entregue à parte.

O `publicar.py` recusa publicar se houver alterações sem commit no código, ou
se a versão não for mais nova que a já publicada.

## Conferências feitas pelo app antes de instalar
- **SHA-256:** o do pacote baixado tem de ser igual ao do `atualizacao.json`.
- **Versão:** a que está dentro do pacote tem de ser a anunciada.
- **Caminhos:** o pacote só pode conter caminhos dentro da pasta do app e fora
  das pastas protegidas.
- **Bibliotecas:** se o `requirements.txt` mudou, as bibliotecas são
  atualizadas.
- **Falha:** se qualquer passo falhar, os arquivos anteriores voltam e nada
  muda.
