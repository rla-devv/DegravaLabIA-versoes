"""Degrava Lab IA — o "Instalar Degrava Lab IA.bat" da pasta roda isto (python -m degravaia.abrir).

    Instalar Degrava Lab IA.bat               instala na primeira vez; depois, abre o app
    Instalar Degrava Lab IA.bat instalar      roda a instalação de novo
    Instalar Degrava Lab IA.bat diagnostico   mostra o que o app encontrou (GPU, modelos…)
    Instalar Degrava Lab IA.bat --navegador   abre no navegador, com a janela preta

No Windows, com o pywebview instalado, abre em janela própria (degravaia\\janela.pyw). Os
atalhos são criados na instalação; ao abrir, o servidor só cria o "Abrir Degrava Lab IA" da pasta
do app, se faltar. Com --navegador, ou sem o pywebview, abre como abaixo, no navegador:

Funciona sem internet: liga o modo offline das bibliotecas (item 1 dos requisitos)
e põe no PATH as bibliotecas da NVIDIA para o Whisper usar a GPU. Mantenha esta
janela aberta enquanto usa; para encerrar, feche-a.

Tudo o que aparece aqui vai também para registro.txt (fica mesmo se a janela fechar).
Se o programa da tela cair, ele é aberto de novo sozinho.
"""
import os
import subprocess
import sys
import time
from datetime import datetime
from pathlib import Path

from degravaia.instalar import AQUI, JANELA, ambiente_modelos, ambiente_nvidia, instalar, python_do_app

REGISTRO = AQUI / "registro.txt"
PARA_ABRIR = ("Para abrir depois, use o atalho 'Abrir Degrava Lab IA' nesta pasta ou o atalho 'Degrava Lab IA' na\n"
              "Área de Trabalho e no Menu Iniciar.")
REINICIAR = 3  # o servidor pede para reabrir (atualização instalada; atualizacao.py)
# grupo de processos próprio: um sinal de "encerrar" vindo de outro processo da janela
# (ex.: a importação fechando depois de usar a GPU) não derruba o servidor
GRUPO_PROPRIO = subprocess.CREATE_NEW_PROCESS_GROUP if os.name == "nt" else 0


LIMITE_REGISTRO = 256 * 1024  # passou disso ao abrir: fica só o fim (o mesmo limite dos outros apps RLA.dev)
FIM_REGISTRO = 64 * 1024


def limitar_registro():
    """Passou de 256 KB: fica só o fim (64 KB, a partir de uma linha inteira). Erro aqui não impede de abrir
    (ex.: o arquivo aberto por outro Degrava Lab IA)."""
    try:
        REGISTRO.with_suffix(".anterior.txt").unlink(missing_ok=True)  # das versões que guardavam 2 MB + 2 MB
        if REGISTRO.exists() and REGISTRO.stat().st_size > LIMITE_REGISTRO:
            with open(REGISTRO, "rb") as f:
                f.seek(-FIM_REGISTRO, os.SEEK_END)
                fim = f.read()
            quebra = fim.find(b"\n")
            novo = REGISTRO.with_name(REGISTRO.name + ".novo")
            novo.write_bytes(fim[quebra + 1:] if quebra >= 0 else fim)
            os.replace(novo, REGISTRO)
    except OSError:
        pass


def abrir_registro():
    limitar_registro()
    return open(REGISTRO, "a", encoding="utf-8", errors="replace")


def anotar(registro, texto):
    print(texto, flush=True)
    registro.write(f"{datetime.now():%Y-%m-%d %H:%M:%S} {texto}\n")
    registro.flush()


def rodar_servidor(app, comando, registro):
    """Roda o servidor mostrando a saída aqui e gravando no registro; devolve o código de saída."""
    from degravaia.atualizacao import LANCADOR

    proc = subprocess.Popen([str(app), "-u", "-m", "degravaia", *comando],
                            env=dict(ambiente_nvidia(), DEGRAVAIA_LANCADOR=str(LANCADOR)),
                            stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, encoding="utf-8",
                            errors="replace", creationflags=GRUPO_PROPRIO)
    try:
        for linha in proc.stdout:
            print(linha, end="", flush=True)
            registro.write(f"{datetime.now():%Y-%m-%d %H:%M:%S} {linha}")
            registro.flush()
        return proc.wait()
    except KeyboardInterrupt:  # Ctrl+C nesta janela: encerra o servidor também
        proc.terminate()
        raise


def abrir_em_janela(app):
    """Abre a janela própria (degravaia\\janela.pyw, sem janela preta). False se não der."""
    if os.name != "nt":
        return False
    tem_janela = subprocess.run([str(app), "-c", "import webview"], capture_output=True).returncode == 0
    pythonw = app.with_name("pythonw.exe")
    if not tem_janela or not pythonw.exists():
        return False
    # os atalhos: o servidor, ao abrir, cria o da pasta se faltar (instalar.arrumar_pasta)
    subprocess.Popen([str(pythonw), str(JANELA)], cwd=AQUI,
                     creationflags=subprocess.DETACHED_PROCESS | subprocess.CREATE_NEW_PROCESS_GROUP)
    return True


CONFERIR = ("import sys, faster_whisper\n"
            "from degravaia.diagnostico import problemas_do_modelo, MODELO_WHISPER, MODELO_SEGUNDA_ESCUTA, MODELO_DIARIZACAO\n"
            "sys.exit(2 if any(problemas_do_modelo(m) for m in (MODELO_WHISPER, MODELO_SEGUNDA_ESCUTA, MODELO_DIARIZACAO)) else 0)")


def situacao(app):
    """"ok"; "sem_bibliotecas" (primeira vez); ou "modelos_incompletos" (um download da instalação
    não terminou: o "Instalar Degrava Lab IA.bat" baixa de novo só o que falta)."""
    if not app.exists():
        return "sem_bibliotecas"
    codigo = subprocess.run([str(app), "-c", CONFERIR], capture_output=True, cwd=AQUI, env=ambiente_modelos()).returncode
    return {0: "ok", 2: "modelos_incompletos"}.get(codigo, "sem_bibliotecas")


def instalado(app):
    return situacao(app) == "ok"


def esconder_lista():
    """A lista de arquivos do app fica na raiz (as atualizações antigas a procuram ali), mas
    escondida: na pasta, a pessoa vê só o "Instalar Degrava Lab IA.bat" e o LEIA-ME."""
    lista = AQUI / "arquivos-do-app.txt"
    if os.name == "nt" and lista.exists():
        try:
            import ctypes

            ctypes.windll.kernel32.SetFileAttributesW(str(lista), 0x2)  # FILE_ATTRIBUTE_HIDDEN
        except Exception:
            pass


def principal():
    os.chdir(AQUI)
    esconder_lista()
    navegador = "--navegador" in sys.argv
    comando = [a for a in sys.argv[1:] if a != "--navegador"] or ["revisar"]
    app = python_do_app()
    estado = "ok" if comando == ["instalar"] else situacao(app)
    if comando == ["instalar"] or estado != "ok":  # primeira vez (ou modelo pela metade): instala e já abre
        if estado == "modelos_incompletos":
            print("Faltam arquivos dos modelos (um download da instalação não terminou).")
            print("Baixando de novo só o que falta (precisa de internet).\n")
        elif comando != ["instalar"]:
            print("Primeira vez: o Degrava Lab IA vai ser instalado (precisa de internet só agora).\n")
        codigo = instalar()
        app = python_do_app()
        if codigo or comando == ["instalar"] or not instalado(app):
            if not codigo and instalado(app):
                print(f"\n{PARA_ABRIR}")
            input("\nTecle Enter para fechar esta janela.")
            return codigo or (0 if comando == ["instalar"] else 1)
        print(f"\nPronto! O Degrava Lab IA está abrindo. {PARA_ABRIR}")
        comando = ["revisar"]
        if not navegador and abrir_em_janela(app):
            time.sleep(6)  # tempo de ler a mensagem; depois esta tela preta fecha sozinha
            return 0
    if comando == ["revisar"] and not navegador and abrir_em_janela(app):
        return 0
    if comando != ["revisar"]:  # outros comandos (diagnóstico etc.): roda uma vez e mostra
        codigo = subprocess.run([str(app), "-m", "degravaia", *comando], env=ambiente_nvidia()).returncode
        input("\nTecle Enter para fechar.")
        return codigo
    quedas = []
    with abrir_registro() as registro:
        anotar(registro, "=== Degrava Lab IA aberto")
        from degravaia.atualizacao import PENDENTE, concluir_pendente

        def concluir():  # o que a atualização deixou para fazer com o servidor fechado (o pip)
            if PENDENTE.exists():
                concluir_pendente(lambda texto: anotar(registro, texto), AQUI,
                                  registrar=lambda texto: registro.write(texto) or registro.flush())

        try:
            concluir()  # ficou pela metade da última vez
            codigo = rodar_servidor(app, comando, registro)
            while True:
                if codigo == REINICIAR:
                    anotar(registro, "Aplicando a atualização…")
                    concluir()
                    anotar(registro, "Abrindo a versão nova…")
                elif codigo != 0:
                    quedas = [t for t in quedas if time.time() - t < 600] + [time.time()]
                    anotar(registro, f"O programa da tela parou (código {codigo}).")
                    if len(quedas) > 5:  # caindo em sequência: para e mostra
                        anotar(registro, "Parou várias vezes seguidas. Envie o arquivo registro.txt para o suporte.")
                        input("\nTecle Enter para fechar.")
                        return codigo
                    anotar(registro, "Abrindo de novo em 2 segundos… (a tela no navegador volta sozinha)")
                    time.sleep(2)
                else:
                    return 0
                codigo = rodar_servidor(app, ["revisar", "--nao-abrir"], registro)
        except KeyboardInterrupt:
            anotar(registro, "Encerrado nesta janela.")
            return 0


if __name__ == "__main__":
    sys.exit(principal())
