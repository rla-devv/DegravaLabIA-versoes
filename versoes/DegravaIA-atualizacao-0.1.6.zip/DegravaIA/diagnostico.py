"""DegravaIA — mostra o que o app encontrou (GPU, ffmpeg, modelos, fonte do PDF).
Dê dois cliques neste arquivo."""
import subprocess
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from instalar import ambiente_nvidia, python_do_app  # noqa: E402

if __name__ == "__main__":
    app = python_do_app()
    if not app.exists() or subprocess.run([str(app), "-c", "import faster_whisper"], capture_output=True).returncode:
        print("O DegravaIA ainda não foi instalado. Dê dois cliques em instalar.bat (ou instalar.py) primeiro.")
    else:
        subprocess.run([str(app), "-m", "degravaia", "diagnostico"], env=ambiente_nvidia(),
                       cwd=Path(__file__).resolve().parent)
    input("\nTecle Enter para fechar.")
