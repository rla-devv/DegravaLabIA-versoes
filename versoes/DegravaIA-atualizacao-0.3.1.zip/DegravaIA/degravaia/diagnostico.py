"""Instalação e conferência no PC do usuário.

    python -m degravaia baixar-modelos   baixa uma vez os modelos que faltam (sem token)
    python -m degravaia diagnostico      mostra o que o app encontrou: GPU, ffmpeg, modelos, fonte do PDF

Depois de baixados, os modelos ficam no computador e o app roda sem internet
(o "Degrava IA.bat" liga o modo offline das bibliotecas).
"""
import os
import platform
import shutil
import sys
from pathlib import Path

from .config import MODELO_DIARIZACAO, MODELO_SEGUNDA_ESCUTA, MODELO_WHISPER, NOME_APP, VERSAO


def _linha(rotulo, ok, detalhe=""):
    print(f"  [{'OK' if ok else '!!'}] {rotulo}{': ' + detalhe if detalhe else ''}")
    return ok


def diagnostico():
    print(f"{NOME_APP} {VERSAO} — diagnóstico")
    tudo = True
    tudo &= _linha("Python", sys.version_info >= (3, 10), f"{platform.python_version()} ({platform.system()})")

    try:
        import ctranslate2

        n = ctranslate2.get_cuda_device_count()
        tudo &= _linha("Whisper (ctranslate2)", True, f"GPU NVIDIA: {'sim, ' + str(n) if n else 'não, usa a CPU'}")
    except Exception as e:
        tudo &= _linha("Whisper (ctranslate2)", False, str(e))

    try:
        import torch

        if torch.cuda.is_available():
            p = torch.cuda.get_device_properties(0)
            det = f"GPU {p.name}, {p.total_memory / 2**30:.1f} GB"
        else:
            det = "sem GPU, usa a CPU"
        tudo &= _linha("wav2vec2 e pyannote (torch)", True, f"{torch.__version__}; {det}")
    except Exception as e:
        tudo &= _linha("wav2vec2 e pyannote (torch)", False, str(e))

    try:
        from .audio import ffmpeg

        tudo &= _linha("ffmpeg", True, ffmpeg())
    except Exception as e:
        tudo &= _linha("ffmpeg", False, str(e))

    try:
        from .exportacao import _fontes_pdf

        tudo &= _linha("Fonte do PDF", True, _fontes_pdf()[0])
    except Exception as e:
        tudo &= _linha("Fonte do PDF", False, str(e))

    for modelo in (MODELO_WHISPER, MODELO_SEGUNDA_ESCUTA, MODELO_DIARIZACAO):
        tudo &= _linha(f"Modelo {modelo}", _no_computador(modelo),
                       "no computador" if _no_computador(modelo) else 'falta baixar ("Degrava IA.bat" instalar)')

    offline = os.environ.get("HF_HUB_OFFLINE") == "1"
    _linha("Modo offline das bibliotecas", offline, "ligado" if offline else 'desligado (o "Degrava IA.bat" liga)')
    print("Tudo certo." if tudo else "Há itens marcados com !! acima.")
    return 0 if tudo else 1


def _no_computador(modelo):
    try:
        if modelo == MODELO_WHISPER:  # o faster-whisper baixa só os arquivos que usa
            from faster_whisper.utils import download_model

            download_model(modelo, local_files_only=True)
        else:
            from huggingface_hub import snapshot_download

            snapshot_download(modelo, local_files_only=True)
        return True
    except Exception:
        return False


def _pastas_com_modelos():
    """Outros lugares deste PC onde os modelos podem já ter sido baixados."""
    from huggingface_hub.constants import HF_HUB_CACHE

    destino = Path(HF_HUB_CACHE).resolve()
    candidatos = [Path.home() / ".cache" / "huggingface" / "hub"]  # pasta padrão do Hugging Face
    raiz = destino.parent.parent  # .../Degrava IA (quando os modelos ficam em DegravaIA/modelos)
    for base in (raiz.parent, raiz.parent.parent):  # outras cópias do Degrava IA ao lado desta
        candidatos += list(base.glob("*/modelos/hub")) + list(base.glob("*/*/modelos/hub"))
    vistos = []
    for c in candidatos:
        try:
            c = c.resolve()
        except OSError:
            continue
        if c.is_dir() and c != destino and c not in vistos:
            vistos.append(c)
    return destino, vistos


def _copiar(origem, destino):
    """Copia um modelo já baixado. Segue os atalhos (links simbólicos) da pasta do Hugging Face
    e leva só refs/ e snapshots/ com os arquivos de verdade, o mesmo formato que ele usa no
    Windows sem atalhos. No mesmo disco usa links físicos (não ocupa espaço de novo)."""
    def ligar(a, b):
        real = os.path.realpath(a)  # o arquivo de verdade por trás do atalho
        try:
            os.link(real, b)
        except OSError:
            shutil.copy2(real, b)

    if destino.exists():  # cópia anterior incompleta: refaz do zero (é a pasta do próprio app)
        shutil.rmtree(destino)
    for parte in ("refs", "snapshots"):
        if (origem / parte).is_dir():
            shutil.copytree(origem / parte, destino / parte, symlinks=False, copy_function=ligar)


def reaproveitar_modelos():
    """Antes de baixar, procura os modelos já baixados em outro lugar do PC e copia de lá."""
    destino, origens = _pastas_com_modelos()
    for modelo in (MODELO_WHISPER, MODELO_SEGUNDA_ESCUTA, MODELO_DIARIZACAO):
        if _no_computador(modelo):
            continue
        nome = "models--" + modelo.replace("/", "--")
        for origem in origens:
            if (origem / nome).is_dir():
                print(f"Reaproveitando {modelo} já baixado em {origem} …", flush=True)
                _copiar(origem / nome, destino / nome)
                if _no_computador(modelo):
                    break


# os arquivos que o faster-whisper usa (faster_whisper.utils.download_model)
ARQUIVOS_WHISPER = ["config.json", "preprocessor_config.json", "model.bin", "tokenizer.json", "vocabulary.*"]


def _gb(n):
    return f"{n / 2**30:.2f}".replace(".", ",")


def baixar_com_andamento(modelo, padroes=None):
    """snapshot_download com uma linha de andamento que se atualiza: GB baixados, velocidade e
    quanto falta (medidos pelo tamanho dos arquivos na pasta do modelo)."""
    import fnmatch
    import threading
    import time

    from huggingface_hub import HfApi, snapshot_download
    from huggingface_hub.constants import HF_HUB_CACHE

    try:
        info = HfApi().model_info(modelo, files_metadata=True)
        total = sum(s.size or 0 for s in info.siblings
                    if padroes is None or any(fnmatch.fnmatch(s.rfilename, p) for p in padroes))
    except Exception:
        total = 0
    pasta = Path(HF_HUB_CACHE) / ("models--" + modelo.replace("/", "--"))
    erro = []

    def baixar():
        try:
            snapshot_download(modelo, allow_patterns=padroes)
        except BaseException as e:  # noqa: BLE001 (repassado abaixo)
            erro.append(e)

    def no_disco():
        try:
            return sum(f.stat().st_size for f in pasta.rglob("*") if f.is_file() and not f.is_symlink())
        except OSError:
            return 0

    inicio_bytes, inicio = no_disco(), time.monotonic()
    tarefa = threading.Thread(target=baixar, daemon=True)
    tarefa.start()
    while tarefa.is_alive():
        tarefa.join(2)
        feito = no_disco()
        passado = time.monotonic() - inicio
        velocidade = (feito - inicio_bytes) / passado if passado > 0 else 0
        linha = f"  {_gb(feito)} GB"
        if total:
            linha += f" de {_gb(total)} GB ({min(100, int(100 * feito / total))}%)"
        if velocidade > 0:
            linha += f" · {velocidade / 2**20:.1f} MB/s".replace(".", ",")
            if total and feito < total:
                falta = (total - feito) / velocidade
                linha += " · falta " + (f"cerca de {int(falta // 60) + 1} min" if falta >= 60 else "menos de 1 min")
        print("\r" + linha.ljust(70), end="", flush=True)
    print("\r" + f"  Pronto: {_gb(no_disco())} GB".ljust(70), flush=True)
    if erro:
        raise erro[0]


def baixar_modelos():
    """Baixa os modelos que faltam (ou reaproveita os já baixados). Nenhum pede token:
    o pyannote vem dentro do pacote."""
    # avisos que só assustam: no Windows sem "modo de desenvolvedor" os modelos são guardados como
    # arquivos comuns (sem links simbólicos), e o download é feito sem conta, como deve ser
    os.environ.setdefault("HF_HUB_DISABLE_SYMLINKS_WARNING", "1")
    os.environ.setdefault("HF_HUB_VERBOSITY", "error")
    # download clássico (sem o "xet"): o arquivo cresce na pasta e dá para mostrar o andamento em GB;
    # as barras da biblioteca contam arquivos, e o modelo é um arquivo só de 3 GB (ficaria parada)
    os.environ.setdefault("HF_HUB_DISABLE_XET", "1")
    os.environ.setdefault("HF_HUB_DISABLE_PROGRESS_BARS", "1")
    import warnings

    warnings.filterwarnings("ignore", message=".*symlinks.*")
    warnings.filterwarnings("ignore", message=".*unauthenticated.*")
    from huggingface_hub import snapshot_download

    reaproveitar_modelos()
    if all(_no_computador(m) for m in (MODELO_WHISPER, MODELO_SEGUNDA_ESCUTA, MODELO_DIARIZACAO)):
        print("Os três modelos já estão no computador: nada a baixar.")
        return 0
    # primeiro os dois modelos livres, que não precisam de token
    if not _no_computador(MODELO_WHISPER):
        print("Baixando o modelo de transcrição (Whisper large-v3, cerca de 3 GB). Pode levar de 5 a 30 minutos,")
        print("conforme a internet; a barra abaixo mostra o andamento.", flush=True)
        # os mesmos arquivos que o faster-whisper baixa, mas com a barra de progresso (ele a esconde)
        baixar_com_andamento(MODELO_WHISPER, ARQUIVOS_WHISPER)
    if not _no_computador(MODELO_SEGUNDA_ESCUTA):
        print("Baixando o modelo da segunda escuta (wav2vec2, cerca de 1,3 GB) …", flush=True)
        baixar_com_andamento(MODELO_SEGUNDA_ESCUTA)
    if not _no_computador(MODELO_DIARIZACAO):
        # o pacote do Degrava IA já traz este modelo (modelos/hub); só a cópia do código-fonte
        # precisa baixá-lo, e os autores exigem um token do Hugging Face para isso
        if not os.environ.get("HF_TOKEN"):
            print(f"Falta o modelo {MODELO_DIARIZACAO}, que vem dentro do DegravaIA.zip.")
            print("Baixe o pacote completo de novo e descompacte-o inteiro.")
            return 1
        print(f"Baixando {MODELO_DIARIZACAO} …", flush=True)
        snapshot_download(MODELO_DIARIZACAO, token=os.environ["HF_TOKEN"])
    print("Modelos no computador. Daqui em diante o app funciona sem internet.")
    return 0
