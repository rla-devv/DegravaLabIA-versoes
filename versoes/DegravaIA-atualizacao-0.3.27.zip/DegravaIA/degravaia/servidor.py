"""Tela de revisão: servidor local só para o próprio computador (item 12).

Usa só a biblioteca padrão do Python. Escuta em 127.0.0.1 e recusa:
- pedidos cujo Host não seja este computador (bloqueia "DNS rebinding");
- alterações vindas de outra página aberta no navegador (confere o Origin).
Nada é carregado da internet: a página e os scripts estão em degravaia/web/.
"""
import json
import os
import re
import shutil
import subprocess
import sys
import threading
import time
import uuid
import webbrowser
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import unquote, urlparse

from . import andamento, atualizacao, audio, exportacao, marcacoes, montagem, revisao, trechos
from .config import NOME_APP, NOME_TECNICO, VERSAO
from .projeto import Projeto

WEB = Path(__file__).parent / "web"
TIPOS_ESTATICOS = {".html": "text/html; charset=utf-8", ".js": "text/javascript; charset=utf-8",
                   ".css": "text/css; charset=utf-8", ".ico": "image/x-icon", ".png": "image/png",
                   ".woff2": "font/woff2"}
NOME_VALIDO = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]*$")
BLOCO = 256 * 1024

_trava = threading.Lock()  # uma alteração de cada vez
_trava_motores = threading.Lock()  # um uso dos motores de cada vez (reanálise, importação)


class Erro(Exception):
    def __init__(self, status, mensagem):
        super().__init__(mensagem)
        self.status, self.mensagem = status, mensagem


def resumo_projeto(proj):
    d = proj.dados
    alteracoes = [l for l in revisao.alteracoes_do_usuario(proj) if l["acao"] in revisao.TIPOS and not l["desfeita"]]
    return {
        "id": proj.pasta.name,
        "arquivo": d["original"]["nome"],
        "importado_em": d["original"]["importado_em"],
        "duracao_s": d["processamento"].get("transcricao", {}).get("duracao_s"),
        "interlocutores": len(d["interlocutores"]),
        "alteracoes": len(alteracoes),
        "posicao_s": d.get("revisao", {}).get("posicao_s", 0),
        "pendentes": sum(1 for m in d.get("marcacoes", []) if m["origem"] == "ia" and not m.get("decisao")
                         and marcacoes.TIPOS[m["tipo"]]["substitui"])
        + sum(1 for x in d.get("insercoes", []) if x["origem"] == "ia" and not x.get("decisao")),
    }


class Manipulador(BaseHTTPRequestHandler):
    server_version = f"{NOME_TECNICO}/{VERSAO}"
    raiz: Path = Path("projetos")
    porta: int = 0

    # ---------- utilitários ----------
    def log_message(self, formato, *args):
        pass  # sem log no terminal a cada pedido

    def _hosts_permitidos(self):
        return {f"127.0.0.1:{self.porta}", f"localhost:{self.porta}"}

    def _conferir_host(self):
        if self.headers.get("Host") not in self._hosts_permitidos():
            raise Erro(HTTPStatus.FORBIDDEN, "Acesso permitido só pelo próprio computador.")

    def _conferir_origem(self):
        origem = self.headers.get("Origin")
        if origem is None or urlparse(origem).netloc not in self._hosts_permitidos():
            raise Erro(HTTPStatus.FORBIDDEN, "Alteração recusada: origem desconhecida.")
        tipo = self.headers.get("Content-Type", "")
        envio = urlparse(self.path).path == "/api/importar" and tipo == "application/octet-stream"
        if not tipo.startswith("application/json") and not envio:
            raise Erro(HTTPStatus.UNSUPPORTED_MEDIA_TYPE, "Envie JSON.")

    def _cabecalhos_comuns(self):
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Content-Security-Policy",
                         "default-src 'self'; media-src 'self'; img-src 'self' data:; "
                         "connect-src 'self'; frame-ancestors 'none'")

    def _json(self, dados, status=HTTPStatus.OK):
        corpo = json.dumps(dados, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(corpo)))
        self._cabecalhos_comuns()
        self.end_headers()
        self.wfile.write(corpo)

    def _ler_json(self):
        tamanho = int(self.headers.get("Content-Length") or 0)
        if tamanho > 1_000_000:
            raise Erro(HTTPStatus.REQUEST_ENTITY_TOO_LARGE, "Pedido grande demais.")
        try:
            return json.loads(self.rfile.read(tamanho) or b"{}")
        except json.JSONDecodeError:
            raise Erro(HTTPStatus.BAD_REQUEST, "JSON inválido.")

    def _projeto(self, nome):
        nome = unquote(nome)
        pasta = self.raiz / nome
        if not NOME_VALIDO.match(nome) or not (pasta / "projeto.json").is_file():
            raise Erro(HTTPStatus.NOT_FOUND, "Projeto não encontrado.")
        return Projeto(pasta)

    def _rota(self, metodo):
        caminho = urlparse(self.path).path
        partes = [p for p in caminho.split("/") if p]
        try:
            self._conferir_host()
            if metodo == "POST":
                self._conferir_origem()
            if metodo == "GET" and (not partes or partes[0] in ("index.html", "projeto")):
                return self._estatico("index.html")
            if metodo == "GET" and partes[0] == "web" and len(partes) == 2:
                return self._estatico(partes[1])
            if partes[:2] == ["api", "projetos"]:
                return self._api(metodo, partes[2:])
            if partes[:2] == ["api", "importar"] and metodo == "POST":
                return self._importar()
            if partes[:2] == ["api", "importacoes"] and len(partes) == 3 and metodo == "GET":
                return self._json(estado_importacao(partes[2]))
            if partes == ["api", "aba"] and metodo == "POST":
                return self._json(registrar_aba(self._ler_json()))
            if partes == ["api", "saude"] and metodo == "GET":  # o lançador e a página esperam por ela
                return self._json({"ok": True, "versao": VERSAO})
            if partes == ["api", "atualizacao"]:
                if metodo == "GET":
                    return self._json(estado_atualizacao(forcar="forcar=1" in urlparse(self.path).query))
                return self._json(iniciar_atualizacao(self._ler_json(), self.server))
            raise Erro(HTTPStatus.NOT_FOUND, "Página não encontrada.")
        except Erro as e:
            self._json({"erro": e.mensagem}, e.status)
        except (revisao.AlteracaoInvalida, exportacao.ExportacaoInvalida) as e:
            self._json({"erro": str(e)}, HTTPStatus.BAD_REQUEST)
        except (BrokenPipeError, ConnectionResetError):
            pass  # o navegador cancelou (comum ao pular no áudio)

    def do_GET(self):
        self._rota("GET")

    def do_HEAD(self):
        self._rota("GET")

    def do_POST(self):
        self._rota("POST")

    # ---------- arquivos ----------
    def _estatico(self, nome):
        caminho = WEB / nome
        if not NOME_VALIDO.match(nome) or caminho.suffix not in TIPOS_ESTATICOS or not caminho.is_file():
            raise Erro(HTTPStatus.NOT_FOUND, "Arquivo não encontrado.")
        corpo = caminho.read_bytes()
        if nome == "index.html":  # a versão já vem na página (o cabeçalho a mostra em todas as telas)
            corpo = corpo.replace(b'<span id="versao"></span>', f'<span id="versao">{VERSAO}</span>'.encode())
        self.send_response(HTTPStatus.OK)
        self.send_header("Content-Type", TIPOS_ESTATICOS[caminho.suffix])
        self.send_header("Content-Length", str(len(corpo)))
        self._cabecalhos_comuns()
        self.end_headers()
        if self.command != "HEAD":
            self.wfile.write(corpo)

    def _audio(self, proj, melhorado=False):
        """Envia o áudio de revisão aceitando "Range", para o player poder pular no tempo."""
        caminho = proj.caminho_audio_melhorado if melhorado else proj.caminho_audio_revisao
        if melhorado and not caminho.exists():
            raise Erro(HTTPStatus.NOT_FOUND, "Este projeto não tem áudio melhorado.")
        if not caminho.exists():
            with _trava:
                if not caminho.exists():
                    tmp = caminho.with_name("audio_revisao.tmp.wav")
                    audio.extrair_audio_revisao(proj.caminho_original, tmp)
                    os.replace(tmp, caminho)
        total = caminho.stat().st_size
        inicio, fim = 0, total - 1
        faixa = self.headers.get("Range")
        m = re.match(r"bytes=(\d*)-(\d*)$", faixa or "")
        if faixa and m and (m.group(1) or m.group(2)):
            if m.group(1):
                inicio = int(m.group(1))
                fim = min(int(m.group(2)), total - 1) if m.group(2) else total - 1
            else:
                inicio = max(0, total - int(m.group(2)))
            if inicio > fim:
                self.send_response(HTTPStatus.REQUESTED_RANGE_NOT_SATISFIABLE)
                self.send_header("Content-Range", f"bytes */{total}")
                self.end_headers()
                return
            self.send_response(HTTPStatus.PARTIAL_CONTENT)
            self.send_header("Content-Range", f"bytes {inicio}-{fim}/{total}")
        else:
            self.send_response(HTTPStatus.OK)
        self.send_header("Content-Type", "audio/wav")
        self.send_header("Accept-Ranges", "bytes")
        self.send_header("Content-Length", str(fim - inicio + 1))
        self._cabecalhos_comuns()
        self.end_headers()
        if self.command == "HEAD":
            return
        with open(caminho, "rb") as f:
            f.seek(inicio)
            falta = fim - inicio + 1
            while falta > 0:
                parte = f.read(min(BLOCO, falta))
                if not parte:
                    break
                self.wfile.write(parte)
                falta -= len(parte)

    def _arquivo_exportado(self, proj, nome):
        caminho = proj.pasta / "exportacoes" / nome
        tipos = {".docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                 ".pdf": "application/pdf", ".srt": "application/x-subrip; charset=utf-8",
                 ".txt": "text/plain; charset=utf-8",
                 ".xlsx": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"}
        if not NOME_VALIDO.match(nome) or caminho.suffix not in tipos or not caminho.is_file():
            raise Erro(HTTPStatus.NOT_FOUND, "Arquivo não encontrado.")
        corpo = caminho.read_bytes()
        self.send_response(HTTPStatus.OK)
        self.send_header("Content-Type", tipos[caminho.suffix])
        self.send_header("Content-Disposition", f'attachment; filename="{nome}"')
        self.send_header("Content-Length", str(len(corpo)))
        self._cabecalhos_comuns()
        self.end_headers()
        if self.command != "HEAD":
            self.wfile.write(corpo)

    def _importar(self):
        """Recebe o arquivo do navegador (fica no computador) e importa em segundo plano."""
        from urllib.parse import parse_qs

        q = {k: v[0] for k, v in parse_qs(urlparse(self.path).query).items()}
        nome = Path(unquote(q.get("nome", ""))).name
        if not nome or nome.startswith("."):
            raise Erro(HTTPStatus.BAD_REQUEST, "Nome de arquivo inválido.")
        idioma = q.get("idioma", "pt")
        if not re.fullmatch(r"auto|[a-z]{2,3}", idioma):
            raise Erro(HTTPStatus.BAD_REQUEST, "Idioma inválido.")
        falantes = int(q["falantes"]) if q.get("falantes", "").isdigit() and int(q["falantes"]) > 0 else None
        vocabulario = motores_vocabulario(unquote(q.get("vocabulario", "")))
        melhoria = q.get("melhoria") or None
        if melhoria is not None and melhoria not in audio.MELHORIAS:
            raise Erro(HTTPStatus.BAD_REQUEST, "Nível de melhoria desconhecido.")
        tamanho = int(self.headers.get("Content-Length") or 0)
        if tamanho <= 0:
            raise Erro(HTTPStatus.BAD_REQUEST, "Arquivo vazio.")
        if not _trava_motores.acquire(blocking=False):
            raise Erro(HTTPStatus.CONFLICT, "Já há um processamento em andamento. Aguarde terminar.")
        pasta = self.raiz / ".importando" / uuid.uuid4().hex
        try:
            pasta.mkdir(parents=True)
            destino = pasta / nome
            with open(destino, "wb") as f:
                falta = tamanho
                while falta > 0:
                    parte = self.rfile.read(min(BLOCO * 4, falta))
                    if not parte:
                        raise Erro(HTTPStatus.BAD_REQUEST, "Envio interrompido.")
                    f.write(parte)
                    falta -= len(parte)
        except BaseException:
            _trava_motores.release()
            shutil.rmtree(pasta, ignore_errors=True)
            raise
        tarefa = uuid.uuid4().hex[:12]
        _importacoes[tarefa] = {"estado": "rodando", "log": [], "projeto": None, "arquivo": nome,
                                "andamento": andamento.Andamento(andamento.carregar_aprendido(self.raiz))}
        threading.Thread(target=_rodar_importacao, daemon=True, args=(
            tarefa, destino, self.raiz, idioma, falantes, q.get("interlocutores", "1") == "1", melhoria,
            vocabulario)).start()
        return self._json({"tarefa": tarefa})

    def _trecho(self, proj, corpo):
        ids = corpo.get("palavras") or []
        if not ids or not all(isinstance(i, int) and 0 <= i < len(proj.dados["palavras"]) for i in ids):
            raise Erro(HTTPStatus.BAD_REQUEST, "Selecione um trecho.")
        ids = sorted(set(ids))
        if corpo.get("acao") == "limpa":
            literal = " ".join(proj.dados["palavras"][i]["texto"] for i in ids if proj.dados["palavras"][i]["texto"])
            return {"literal": literal, "limpa": trechos.limpar(literal)}
        if corpo.get("acao") == "reanalisar":
            if proj.dados["palavras"][ids[-1]]["fim"] - proj.dados["palavras"][ids[0]]["inicio"] > 60:
                raise Erro(HTTPStatus.BAD_REQUEST, "Selecione um trecho de até 60 segundos.")
            nivel = corpo.get("nivel")
            if nivel is not None and nivel not in audio.MELHORIAS:
                raise Erro(HTTPStatus.BAD_REQUEST, "Nível de melhoria desconhecido.")
            if not _trava_motores.acquire(timeout=1):
                raise Erro(HTTPStatus.CONFLICT, "Há um processamento em andamento. Tente de novo em instantes.")
            try:  # processo à parte: a memória dos modelos volta ao sistema ao terminar
                args = ["reanalisar", proj.pasta.resolve(), "--palavras", *ids] + (["--nivel", nivel] if nivel else [])
                proc = _motor(*args)
                linhas, ultima = [], None
                relogio = threading.Timer(900, proc.kill)  # trava de verdade: desiste em 15 min
                relogio.start()
                for linha in proc.stdout:
                    linhas.append(linha)
                    if linha.startswith("{"):  # o resultado chegou: não espera o processo fechar
                        ultima = linha
                        threading.Timer(ESPERA_FECHAR_S, _encerrar_se_parado, args=(proc,)).start()
                relogio.cancel()
                proc.wait()
                saida = "".join(linhas)
            finally:
                _trava_motores.release()
            if not ultima or (proc.returncode != 0 and not proc.encerrado_por_nos):
                raise Erro(HTTPStatus.INTERNAL_SERVER_ERROR, "A reanálise falhou: " + saida.strip()[-300:])
            return json.loads(ultima)
        raise Erro(HTTPStatus.BAD_REQUEST, "Ação desconhecida.")

    # ---------- API ----------
    def _api(self, metodo, partes):
        if not partes:
            if metodo != "GET":
                raise Erro(HTTPStatus.METHOD_NOT_ALLOWED, "Método não permitido.")
            projetos = []
            if self.raiz.is_dir():
                for pasta in sorted(self.raiz.iterdir(), reverse=True):
                    if (pasta / "projeto.json").is_file():
                        try:
                            projetos.append(resumo_projeto(Projeto(pasta)))
                        except (OSError, ValueError, KeyError):
                            continue  # projeto incompleto (importação interrompida)
            return self._json({"projetos": projetos, "pasta": str(self.raiz.resolve()), "versao": VERSAO,
                               "janela": os.environ.get("DEGRAVAIA_JANELA") == "1"})

        acao = partes[1] if len(partes) > 1 else None
        if metodo == "GET":
            proj = self._projeto(partes[0])
            if acao is None:
                if "marcacoes" in proj.dados and proj.dados.get("segunda_escuta") and proj.dados["palavras"] \
                        and "discorda" not in proj.dados["palavras"][0]:
                    with _trava:  # projeto da Etapa 3: só acrescenta o destaque de discordância
                        proj = self._projeto(partes[0])
                        marcacoes.marcar_discordancia(proj.dados)
                        proj.salvar()
                if "marcacoes" not in proj.dados:
                    with _trava:  # projeto da Etapa 1/2: cria as marcações e sugestões uma vez
                        proj = self._projeto(partes[0])
                        if "marcacoes" not in proj.dados:
                            marcacoes.gerar(proj.dados)
                            proj.salvar()
                            proj.registrar("marcacoes", {"marcacoes": len(proj.dados["marcacoes"]),
                                                         "sugestoes_insercao": len(proj.dados["insercoes"])},
                                           origem="ia")
                d = proj.dados
                return self._json({"id": proj.pasta.name, "resumo": resumo_projeto(proj),
                                   "dados": {k: d.get(k) for k in ("original", "opcoes", "revisao")}
                                   | {"melhoria": d.get("processamento", {}).get("melhoria")}
                                   | estado_tela(d) | {"avisos": avisos(d)}})
            if acao == "audio":
                return self._audio(proj, melhorado="versao=melhorado" in urlparse(self.path).query)
            if acao == "historico":
                return self._json({"alteracoes": revisao.alteracoes_do_usuario(proj)})
            if acao == "exportacao":
                return self._json(estado_exportacao(proj, self.raiz))
            if acao == "exportacoes" and len(partes) == 3:
                return self._arquivo_exportado(proj, unquote(partes[2]))
            raise Erro(HTTPStatus.NOT_FOUND, "Página não encontrada.")

        corpo = self._ler_json()
        if acao == "excluir":
            return self._json(excluir_projeto(self._projeto(partes[0])))
        if acao == "trecho":  # item 11: só leitura e motores; nada é gravado
            return self._json(self._trecho(self._projeto(partes[0]), corpo))
        with _trava:
            proj = self._projeto(partes[0])  # relê do disco: o arquivo é a fonte da verdade
            if acao == "alteracao":
                feita = revisao.alterar(proj, corpo.get("tipo"), corpo)
            elif acao == "desfazer":
                feita = revisao.desfazer(proj)
            elif acao == "exportar":
                arquivos = exportacao.exportar(proj, self.raiz, corpo.get("formatos"), corpo.get("campos"))
                return self._json({"arquivos": arquivos})
            elif acao == "posicao":
                proj.dados.setdefault("revisao", {})["posicao_s"] = round(float(corpo.get("segundos", 0)), 2)
                proj.salvar()
                return self._json({"ok": True})
            else:
                raise Erro(HTTPStatus.NOT_FOUND, "Página não encontrada.")
            d = proj.dados
        return self._json({"feita": feita} | estado_tela(d))


def estado_tela(dados):
    """Texto como vai ao documento, fala por fala, com o que é só sugestão marcado (item 3)."""
    falas = []
    for n, fala in enumerate(dados["falas"]):
        partes = []
        for p in marcacoes.partes_da_fala(fala, dados, final=n == len(dados["falas"]) - 1):
            p = dict(p)
            if "marcacao" in p:
                p["marcacao"] = p["marcacao"]["id"]
            if "insercao" in p:
                p["insercao"] = p["insercao"]["id"]
            partes.append(p)
        falas.append(fala | {"partes": partes})
    return {"interlocutores": dados["interlocutores"], "palavras": dados["palavras"], "falas": falas,
            "marcacoes": dados.get("marcacoes", []), "insercoes": dados.get("insercoes", [])}


_importacoes = {}  # tarefa → {"estado", "log", "projeto", "arquivo"}


def _motor(*args):
    """Roda `python -m degravaia …` num processo à parte: os modelos (vários GB) saem da
    memória quando ele termina, e uma falha dos motores não derruba a tela."""
    env = os.environ | {"PYTHONIOENCODING": "utf-8", "PYTHONUNBUFFERED": "1"}
    # grupo de processos próprio (Windows): quando o motor fecha depois de usar a GPU, um sinal
    # de "encerrar" que ele dispare não chega ao servidor
    grupo = subprocess.CREATE_NEW_PROCESS_GROUP if os.name == "nt" else 0
    proc = subprocess.Popen([sys.executable, "-m", "degravaia", *map(str, args)], stdout=subprocess.PIPE,
                            stderr=subprocess.STDOUT, text=True, encoding="utf-8", errors="replace", env=env,
                            cwd=str(Path(__file__).resolve().parent.parent), creationflags=grupo)
    proc.encerrado_por_nos = False
    return proc


ESPERA_FECHAR_S = 30


def _encerrar_se_parado(proc):
    if proc.poll() is None:
        proc.encerrado_por_nos = True
        proc.kill()


def motores_vocabulario(texto):
    from .motores import limpar_vocabulario  # leve: não carrega os modelos

    return limpar_vocabulario(texto)


def _rodar_importacao(tarefa, arquivo, raiz, idioma, falantes, com_interlocutores, melhoria=None, vocabulario=None):
    t = _importacoes[tarefa]
    args = ["importar", arquivo, "--projetos", Path(raiz).resolve(), "--idioma", idioma, "--sem-texto",
            "--procedencia", f"{arquivo.name} (enviado pela tela de revisão)"]
    if falantes:
        args += ["--falantes", falantes]
    if not com_interlocutores:
        args.append("--sem-interlocutores")
    if melhoria:
        args += ["--melhoria", melhoria]
    if vocabulario:
        args += ["--vocabulario", ", ".join(vocabulario)]
    try:
        proc = _motor(*args)
        for linha in proc.stdout:
            linha = linha.rstrip()
            if linha.startswith("@andamento "):
                try:
                    t["andamento"].receber(json.loads(linha[len("@andamento "):]))
                except (ValueError, TypeError, KeyError):
                    pass
                continue
            if linha.startswith("@erro "):  # erro com o que fazer, para a pessoa (não só o técnico)
                t["erro"] = linha[len("@erro "):]
                t["log"].append(t["erro"])
                continue
            if linha and not RUIDO.search(linha):
                t["log"].append(linha)
            if linha.startswith("Projeto salvo em "):
                t["projeto"] = Path(linha[len("Projeto salvo em "):]).name
                # rede de segurança: se o processo não fechar sozinho, fecha-o (o projeto já está salvo)
                threading.Timer(ESPERA_FECHAR_S, _encerrar_se_parado, args=(proc,)).start()
        proc.wait()
        t["estado"] = "pronto" if t["projeto"] and (proc.returncode == 0 or proc.encerrado_por_nos) else "erro"
        if t["estado"] == "pronto":
            t["andamento"].aprender(raiz)  # a próxima previsão neste computador sai mais certa
        if t["estado"] == "erro":
            t["log"].append("ERRO: a importação não terminou (detalhe acima).")
    except Exception as erro:
        t["log"].append(f"ERRO: {erro}")
        t["estado"] = "erro"
    finally:
        shutil.rmtree(arquivo.parent, ignore_errors=True)  # o projeto guardou a cópia protegida
        _trava_motores.release()


# avisos internos das bibliotecas, que não interessam na tela
RUIDO = re.compile(r"Warning|warn\(|std = sequences|Loading weights|^\s*$")


def estado_importacao(tarefa):
    if tarefa not in _importacoes:
        raise Erro(HTTPStatus.NOT_FOUND, "Importação não encontrada.")
    t = _importacoes[tarefa]
    return {k: v for k, v in t.items() if k != "andamento"} | {"andamento": t["andamento"].estado()}


def estado_exportacao(proj, raiz):
    pendentes = sum(1 for m in proj.dados.get("marcacoes", [])
                    if m["origem"] == "ia" and not m.get("decisao") and marcacoes.TIPOS[m["tipo"]]["substitui"])
    anteriores = [{"quando": l["quando"], "arquivos": l["detalhes"]["arquivos"]}
                  for l in revisao.historico(proj) if l["acao"] == "exportacao"]
    return {"campos": exportacao.campos_do_projeto(proj, raiz), "formatos": exportacao.FORMATOS,
            "pendentes": pendentes, "anteriores": anteriores[::-1][:10]}


def avisos(dados):
    """Pontos que pedem atenção na revisão, além do destaque por palavra (item 4)."""
    proc = dados.get("processamento", {})
    regioes = proc.get("transcricao", {}).get("regioes")
    # recalculado com o critério atual (projetos antigos guardaram o anterior)
    fora = montagem.fora_das_regioes(dados.get("segunda_escuta", []), regioes) if regioes else []
    return {"fora_dos_turnos": fora,
            "sobreposicoes": dados.get("processamento", {}).get("interlocutores", {}).get("sobreposicoes", [])}


# ---------- atualização do app (atualizacao.py) ----------
_abas = {}  # aba do navegador → (projeto aberto nela, último sinal)
_atualizacao = {"consultado": 0.0, "nova": None, "estado": "parado", "erro": None, "sem_conexao": False}
ABA_VIVA_S = 45  # a tela do projeto dá sinal a cada 15 s


def registrar_aba(corpo):
    aba = str(corpo.get("aba", ""))[:40]
    if aba:
        if corpo.get("projeto"):
            _abas[aba] = (str(corpo["projeto"])[:200], time.time())
        else:
            _abas.pop(aba, None)  # a aba saiu do projeto
    return {"ok": True}


def projetos_abertos():
    agora = time.time()
    return sorted({p for p, t in _abas.values() if agora - t < ABA_VIVA_S})


CONSULTA_S = 15 * 60  # com o app aberto, uma versão nova aparece em até 15 min (ou já, pelo botão)


def estado_atualizacao(forcar=False):
    if _atualizacao["estado"] == "parado" and (forcar or time.time() - _atualizacao["consultado"] > CONSULTA_S):
        try:
            _atualizacao.update(nova=atualizacao.verificar(avisar_sem_conexao=True), sem_conexao=False)
        except atualizacao.SemConexao:
            _atualizacao["sem_conexao"] = True  # mantém o que já se sabia
        _atualizacao["consultado"] = time.time()
    return {"versao": VERSAO, "nova": _atualizacao["nova"], "estado": _atualizacao["estado"],
            "erro": _atualizacao["erro"], "sem_conexao": _atualizacao["sem_conexao"],
            "projetos_abertos": projetos_abertos()}


def iniciar_atualizacao(corpo, servidor):
    nova = _atualizacao["nova"]
    if not nova or corpo.get("versao") != nova["versao"]:
        raise Erro(HTTPStatus.CONFLICT, "Não há esta versão para instalar. Recarregue a página.")
    if _atualizacao["estado"] == "instalando":
        return estado_atualizacao()
    if nova.get("lancador_minimo", 0) > atualizacao.lancador_em_uso():
        raise Erro(HTTPStatus.CONFLICT, "Esta versão precisa que o Degrava Lab IA seja fechado e aberto de novo antes "
                                        "de atualizar. Feche o app, abra de novo e clique em Atualizar agora.")
    if projetos_abertos():
        raise Erro(HTTPStatus.CONFLICT, "Há um projeto aberto no navegador. Feche-o (volte à página "
                                        "inicial em todas as abas) e tente de novo.")
    if not _trava_motores.acquire(blocking=False):
        raise Erro(HTTPStatus.CONFLICT, "Há um processamento em andamento. Atualize quando ele terminar.")
    _atualizacao.update(estado="instalando", erro=None)

    def rodar():
        try:
            with _trava:  # nenhuma alteração de projeto enquanto os arquivos são trocados
                atualizacao.instalar(nova)
            _atualizacao["estado"] = "reiniciando"
            servidor.codigo_saida = atualizacao.REINICIAR
            print("Atualização instalada. O lançador abre a versão nova.", flush=True)
            # sai com o código 3 depois de a página receber a resposta; quem abre a versão nova (e faz o
            # que precisa do servidor fechado, como o pip) é o lançador, sem fechar a janela
            threading.Timer(1.5, os._exit, args=(atualizacao.REINICIAR,)).start()
        except Exception as erro:
            _atualizacao.update(estado="parado", erro=f"A atualização não foi feita (nada mudou): {erro}")
        finally:
            if _atualizacao["estado"] != "reiniciando":
                _trava_motores.release()

    threading.Thread(target=rodar, daemon=True).start()
    return estado_atualizacao()


def excluir_projeto(proj):
    """Apaga o projeto da pasta: cópia do original, transcrição, histórico e exportações."""
    if proj.pasta.name in projetos_abertos():
        raise Erro(HTTPStatus.CONFLICT, "Este projeto está aberto em outra aba. Feche-a e tente de novo.")
    if not _trava_motores.acquire(blocking=False):
        raise Erro(HTTPStatus.CONFLICT, "Há um processamento em andamento. Exclua quando ele terminar.")
    try:
        with _trava:
            apagar_pasta(proj.pasta)
    finally:
        _trava_motores.release()
    return {"ok": True}


def apagar_pasta(pasta):
    """rmtree que também apaga a cópia protegida (só leitura) do original, que no Windows
    o rmtree comum recusa."""
    import stat

    def liberar(funcao, caminho, _erro):
        os.chmod(caminho, stat.S_IWRITE | stat.S_IREAD)
        funcao(caminho)

    if sys.version_info >= (3, 12):
        shutil.rmtree(pasta, onexc=liberar)
    else:
        shutil.rmtree(pasta, onerror=liberar)


def _arrumar_pasta():
    try:
        atualizacao.limpar_sobras()
        from .instalar import arrumar_pasta

        arrumar_pasta()
    except Exception as erro:
        print(f"Arrumação da pasta: {erro}", flush=True)


def _ja_aberto(porta):
    """O Degrava Lab IA já está rodando nesta porta? (a pessoa abriu o app de novo)"""
    from urllib.request import urlopen

    try:
        with urlopen(f"http://127.0.0.1:{porta}/api/projetos", timeout=2) as r:
            return "projetos" in json.loads(r.read().decode("utf-8"))
    except Exception:
        return False


def _registrar_erros():
    """Erros que não derrubariam a tela sem deixar rastro: vão para a saída (registro.txt)."""
    import faulthandler

    faulthandler.enable()  # queda grave (ex.: biblioteca nativa): mostra onde estava

    def em_thread(args):
        print(f"ERRO numa tarefa da tela: {args.exc_type.__name__}: {args.exc_value}", flush=True)
        import traceback

        traceback.print_tb(args.exc_traceback)

    threading.excepthook = em_thread


def servir(raiz="projetos", porta=8765, abrir=True):
    _registrar_erros()
    raiz = Path(raiz)
    Manipulador.raiz = raiz
    try:
        servidor = ThreadingHTTPServer(("127.0.0.1", porta), Manipulador)
    except OSError:
        if _ja_aberto(porta):
            print(f"{NOME_APP} já está aberto. Abrindo a tela no navegador…")
            if abrir:
                webbrowser.open(f"http://127.0.0.1:{porta}/")
            return
        print(f"A porta {porta} está ocupada por outro programa. Feche-o ou use: "
              f"python -m degravaia revisar --porta {porta + 1}")
        return 1
    servidor.codigo_saida = 0
    Manipulador.porta = servidor.server_address[1]
    endereco = f"http://127.0.0.1:{Manipulador.porta}/"
    print(f"{NOME_APP}: tela de revisão em {endereco}")
    print("Acessível só por este computador. Para encerrar: Ctrl+C nesta janela.")
    if abrir:
        threading.Timer(0.5, webbrowser.open, args=(endereco,)).start()
    threading.Thread(target=estado_atualizacao, daemon=True).start()  # já deixa a consulta pronta
    threading.Thread(target=_arrumar_pasta, daemon=True).start()
    try:
        servidor.serve_forever()
    except KeyboardInterrupt:
        print("\nEncerrado.")
    finally:
        servidor.server_close()
    if servidor.codigo_saida == atualizacao.REINICIAR:
        print("Atualização instalada. Reabrindo…")
    return servidor.codigo_saida
