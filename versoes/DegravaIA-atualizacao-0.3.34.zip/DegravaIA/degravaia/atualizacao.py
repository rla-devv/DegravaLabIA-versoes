"""Atualização do próprio app (código), confirmada pelo usuário na tela inicial.

Como funciona:
- ao abrir e a cada 15 minutos (e pelo botão "Buscar atualização"), a tela pergunta ao servidor
  local se há versão nova; o botão do topo vira "Nova versão X". O servidor baixa só o arquivo
  `atualizacao.json` do repositório público REPO_VERSOES (nenhum dado do usuário é
  enviado: é um download comum, como abrir uma página). O publicar.py põe lá o
  atualizacao.json e o pacote em versoes/;
- o usuário confirma; o pacote de código (poucos MB) é baixado e conferido pelo tamanho e pelo SHA-256;
- os arquivos atuais que mudam vão para versoes-anteriores/<versão>/ (só a última versão fica guardada)
  e os novos entram no lugar. Nunca são tocadas as pastas python/, modelos/, projetos/ e .venv/;
- se o requirements.txt mudou, as bibliotecas são atualizadas. Com o lançador novo (janela.pyw
  ou abrir.py, que avisam por DEGRAVAIA_LANCADOR), isso fica para depois de o servidor sair, em
  .atualizacao/pendente.json: no Windows o pip não troca uma biblioteca que o servidor está usando.
  O lançador chama concluir_pendente() com o servidor fechado e, se der errado, volta tudo;
- o servidor sai com o código 3 e o lançador o abre de novo na mesma janela, já na versão nova.

Voltar para a versão anterior (link "Voltar para a versão X" no popup, ou `restaurar-versao` na linha de comando):
o servidor deixa {"etapas": ["restaurar"], "restaurar": "X"} em .atualizacao/pendente.json e sai com o código 3;
o lançador, com o servidor fechado, devolve os arquivos guardados, tira os que só a versão atual tinha (pela
lista arquivos-do-app.txt), roda o pip se o requirements.txt da versão guardada for outro e apaga a cópia usada.
Se algo falhar, tudo volta a ser a versão atual. Só aparece com lançador LANCADOR >= 3 (os antigos, ainda
abertos desde antes desta versão, não conhecem essa etapa).

Sem internet, ou enquanto REPO_VERSOES não existir, a consulta falha em silêncio e o app
segue normalmente. Publicar uma versão: PUBLICAR-VERSAO.md.
"""
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import time
import zipfile
from pathlib import Path
from urllib.request import Request, urlopen

from .config import NOME_TECNICO, REPO_VERSOES, VERSAO

RAIZ_APP = Path(__file__).resolve().parent.parent
LISTA = "arquivos-do-app.txt"  # arquivos do código, gerada pelo empacotar.py; fica na raiz (as versões
# já instaladas a procuram ali para aceitar a atualização), escondida no Windows
PROTEGIDAS = ("python/", "modelos/", "projetos/", ".venv/", "versoes-anteriores/", ".atualizacao/", ".git/",
              "dados-janela/", "Abrir Degrava Lab IA.lnk", "Abrir Degrava Lab.lnk", "Abrir Degrava IA.lnk",
              "Abrir o Degrava IA.lnk")  # o atalho da pasta é da instalação, não do pacote
REINICIAR = 3  # código de saída que pede ao lançador (abrir.py, janela.pyw) para abrir o servidor de novo
PENDENTE = RAIZ_APP / ".atualizacao" / "pendente.json"  # o que falta fazer com o servidor fechado
LANCADOR = 3  # versão do lançador desta versão do app; o publicar.py pode exigir uma mínima (lancador_minimo)
LANCADOR_RESTAURA = 3  # a partir desta versão o lançador sabe voltar para a versão anterior (etapa "restaurar")


def lancador_em_uso():
    """A versão do lançador que abriu este servidor (0: um antigo, que não avisa)."""
    try:
        return int(os.environ.get("DEGRAVAIA_LANCADOR", "0"))
    except ValueError:
        return 0


class AtualizacaoInvalida(Exception):
    pass


def _base():
    # DEGRAVAIA_REPO_VERSOES: um repositório de versões falso, para testar (python -m http.server)
    return os.environ.get("DEGRAVAIA_REPO_VERSOES") or f"https://raw.githubusercontent.com/{REPO_VERSOES}/main"


def url_manifesto():
    # ?t= sempre diferente: o raw.githubusercontent.com guarda cópia por ~5 min e entregaria a versão de antes
    return f"{_base().rstrip('/')}/atualizacao.json?t={int(time.time() * 1000)}"


def url_pacote(versao, arquivo):
    return f"{_base().rstrip('/')}/versoes/{arquivo}"


def numeros(versao):
    return tuple(int(n) for n in re.findall(r"\d+", versao)[:3])


def _baixar(url, timeout):
    pedido = Request(url, headers={"User-Agent": f"{NOME_TECNICO}/{VERSAO}", "Cache-Control": "no-cache"})
    with urlopen(pedido, timeout=timeout) as r:
        return r.read()


def baixar_conferido(url, destino, sha256, timeout=120):
    """Baixa um arquivo e só o põe no lugar (via .novo) se o SHA-256 conferir com o esperado."""
    dados = _baixar(url, timeout)
    if hashlib.sha256(dados).hexdigest() != sha256:
        raise AtualizacaoInvalida(f"O arquivo baixado não confere com o SHA-256 esperado: {url}")
    destino = Path(destino)
    destino.parent.mkdir(parents=True, exist_ok=True)
    novo = destino.with_name(destino.name + ".novo")
    novo.write_bytes(dados)
    novo.replace(destino)
    return destino


class SemConexao(Exception):
    pass


def verificar(timeout=6, avisar_sem_conexao=False):
    """A versão nova publicada, se houver; None sem internet, sem novidade ou se o
    endereço ainda não existir. Com avisar_sem_conexao, a falha de rede vira SemConexao."""
    if not REPO_VERSOES and not os.environ.get("DEGRAVAIA_REPO_VERSOES"):
        return None
    try:
        dados = _baixar(url_manifesto(), timeout)
    except Exception as erro:
        if avisar_sem_conexao:
            raise SemConexao(str(erro)) from erro
        return None
    try:
        m = json.loads(dados)
        if not re.fullmatch(r"\d+\.\d+\.\d+", m["versao"]) or not re.fullmatch(r"[0-9a-f]{64}", m["sha256"]) \
                or not re.fullmatch(r"[A-Za-z0-9._-]+\.zip", m["arquivo"]):
            return None
    except Exception:
        return None
    if numeros(m["versao"]) <= numeros(VERSAO):
        return None
    try:
        minimo = int(m.get("lancador_minimo", 0))
    except (TypeError, ValueError):
        minimo = 0
    return {"versao": m["versao"], "arquivo": m["arquivo"], "sha256": m["sha256"],
            "tamanho": m.get("tamanho"), "novidades": str(m.get("novidades", ""))[:4000],
            "lancador_minimo": minimo}


def _caminho_seguro(nome):
    """Caminho relativo dentro da pasta do app, fora das pastas protegidas; None se não for."""
    if not nome.startswith("DegravaIA/") or nome.endswith("/"):
        return None
    rel = nome[len("DegravaIA/"):]
    partes = rel.split("/")
    if not rel or rel.startswith("/") or "\\" in rel or ":" in rel or any(p in ("", ".", "..") for p in partes):
        return None
    if any(rel.startswith(p) for p in PROTEGIDAS):
        return None
    return rel


def ler_pacote(dados_zip):
    """{caminho relativo: conteúdo} do pacote de código, recusando qualquer coisa estranha."""
    import io

    novos = {}
    with zipfile.ZipFile(io.BytesIO(dados_zip)) as z:
        for info in z.infolist():
            if info.is_dir():
                continue
            rel = _caminho_seguro(info.filename)
            if rel is None:
                raise AtualizacaoInvalida(f"Arquivo fora do lugar no pacote: {info.filename}")
            novos[rel] = z.read(info)
    if "degravaia/config.py" not in novos or LISTA not in novos:
        raise AtualizacaoInvalida("O pacote baixado não é uma atualização do Degrava Lab IA.")
    return novos


def _so_cache(pasta):
    """Pasta vazia ou só com cache do Python (__pycache__/*.pyc): pode sair."""
    return all(f.suffix == ".pyc" for f in Path(pasta).rglob("*") if f.is_file())


# pastas que a 0.3.0 tirou da raiz (código foi para degravaia/; desenvolvimento ficou no repositório).
# A atualização que trouxe a 0.3.0 ainda era a antiga: apagou os arquivos e deixou as pastas.
SOBRAS = ("bibliotecas", "ferramentas", "teste-motores", "testes", "__pycache__")


def limpar_sobras(raiz=RAIZ_APP):
    """Ao iniciar: apaga as pastas antigas que ficaram vazias (nunca uma com arquivos de verdade) e o
    instalador com um nome antigo, quando o "Instalar Degrava Lab IA.bat" já está na pasta."""
    if (Path(raiz) / "Instalar Degrava Lab IA.bat").is_file():
        for antigo in ("Degrava IA.bat", "Degrava Lab.bat", "Degrava Lab IA.bat"):
            (Path(raiz) / antigo).unlink(missing_ok=True)
    for nome in SOBRAS:
        pasta = Path(raiz) / nome
        if pasta.is_dir() and _so_cache(pasta):
            shutil.rmtree(pasta, ignore_errors=True)


def aplicar(novos, raiz=RAIZ_APP, atualizar_bibliotecas=True, adiar_bibliotecas=False):
    """Troca os arquivos do código. Guarda os atuais em versoes-anteriores/<versão>/ e
    devolve tudo como estava se algo falhar. Devolve a lista de arquivos alterados.
    Com adiar_bibliotecas, o pip fica em .atualizacao/pendente.json para o lançador rodar com o
    servidor fechado (concluir_pendente)."""
    raiz = Path(raiz)
    atual = re.search(r'^VERSAO = "([^"]+)"', (raiz / "degravaia" / "config.py").read_text("utf-8"), re.M)
    copia = raiz / "versoes-anteriores" / (atual.group(1) if atual else VERSAO)
    if copia.exists():
        shutil.rmtree(copia)
    antigos = set((raiz / LISTA).read_text("utf-8").splitlines()) - {""} if (raiz / LISTA).is_file() else set()
    sairam = sorted(a for a in antigos - set(novos) if _caminho_seguro("DegravaIA/" + a) and (raiz / a).is_file())
    mudam = [rel for rel, conteudo in sorted(novos.items())
             if not (raiz / rel).is_file() or (raiz / rel).read_bytes() != conteudo]
    criados = [rel for rel in mudam if not (raiz / rel).exists()]
    for rel in [r for r in mudam if r not in criados] + sairam:  # cópia do que vai mudar ou sair
        (copia / rel).parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(raiz / rel, copia / rel)
    if (raiz / LISTA).is_file() and not (copia / LISTA).is_file():  # a lista desta versão vai junto (para voltar)
        copia.mkdir(parents=True, exist_ok=True)
        shutil.copy2(raiz / LISTA, copia / LISTA)

    def desfazer():
        for rel in criados:
            (raiz / rel).unlink(missing_ok=True)
        if copia.is_dir():
            for f in copia.rglob("*"):
                if f.is_file():
                    destino = raiz / f.relative_to(copia)
                    destino.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(f, destino)

    requisitos_mudaram = "degravaia/requirements.txt" in mudam
    try:
        for rel in mudam:
            destino = raiz / rel
            destino.parent.mkdir(parents=True, exist_ok=True)
            temporario = destino.with_name(destino.name + ".novo")
            temporario.write_bytes(novos[rel])
            temporario.replace(destino)  # troca de uma vez: nunca fica arquivo pela metade
        for rel in sairam:
            (raiz / rel).unlink(missing_ok=True)
            pasta = (raiz / rel).parent
            while pasta != raiz and pasta.is_dir() and _so_cache(pasta):  # pasta que ficou vazia sai junto
                shutil.rmtree(pasta, ignore_errors=True)
                pasta = pasta.parent
        if requisitos_mudaram and atualizar_bibliotecas and adiar_bibliotecas:
            pendente = raiz / ".atualizacao" / "pendente.json"
            pendente.parent.mkdir(exist_ok=True)
            pendente.write_text(json.dumps({"versao_anterior": copia.name, "etapas": ["bibliotecas"]}), "utf-8")
        elif requisitos_mudaram and atualizar_bibliotecas:
            _pip(raiz, check=True)
    except BaseException:
        desfazer()
        raise
    if copia.is_dir():  # só a última versão fica guardada; as mais antigas saem
        for antiga in copia.parent.iterdir():
            if antiga.is_dir() and antiga.name != copia.name:
                shutil.rmtree(antiga, ignore_errors=True)
    return mudam + sairam


def _pip(raiz, check=True, saida=None):
    """pip install das bibliotecas do requirements.txt (pelo python.exe, sem janela preta)."""
    python = Path(sys.executable)
    if python.name.lower() == "pythonw.exe":  # o lançador roda no pythonw; o pip precisa de console
        python = python.with_name("python.exe")
    return subprocess.run([str(python), "-m", "pip", "install", "--no-warn-script-location",
                           "--find-links", str(raiz / "degravaia" / "bibliotecas"),
                           "-r", str(raiz / "degravaia" / "requirements.txt")],
                          check=check, cwd=raiz, stdout=saida, stderr=subprocess.STDOUT if saida else None,
                          creationflags=0x08000000 if os.name == "nt" else 0)


def concluir_pendente(avisar=print, raiz=RAIZ_APP, registrar=None):
    """Faz, com o servidor fechado, o que a atualização deixou em .atualizacao/pendente.json (o lançador
    chama ao abrir e depois de cada atualização). Avisa cada etapa com avisar("texto"). Se uma etapa
    falhar, volta para a versão anterior. Devolve False só nesse caso."""
    raiz = Path(raiz)
    pendente = raiz / ".atualizacao" / "pendente.json"
    try:
        dados = json.loads(pendente.read_text("utf-8"))
    except (OSError, ValueError):
        pendente.unlink(missing_ok=True)
        return True
    if "restaurar" in dados.get("etapas", []):
        try:
            return voltar_para(str(dados.get("restaurar", "")), avisar, raiz, registrar)
        finally:
            pendente.unlink(missing_ok=True)
    try:
        for etapa in dados.get("etapas", []):
            if etapa == "bibliotecas":
                avisar("Instalando as bibliotecas novas do programa…")
                r = _pip(raiz, check=False, saida=subprocess.PIPE)
                if registrar:
                    registrar(r.stdout.decode("utf-8", "replace") if r.stdout else "")
                if r.returncode != 0:
                    raise RuntimeError(f"o pip terminou com o código {r.returncode}")
        avisar("Atualização aplicada.")
        return True
    except Exception as erro:
        avisar(f"Não foi possível concluir a atualização ({erro}). Voltando para a versão anterior…")
        anterior = raiz / "versoes-anteriores" / str(dados.get("versao_anterior", ""))
        if dados.get("versao_anterior") and anterior.is_dir():
            for f in anterior.rglob("*"):
                if f.is_file():
                    destino = raiz / f.relative_to(anterior)
                    destino.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(f, destino)
            if "bibliotecas" in dados.get("etapas", []):
                _pip(raiz, check=False, saida=subprocess.PIPE)  # as bibliotecas da versão anterior
        return False
    finally:
        pendente.unlink(missing_ok=True)


def instalar(nova, raiz=RAIZ_APP):
    """Baixa, confere e aplica a versão `nova` (resultado de verificar())."""
    dados_zip = _baixar(url_pacote(nova["versao"], nova["arquivo"]), timeout=120)
    if nova.get("tamanho") is not None and len(dados_zip) != int(nova["tamanho"]):
        raise AtualizacaoInvalida("O arquivo baixado não tem o tamanho publicado. Nada foi alterado.")
    if hashlib.sha256(dados_zip).hexdigest() != nova["sha256"]:
        raise AtualizacaoInvalida("O arquivo baixado não confere com o SHA-256 publicado. Nada foi alterado.")
    novos = ler_pacote(dados_zip)
    versao_pacote = re.search(r'^VERSAO = "([^"]+)"', novos["degravaia/config.py"].decode("utf-8"), re.M)
    if not versao_pacote or versao_pacote.group(1) != nova["versao"]:
        raise AtualizacaoInvalida("A versão dentro do pacote não é a anunciada. Nada foi alterado.")
    return aplicar(novos, raiz, adiar_bibliotecas=lancador_em_uso() >= 2)


def versao_guardada(raiz=RAIZ_APP):
    """A versão guardada em versoes-anteriores/ (só fica uma), se for anterior à atual; None se não houver."""
    pasta = Path(raiz) / "versoes-anteriores"
    try:
        atual = re.search(r'^VERSAO = "([^"]+)"', (Path(raiz) / "degravaia" / "config.py").read_text("utf-8"), re.M)
        atual = numeros(atual.group(1)) if atual else numeros(VERSAO)
        versoes = [p.name for p in pasta.iterdir()
                   if p.is_dir() and re.fullmatch(r"\d+\.\d+\.\d+", p.name) and numeros(p.name) < atual]
    except OSError:
        return None
    return max(versoes, key=numeros) if versoes else None


def pendente_restauracao(raiz=RAIZ_APP):
    """A versão para a qual o pendente.json pede para voltar (o lançador muda os textos da tela); None se não for."""
    try:
        dados = json.loads((Path(raiz) / ".atualizacao" / "pendente.json").read_text("utf-8"))
    except (OSError, ValueError):
        return None
    return str(dados.get("restaurar")) if "restaurar" in dados.get("etapas", []) else None


def preparar_restauracao(versao, raiz=RAIZ_APP):
    """Deixa o pedido de voltar para `versao` para o lançador fazer com o servidor fechado (código 3)."""
    if versao != versao_guardada(raiz):
        raise AtualizacaoInvalida("Não há esta versão guardada. Recarregue a página.")
    pendente = Path(raiz) / ".atualizacao" / "pendente.json"
    pendente.parent.mkdir(exist_ok=True)
    pendente.write_text(json.dumps({"etapas": ["restaurar"], "restaurar": versao}), "utf-8")


def _lista(arquivo):
    return set(Path(arquivo).read_text("utf-8").splitlines()) - {""} if Path(arquivo).is_file() else set()


def voltar_para(versao, avisar=print, raiz=RAIZ_APP, registrar=None):
    """Volta para a versão guardada em versoes-anteriores/<versao>/, com o servidor fechado: devolve os arquivos
    guardados (via .novo), tira os que a versão atual tem e a guardada não tinha (pelas listas arquivos-do-app.txt;
    sem a lista da guardada, não tira nada), roda o pip se o requirements.txt mudou e apaga a cópia usada.
    Se algo falhar, devolve tudo como estava (inclusive as bibliotecas). Devolve True se voltou."""
    raiz = Path(raiz)
    copia = raiz / "versoes-anteriores" / versao
    if not re.fullmatch(r"\d+\.\d+\.\d+", versao) or not copia.is_dir():
        avisar("Não há versão anterior guardada.")
        return False
    guardados = {}
    for f in sorted(copia.rglob("*")):
        if f.is_file():
            rel = f.relative_to(copia).as_posix()
            if _caminho_seguro("DegravaIA/" + rel) is None:
                avisar(f"A cópia guardada tem um arquivo fora do lugar ({rel}). Nada foi alterado.")
                return False
            guardados[rel] = f.read_bytes()
    lista_atual = _lista(raiz / LISTA)
    lista_antiga = _lista(copia / LISTA) if (copia / LISTA).is_file() else lista_atual
    sair = sorted(a for a in lista_atual - lista_antiga - set(guardados)
                  if _caminho_seguro("DegravaIA/" + a) and (raiz / a).is_file())
    mudam = [rel for rel, conteudo in guardados.items()
             if not (raiz / rel).is_file() or (raiz / rel).read_bytes() != conteudo]
    criados = [rel for rel in mudam if not (raiz / rel).exists()]
    reserva = raiz / ".atualizacao" / "antes-de-voltar"  # a versão atual, para desfazer
    shutil.rmtree(reserva, ignore_errors=True)
    for rel in [r for r in mudam if r not in criados] + sair:
        (reserva / rel).parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(raiz / rel, reserva / rel)
    requisitos_mudaram = "degravaia/requirements.txt" in mudam

    def desfazer():
        for rel in criados:
            (raiz / rel).unlink(missing_ok=True)
        if reserva.is_dir():
            for f in reserva.rglob("*"):
                if f.is_file():
                    destino = raiz / f.relative_to(reserva)
                    destino.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(f, destino)

    avisar(f"Voltando para a versão {versao}…")
    try:
        for rel in mudam:
            destino = raiz / rel
            destino.parent.mkdir(parents=True, exist_ok=True)
            temporario = destino.with_name(destino.name + ".novo")
            temporario.write_bytes(guardados[rel])
            temporario.replace(destino)
        for rel in sair:
            (raiz / rel).unlink(missing_ok=True)
            pasta = (raiz / rel).parent
            while pasta != raiz and pasta.is_dir() and _so_cache(pasta):
                shutil.rmtree(pasta, ignore_errors=True)
                pasta = pasta.parent
        if requisitos_mudaram:
            avisar(f"Instalando as bibliotecas da versão {versao}…")
            r = _pip(raiz, check=False, saida=subprocess.PIPE)
            if registrar:
                registrar(r.stdout.decode("utf-8", "replace") if r.stdout else "")
            if r.returncode != 0:
                raise RuntimeError(f"o pip terminou com o código {r.returncode}")
    except Exception as erro:
        avisar(f"Não foi possível voltar para a versão {versao} ({erro}). O app continua na versão atual.")
        desfazer()
        if requisitos_mudaram:
            _pip(raiz, check=False, saida=subprocess.PIPE)  # as bibliotecas da versão atual de novo
        shutil.rmtree(reserva, ignore_errors=True)
        return False
    shutil.rmtree(copia, ignore_errors=True)  # a cópia usada sai; para a versão nova, é só atualizar de novo
    shutil.rmtree(reserva, ignore_errors=True)
    avisar(f"Versão {versao} restaurada.")
    return True


def restaurar(raiz=RAIZ_APP):
    """Linha de comando (restaurar-versao, com o app fechado): volta para a versão guardada."""
    versao = versao_guardada(raiz)
    if not versao:
        print("Não há versão anterior guardada.")
        return 1
    if not voltar_para(versao, raiz=raiz):
        return 1
    print("Abra o Degrava Lab IA de novo.")
    return 0
