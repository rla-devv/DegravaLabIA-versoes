"""Configurações fixas do DegravaIA (ver REQUISITOS.md)."""

NOME_APP = "DegravaIA"
VERSAO = "0.1.5"
# Repositório público só com os pacotes de cada versão (o código continua privado).
# Enquanto ele não existir, a procura por atualização não encontra nada e o app segue normal.
REPO_VERSOES = "rla-devv/degravaia-versoes"

# Item 16: motor principal + segunda escuta
MODELO_WHISPER = "Systran/faster-whisper-large-v3"
MODELO_SEGUNDA_ESCUTA = "Edresson/wav2vec2-large-xlsr-coraa-portuguese"
MODELO_DIARIZACAO = "pyannote/speaker-diarization-community-1"

# Passado como `hotwords` para valer em todas as janelas de 30 s (rodada 3 do teste)
PROMPT_HESITACOES = (
    "Eh... então, né, eu eu acho que, ahn, tipo assim, hum, a gente a gente "
    "foi lá e, eh, né, ficou lá."
)

IDIOMA_PADRAO = "pt"
TAXA_AMOSTRAGEM = 16000

# Item 3: pausas a partir deste tamanho viram marcação [pausa Ns]
PAUSA_MINIMA_S = 2.0
# Item 4: palavras abaixo desta probabilidade ficam destacadas na revisão
CONFIANCA_MINIMA = 0.5
# Item 3: a palavra sai do texto e vira [ininteligível HH:MM:SS] (o texto do motor fica como
# sugestão) quando a certeza é menor que este valor E a segunda escuta ouviu outra coisa.
# Rodada 5: 81% das palavras escondidas estavam erradas; só 0,7% das certas foram escondidas.
CONFIANCA_INTELIGIVEL = 0.40
# Sem segunda escuta (idioma que não o português), só certeza muito baixa (73% erradas).
CONFIANCA_INTELIGIVEL_SEM_SEGUNDA = 0.05

# Frases que o Whisper costuma "inventar" em silêncio ou ruído. Nunca são
# removidas: só marcadas como suspeitas para o usuário conferir.
ALUCINACOES_CONHECIDAS = (
    "legendas pela comunidade amara.org",
    "obrigado por assistir",
    "inscreva-se no canal",
    "legenda adriana zanotto",
    "transcrição e legendas",
)

ROTULO_INTERLOCUTOR = "Interlocutor {n}"

# Item 6: onde a cópia melhorada é usada quando o usuário liga a melhoria na importação.
# "ouvir": player da revisão (o original continua disponível); "motores": transcrição,
# segunda escuta e interlocutores. Rodada 6: nos motores a melhoria piorou o áudio bom,
# ganhou pouco no ruim e o nível médio apagou as hesitações; por isso, só para ouvir.
MELHORIA_USO = ("ouvir",)
