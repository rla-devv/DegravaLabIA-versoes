"""Atualização do próprio app (código), pedida pelo usuário na tela inicial.

Como funciona:
- ao abrir, a tela pergunta ao servidor local se há versão nova; ele baixa só o arquivo
  `atualizacao.json` do repositório público REPO_VERSOES (nenhum dado do usuário é
  enviado: é um download comum, como abrir uma página). O publicar.py põe lá o
  atualizacao.json e o pacote em versoes/;
- o usuário confirma; o pacote de código (poucos MB) é baixado e conferido pelo SHA-256;
- os arquivos atuais que mudam vão para versoes-anteriores/<versão>/ e os novos entram
  no lugar. Nunca são tocadas as pastas python/, modelos/, projetos/ e .venv/;
- se o requirements.txt mudou, as bibliotecas são atualizadas. Com o lançador novo (janela.pyw
  ou abrir.py, que avisam por DEGRAVAIA_LANCADOR), isso fica para depois de o servidor sair, em
  .atualizacao/pendente.json: no Windows o pip não troca uma biblioteca que o servidor está usando.
  O lançador chama concluir_pendente() com o servidor fechado e, se der errado, volta tudo;
- o servidor sai com o código 3 e o lançador o abre de novo na mesma janela, já na versão nova.

Sem internet, ou enquanto REPO_VERSOES não existir, a consulta falha em silêncio e o app
segue normalmente. Publicar uma versão: PUBLICAR-VERSAO.md.
"""
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import zipfile
from pathlib import Path
from urllib.request import Request, urlopen

from .config import NOME_TECNICO, REPO_VERSOES, VERSAO

RAIZ_APP = Path(__file__).resolve().parent.parent
LISTA = "arquivos-do-app.txt"  # arquivos do código, gerada pelo empacotar.py; fica na raiz (as versões
# já instaladas a procuram ali para aceitar a atualização), escondida no Windows
PROTEGIDAS = ("python/", "modelos/", "projetos/", ".venv/", "versoes-anteriores/", ".atualizacao/", ".git/",
              "dados-janela/", "Abrir Degrava Lab IA.lnk", "Abrir Degrava Lab.lnk", "Abrir Degrava IA.lnk",
              "Abrir o Degrava IA.lnk")  # o atalho da pasta é da instalação, não do pacote
REINICIAR = 3  # código de saída que pede ao lançador (abrir.py, janela.pyw) para abrir o servidor de novo
PENDENTE = RAIZ_APP / ".atualizacao" / "pendente.json"  # o que falta fazer com o servidor fechado
LANCADOR = 2  # versão do lançador desta versão do app; o publicar.py pode exigir uma mínima (lancador_minimo)


def lancador_em_uso():
    """A versão do lançador que abriu este servidor (0: um antigo, que não avisa)."""
    try:
        return int(os.environ.get("DEGRAVAIA_LANCADOR", "0"))
    except ValueError:
        return 0


class AtualizacaoInvalida(Exception):
    pass


def _base():
    # DEGRAVAIA_REPO_VERSOES: um repositório de versões falso, para testar (python -m http.server)
    return os.environ.get("DEGRAVAIA_REPO_VERSOES") or f"https://raw.githubusercontent.com/{REPO_VERSOES}/main"


def url_manifesto():
    return f"{_base().rstrip('/')}/atualizacao.json"


def url_pacote(versao, arquivo):
    return f"{_base().rstrip('/')}/versoes/{arquivo}"


def numeros(versao):
    return tuple(int(n) for n in re.findall(r"\d+", versao)[:3])


def _baixar(url, timeout):
    pedido = Request(url, headers={"User-Agent": f"{NOME_TECNICO}/{VERSAO}"})
    with urlopen(pedido, timeout=timeout) as r:
        return r.read()


def baixar_conferido(url, destino, sha256, timeout=120):
    """Baixa um arquivo e só o põe no lugar (via .novo) se o SHA-256 conferir com o esperado."""
    dados = _baixar(url, timeout)
    if hashlib.sha256(dados).hexdigest() != sha256:
        raise AtualizacaoInvalida(f"O arquivo baixado não confere com o SHA-256 esperado: {url}")
    destino = Path(destino)
    destino.parent.mkdir(parents=True, exist_ok=True)
    novo = destino.with_name(destino.name + ".novo")
    novo.write_bytes(dados)
    novo.replace(destino)
    return destino


class SemConexao(Exception):
    pass


def verificar(timeout=6, avisar_sem_conexao=False):
    """A versão nova publicada, se houver; None sem internet, sem novidade ou se o
    endereço ainda não existir. Com avisar_sem_conexao, a falha de rede vira SemConexao."""
    if not REPO_VERSOES and not os.environ.get("DEGRAVAIA_REPO_VERSOES"):
        return None
    try:
        dados = _baixar(url_manifesto(), timeout)
    except Exception as erro:
        if avisar_sem_conexao:
            raise SemConexao(str(erro)) from erro
        return None
    try:
        m = json.loads(dados)
        if not re.fullmatch(r"\d+\.\d+\.\d+", m["versao"]) or not re.fullmatch(r"[0-9a-f]{64}", m["sha256"]) \
                or not re.fullmatch(r"[A-Za-z0-9._-]+\.zip", m["arquivo"]):
            return None
    except Exception:
        return None
    if numeros(m["versao"]) <= numeros(VERSAO):
        return None
    try:
        minimo = int(m.get("lancador_minimo", 0))
    except (TypeError, ValueError):
        minimo = 0
    return {"versao": m["versao"], "arquivo": m["arquivo"], "sha256": m["sha256"],
            "tamanho": m.get("tamanho"), "novidades": str(m.get("novidades", ""))[:4000],
            "lancador_minimo": minimo}


def _caminho_seguro(nome):
    """Caminho relativo dentro da pasta do app, fora das pastas protegidas; None se não for."""
    if not nome.startswith("DegravaIA/") or nome.endswith("/"):
        return None
    rel = nome[len("DegravaIA/"):]
    partes = rel.split("/")
    if not rel or rel.startswith("/") or "\\" in rel or ":" in rel or any(p in ("", ".", "..") for p in partes):
        return None
    if any(rel.startswith(p) for p in PROTEGIDAS):
        return None
    return rel


def ler_pacote(dados_zip):
    """{caminho relativo: conteúdo} do pacote de código, recusando qualquer coisa estranha."""
    import io

    novos = {}
    with zipfile.ZipFile(io.BytesIO(dados_zip)) as z:
        for info in z.infolist():
            if info.is_dir():
                continue
            rel = _caminho_seguro(info.filename)
            if rel is None:
                raise AtualizacaoInvalida(f"Arquivo fora do lugar no pacote: {info.filename}")
            novos[rel] = z.read(info)
    if "degravaia/config.py" not in novos or LISTA not in novos:
        raise AtualizacaoInvalida("O pacote baixado não é uma atualização do Degrava Lab IA.")
    return novos


def _so_cache(pasta):
    """Pasta vazia ou só com cache do Python (__pycache__/*.pyc): pode sair."""
    return all(f.suffix == ".pyc" for f in Path(pasta).rglob("*") if f.is_file())


# pastas que a 0.3.0 tirou da raiz (código foi para degravaia/; desenvolvimento ficou no repositório).
# A atualização que trouxe a 0.3.0 ainda era a antiga: apagou os arquivos e deixou as pastas.
SOBRAS = ("bibliotecas", "ferramentas", "teste-motores", "testes", "__pycache__")


def limpar_sobras(raiz=RAIZ_APP):
    """Ao iniciar: apaga as pastas antigas que ficaram vazias (nunca uma com arquivos de verdade) e o
    instalador com um nome antigo do app, quando o "Degrava Lab IA.bat" já está na pasta."""
    if (Path(raiz) / "Degrava Lab IA.bat").is_file():
        for antigo in ("Degrava IA.bat", "Degrava Lab.bat"):
            (Path(raiz) / antigo).unlink(missing_ok=True)
    for nome in SOBRAS:
        pasta = Path(raiz) / nome
        if pasta.is_dir() and _so_cache(pasta):
            shutil.rmtree(pasta, ignore_errors=True)


def aplicar(novos, raiz=RAIZ_APP, atualizar_bibliotecas=True, adiar_bibliotecas=False):
    """Troca os arquivos do código. Guarda os atuais em versoes-anteriores/<versão>/ e
    devolve tudo como estava se algo falhar. Devolve a lista de arquivos alterados.
    Com adiar_bibliotecas, o pip fica em .atualizacao/pendente.json para o lançador rodar com o
    servidor fechado (concluir_pendente)."""
    raiz = Path(raiz)
    atual = re.search(r'^VERSAO = "([^"]+)"', (raiz / "degravaia" / "config.py").read_text("utf-8"), re.M)
    copia = raiz / "versoes-anteriores" / (atual.group(1) if atual else VERSAO)
    if copia.exists():
        shutil.rmtree(copia)
    antigos = set((raiz / LISTA).read_text("utf-8").splitlines()) - {""} if (raiz / LISTA).is_file() else set()
    sairam = sorted(a for a in antigos - set(novos) if _caminho_seguro("DegravaIA/" + a) and (raiz / a).is_file())
    mudam = [rel for rel, conteudo in sorted(novos.items())
             if not (raiz / rel).is_file() or (raiz / rel).read_bytes() != conteudo]
    criados = [rel for rel in mudam if not (raiz / rel).exists()]
    for rel in [r for r in mudam if r not in criados] + sairam:  # cópia do que vai mudar ou sair
        (copia / rel).parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(raiz / rel, copia / rel)

    def desfazer():
        for rel in criados:
            (raiz / rel).unlink(missing_ok=True)
        if copia.is_dir():
            for f in copia.rglob("*"):
                if f.is_file():
                    destino = raiz / f.relative_to(copia)
                    destino.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(f, destino)

    requisitos_mudaram = "degravaia/requirements.txt" in mudam
    try:
        for rel in mudam:
            destino = raiz / rel
            destino.parent.mkdir(parents=True, exist_ok=True)
            temporario = destino.with_name(destino.name + ".novo")
            temporario.write_bytes(novos[rel])
            temporario.replace(destino)  # troca de uma vez: nunca fica arquivo pela metade
        for rel in sairam:
            (raiz / rel).unlink(missing_ok=True)
            pasta = (raiz / rel).parent
            while pasta != raiz and pasta.is_dir() and _so_cache(pasta):  # pasta que ficou vazia sai junto
                shutil.rmtree(pasta, ignore_errors=True)
                pasta = pasta.parent
        if requisitos_mudaram and atualizar_bibliotecas and adiar_bibliotecas:
            pendente = raiz / ".atualizacao" / "pendente.json"
            pendente.parent.mkdir(exist_ok=True)
            pendente.write_text(json.dumps({"versao_anterior": copia.name, "etapas": ["bibliotecas"]}), "utf-8")
        elif requisitos_mudaram and atualizar_bibliotecas:
            _pip(raiz, check=True)
    except BaseException:
        desfazer()
        raise
    return mudam + sairam


def _pip(raiz, check=True, saida=None):
    """pip install das bibliotecas do requirements.txt (pelo python.exe, sem janela preta)."""
    python = Path(sys.executable)
    if python.name.lower() == "pythonw.exe":  # o lançador roda no pythonw; o pip precisa de console
        python = python.with_name("python.exe")
    return subprocess.run([str(python), "-m", "pip", "install", "--no-warn-script-location",
                           "--find-links", str(raiz / "degravaia" / "bibliotecas"),
                           "-r", str(raiz / "degravaia" / "requirements.txt")],
                          check=check, cwd=raiz, stdout=saida, stderr=subprocess.STDOUT if saida else None,
                          creationflags=0x08000000 if os.name == "nt" else 0)


def concluir_pendente(avisar=print, raiz=RAIZ_APP, registrar=None):
    """Faz, com o servidor fechado, o que a atualização deixou em .atualizacao/pendente.json (o lançador
    chama ao abrir e depois de cada atualização). Avisa cada etapa com avisar("texto"). Se uma etapa
    falhar, volta para a versão anterior. Devolve False só nesse caso."""
    raiz = Path(raiz)
    pendente = raiz / ".atualizacao" / "pendente.json"
    try:
        dados = json.loads(pendente.read_text("utf-8"))
    except (OSError, ValueError):
        pendente.unlink(missing_ok=True)
        return True
    try:
        for etapa in dados.get("etapas", []):
            if etapa == "bibliotecas":
                avisar("Instalando as bibliotecas novas do programa…")
                r = _pip(raiz, check=False, saida=subprocess.PIPE)
                if registrar:
                    registrar(r.stdout.decode("utf-8", "replace") if r.stdout else "")
                if r.returncode != 0:
                    raise RuntimeError(f"o pip terminou com o código {r.returncode}")
        avisar("Atualização aplicada.")
        return True
    except Exception as erro:
        avisar(f"Não foi possível concluir a atualização ({erro}). Voltando para a versão anterior…")
        anterior = raiz / "versoes-anteriores" / str(dados.get("versao_anterior", ""))
        if dados.get("versao_anterior") and anterior.is_dir():
            for f in anterior.rglob("*"):
                if f.is_file():
                    destino = raiz / f.relative_to(anterior)
                    destino.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(f, destino)
            if "bibliotecas" in dados.get("etapas", []):
                _pip(raiz, check=False, saida=subprocess.PIPE)  # as bibliotecas da versão anterior
        return False
    finally:
        pendente.unlink(missing_ok=True)


def instalar(nova, raiz=RAIZ_APP):
    """Baixa, confere e aplica a versão `nova` (resultado de verificar())."""
    dados_zip = _baixar(url_pacote(nova["versao"], nova["arquivo"]), timeout=120)
    if hashlib.sha256(dados_zip).hexdigest() != nova["sha256"]:
        raise AtualizacaoInvalida("O arquivo baixado não confere com o SHA-256 publicado. Nada foi alterado.")
    novos = ler_pacote(dados_zip)
    versao_pacote = re.search(r'^VERSAO = "([^"]+)"', novos["degravaia/config.py"].decode("utf-8"), re.M)
    if not versao_pacote or versao_pacote.group(1) != nova["versao"]:
        raise AtualizacaoInvalida("A versão dentro do pacote não é a anunciada. Nada foi alterado.")
    return aplicar(novos, raiz, adiar_bibliotecas=lancador_em_uso() >= 2)


def restaurar(raiz=RAIZ_APP):
    """Volta para a versão guardada mais recente (linha de comando: restaurar-versao)."""
    pasta = Path(raiz) / "versoes-anteriores"
    versoes = sorted((p for p in pasta.iterdir() if p.is_dir()), key=lambda p: numeros(p.name)) if pasta.is_dir() else []
    if not versoes:
        print("Não há versão anterior guardada.")
        return 1
    anterior = versoes[-1]
    novos = {f.relative_to(anterior).as_posix(): f.read_bytes() for f in anterior.rglob("*") if f.is_file()}
    for rel, conteudo in novos.items():
        destino = Path(raiz) / rel
        destino.parent.mkdir(parents=True, exist_ok=True)
        destino.write_bytes(conteudo)
    print(f"Arquivos da versão {anterior.name} restaurados ({len(novos)}). Abra o Degrava Lab IA de novo.")
    return 0
