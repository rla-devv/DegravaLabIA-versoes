"""Degrava Lab IA em janela própria do Windows: o lançador (o atalho abre este arquivo).

Duas partes, em dois processos (o mesmo modelo do Realce IA):
    lançador ─ python\\pythonw.exe degravaia\\janela.pyw (sem a janela preta)
        abre a janela (pywebview → WebView2, o componente do Edge do Windows 10 e 11) e nunca a fecha
        sozinho; sobe o servidor como processo filho e o vigia;
    servidor ─ python -m degravaia revisar --porta N: a tela, em http://127.0.0.1:N/

O lançador:
    1. mostra a página de espera (logo, nome, frase do cabeçalho e um círculo girando);
    2. escolhe a porta uma vez (a 8765, se livre; senão outra livre) e a usa em todas as reaberturas;
    3. sobe o servidor sem janela (CREATE_NO_WINDOW), com a saída em registro.txt;
    4. espera o GET /api/saude responder (até 5 min) e carrega o endereço na mesma janela;
    5. servidor saiu com o código 3 (atualização instalada): mostra "Aplicando a atualização…", faz o
       que precisa do servidor fechado (atualizacao.concluir_pendente: o pip), mostrando cada etapa, e
       abre o servidor de novo na mesma porta;
    6. servidor caiu: "O app parou inesperadamente. Abrindo de novo…" e reabre em 2 s, até 5 vezes em
       10 min; depois, uma página de erro com o caminho do registro;
    7. ao abrir, conclui uma etapa de atualização que tenha ficado pela metade;
    8. janela fechada: encerra o servidor e tudo o que ele abriu (uma importação em andamento);
    9. sem o pywebview (ou sem o WebView2), ou com --navegador, abre como antes: janela preta e
       navegador, uma vez só (degravaia/abrir.py; nas reaberturas a própria página recarrega).
O ícone fica na bandeja do sistema (perto do relógio), com "Abrir o Degrava Lab IA" e "Fechar o Degrava Lab IA".
"""
import html
import os
import socket
import subprocess
import sys
import threading
import time
from pathlib import Path
from urllib.request import urlopen

# rodado como arquivo (pythonw janela.pyw): a pasta do Degrava Lab IA no caminho de importação, no lugar
# da pasta degravaia/ (os módulos dela só devem ser vistos como degravaia.*)
_PASTA = Path(__file__).resolve().parent
sys.path[:] = [p for p in sys.path if Path(p or ".").resolve() != _PASTA]
sys.path.insert(0, str(_PASTA.parent))
from degravaia.abrir import GRUPO_PROPRIO, REGISTRO, REINICIAR, abrir_registro, anotar  # noqa: E402
from degravaia.atualizacao import LANCADOR, concluir_pendente  # noqa: E402
from degravaia.instalar import AQUI, ambiente_nvidia, python_do_app  # noqa: E402

PORTA_PADRAO = 8765  # a mesma de sempre: o tema e o que a página guarda ficam ligados a ela
SEM_CONSOLE = 0x08000000 if os.name == "nt" else 0  # CREATE_NO_WINDOW: o servidor não abre janela preta
DADOS_JANELA = AQUI / "dados-janela"  # tema, guia fechado… (o que a página guarda no navegador)
ESPERA_S = 300  # quanto o lançador espera o servidor responder
QUEDAS_MAX, QUEDAS_JANELA_S = 5, 600

# nas cores do app (tokens do app.css: claro e escuro, conforme o Windows)
ESTILO = """<style>:root{--bg:#f2f6f5;--glow:#dcefeb;--ink:#102022;--muted:#5a6b6d;--accent:#0c7a70;--line:#d9e3e1;
--bad:#b3261e;color-scheme:light}@media(prefers-color-scheme:dark){:root{--bg:#0c1315;--glow:#12302c;--ink:#e5eeed;
--muted:#92a5a6;--accent:#45cfbe;--line:#263436;--bad:#ff7d74;color-scheme:dark}}
html,body{height:100%;margin:0;color:var(--ink);font:14px/1.5 "Segoe UI Variable Text","Segoe UI",system-ui,sans-serif;
background:radial-gradient(1100px 420px at 15% -120px,var(--glow),transparent 70%),var(--bg)}
body{display:grid;place-items:center}.caixa{text-align:center;max-width:560px;padding:24px}
.logo{width:96px;height:96px;margin:0 auto 12px;display:block;border-radius:20px}
.nome{margin:0;font-size:1.35rem;font-weight:750;letter-spacing:-.02em}
.frase{margin:2px 0 22px;color:var(--muted);font-size:.86rem}h2{margin:0 0 6px;font-size:1.1rem;font-weight:650}
p{color:var(--muted);margin:6px 0}.giro{width:30px;height:30px;margin:18px auto 0;border-radius:50%;
border:3px solid var(--line);border-top-color:var(--accent);animation:g 1s linear infinite}
@keyframes g{to{transform:rotate(360deg)}}@media(prefers-reduced-motion:reduce){.giro{animation-duration:3s}}
ul{list-style:none;padding:0;margin:14px auto 0;text-align:left;display:inline-block;color:var(--muted);font-size:.9rem}
li::before{content:"✓ ";color:var(--accent)}li.atual::before{content:"• "}li.atual{color:var(--ink)}
code{font-family:Consolas,monospace;font-size:.85em;color:var(--accent);word-break:break-all}.erro h2{color:var(--bad)}</style>"""


def _logo():
    """O ícone do app embutido na página (a janela ainda não tem servidor para buscá-lo)."""
    import base64

    try:
        dados = (AQUI / "degravaia" / "web" / "icone.png").read_bytes()
        return f'<img class="logo" alt="" src="data:image/png;base64,{base64.b64encode(dados).decode()}">'
    except OSError:
        return ""


LOGO = _logo()


def pagina(titulo, texto="", etapas=(), girando=True, erro=False):
    """A página de espera do lançador: logo, nome, frase do cabeçalho, o que está acontecendo."""
    lista = ""
    if etapas:
        itens = [f'<li class="{"atual" if i == len(etapas) - 1 and girando else ""}">{html.escape(e)}</li>'
                 for i, e in enumerate(etapas)]
        lista = f"<ul>{''.join(itens)}</ul>"
    return (f'<!doctype html><meta charset="utf-8">{ESTILO}<div class="caixa{" erro" if erro else ""}">{LOGO}'
            f'<p class="nome">Degrava Lab IA</p><p class="frase">Transcrição de áudios e vídeos diretamente no seu '
            f'computador.</p><h2>{html.escape(titulo)}</h2>{texto}{lista}'
            f'{"<div class=giro></div>" if girando else ""}</div>')


CARREGANDO = pagina("Abrindo o Degrava Lab IA…", "<p>Tudo roda no seu computador. Nenhum dado é enviado para a internet.</p>")


def pagina_de_erro(texto):
    return pagina("Não foi possível abrir o Degrava Lab IA", f"<p>{html.escape(texto)}</p><p>O detalhe está no arquivo:"
                  f"<br><code>{html.escape(str(REGISTRO))}</code></p><p>Feche o Degrava Lab IA e abra de novo. Se continuar,"
                  " envie esse arquivo para o suporte.</p>", girando=False, erro=True)


def responde(porta, timeout=1):
    """O servidor do Degrava Lab IA responde nesta porta? (o /api/saude; numa versão antiga, a lista)"""
    for caminho in ("api/saude", "api/projetos"):
        try:
            with urlopen(f"http://127.0.0.1:{porta}/{caminho}", timeout=timeout) as r:
                if r.status == 200:
                    return True
        except Exception:
            continue
    return False


def escolher_porta():
    """(porta, já aberto): a 8765, se livre (ou se já for um Degrava Lab IA aberto); senão, outra livre."""
    if responde(PORTA_PADRAO):
        return PORTA_PADRAO, True
    for porta in (PORTA_PADRAO, 0):
        with socket.socket() as s:
            if os.name != "nt":  # como o servidor: uma porta recém-fechada (em espera) não conta como ocupada
                s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            try:
                s.bind(("127.0.0.1", porta))
                return s.getsockname()[1], False
            except OSError:
                continue
    return PORTA_PADRAO, False


class Lancador:
    """Sobe o servidor, vigia, reabre e mostra cada passo na janela. `janela` só precisa de load_html e
    load_url (os testes passam uma falsa)."""

    def __init__(self, janela, registro, porta, comando=None):
        self.janela = janela
        self.registro = registro
        self.porta = porta
        self.endereco = f"http://127.0.0.1:{porta}/"
        self.comando = comando or [str(python_do_app()), "-u", "-m", "degravaia", "revisar", "--nao-abrir",
                                   "--porta", str(porta)]
        self.proc = None
        self.fechando = False
        self.etapas = []

    def iniciar(self):
        threading.Thread(target=self._vigiar, daemon=True).start()

    def _mostrar(self, *args, **kw):
        if not self.fechando:
            self.janela.load_html(pagina(*args, **kw))

    def _etapa(self, texto):
        anotar(self.registro, texto)
        self.etapas.append(texto)
        self._mostrar("Aplicando a atualização…", "<p>Não feche o Degrava Lab IA.</p>", self.etapas)

    def _registrar(self, texto):
        for linha in texto.splitlines():
            self.registro.write(f"{time.strftime('%Y-%m-%d %H:%M:%S')} {linha}\n")
        self.registro.flush()

    def _subir(self):
        self.proc = subprocess.Popen(
            self.comando, env=dict(ambiente_nvidia(), DEGRAVAIA_JANELA="1", DEGRAVAIA_LANCADOR=str(LANCADOR)),
            cwd=AQUI, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, stdin=subprocess.DEVNULL, text=True,
            encoding="utf-8", errors="replace", creationflags=GRUPO_PROPRIO | SEM_CONSOLE)
        proc = self.proc

        def copiar_saida():
            for linha in proc.stdout:
                self.registro.write(f"{time.strftime('%Y-%m-%d %H:%M:%S')} {linha}")
                self.registro.flush()

        threading.Thread(target=copiar_saida, daemon=True).start()

    def _esperar(self):
        """Espera o servidor responder: True quando responde; False se ele saiu ou demorou demais."""
        limite = time.time() + ESPERA_S
        while time.time() < limite and not self.fechando:
            if self.proc.poll() is not None:
                return False
            if responde(self.porta):
                return True
            time.sleep(0.5)
        return False

    def _concluir_pendente(self):
        ok = concluir_pendente(self._etapa, AQUI, registrar=self._registrar)
        if not ok:
            anotar(self.registro, "Atualização desfeita: o app volta na versão anterior.")

    def _vigiar(self):
        if (AQUI / ".atualizacao" / "pendente.json").exists():  # ficou pela metade da última vez
            self.etapas = []
            self._concluir_pendente()
        quedas = []
        while not self.fechando:
            self._subir()
            if self._esperar():
                self.janela.load_url(self.endereco)
            elif self.proc.poll() is None and not self.fechando:  # vivo, mas não respondeu em 5 min
                anotar(self.registro, "O programa da tela não respondeu.")
                self._mostrar_erro("O programa da tela não respondeu.")
                self.parar()
                return
            codigo = self.proc.wait()
            if self.fechando:
                return
            if codigo == REINICIAR:
                anotar(self.registro, "Atualização instalada: aplicando e abrindo a versão nova…")
                self.etapas = ["Arquivos da versão nova instalados."]
                self._mostrar("Aplicando a atualização…", "<p>Não feche o Degrava Lab IA.</p>", self.etapas)
                self._concluir_pendente()
                self.etapas.append("Abrindo a versão nova…")
                self._mostrar("Aplicando a atualização…", "", self.etapas)
                continue
            quedas = [t for t in quedas if time.time() - t < QUEDAS_JANELA_S] + [time.time()]
            anotar(self.registro, f"O programa da tela parou (código {codigo}).")
            if len(quedas) > QUEDAS_MAX:
                anotar(self.registro, "Parou várias vezes seguidas; desistindo.")
                self._mostrar_erro("O programa parou várias vezes seguidas.")
                return
            self._mostrar("O app parou inesperadamente. Abrindo de novo…")
            time.sleep(2)

    def _mostrar_erro(self, texto):
        if not self.fechando:
            self.janela.load_html(pagina_de_erro(texto))

    def parar(self):
        """Encerra o servidor e tudo o que ele abriu (terminate; se não sair em 5 s, kill)."""
        self.fechando = True
        proc = self.proc
        if not proc or proc.poll() is not None:
            return
        if os.name == "nt":  # a árvore toda: inclusive uma importação em andamento (processo filho)
            subprocess.run(["taskkill", "/T", "/F", "/PID", str(proc.pid)], capture_output=True,
                           creationflags=SEM_CONSOLE)
        else:
            proc.terminate()
        try:
            proc.wait(timeout=5)
        except subprocess.TimeoutExpired:
            proc.kill()
            proc.wait()


def modo_navegador():
    """Como antes: janela preta + navegador padrão (degravaia/abrir.py)."""
    novo_console = subprocess.CREATE_NEW_CONSOLE if os.name == "nt" else 0
    subprocess.Popen([str(python_do_app()), "-m", "degravaia.abrir", "--navegador"], cwd=AQUI,
                     creationflags=novo_console)


def principal():
    os.chdir(AQUI)
    if "--navegador" in sys.argv:
        return modo_navegador()
    try:
        import webview
    except ImportError:
        return modo_navegador()

    registro = abrir_registro()
    anotar(registro, "=== Degrava Lab IA aberto (janela própria)")
    if os.name == "nt":  # app próprio na barra de tarefas (senão o Windows agrupa como "Python", com o ícone dele)
        try:
            import ctypes

            ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID("RLAdev.DegravaIA")
        except Exception:
            pass
    porta, ja_aberto = escolher_porta()  # se já houver um Degrava Lab IA aberto, esta janela usa o mesmo servidor

    webview.settings["ALLOW_DOWNLOADS"] = True  # documentos exportados
    webview.settings["OPEN_EXTERNAL_LINKS_IN_BROWSER"] = True  # "Contribuir pelo Mercado Pago" abre no navegador
    from degravaia.instalar import ICONE as icone
    janela = webview.create_window("Degrava Lab IA", html=CARREGANDO, width=1400, height=900, min_size=(1000, 680),
                                   background_color="#09142c")

    bandeja = {}

    def icone_e_bandeja():
        """No Windows (pythonnet, que vem com o pywebview): o ícone na bandeja do sistema, com menu.
        O ícone da janela e da barra de tarefas o pywebview já põe (parâmetro icon do start)."""
        try:
            from System import Action
            from System.Drawing import Icon
            from System.Windows.Forms import (ContextMenuStrip, FormWindowState, MouseButtons, NotifyIcon,
                                              SystemInformation, ToolStripMenuItem)

            formulario = janela.native

            def mostrar(*_):
                formulario.Show()
                if formulario.WindowState == FormWindowState.Minimized:
                    formulario.WindowState = FormWindowState.Normal
                formulario.Activate()

            def ao_clicar(_origem, evento):
                if evento.Button == MouseButtons.Left:
                    mostrar()

            def montar():  # na linha de execução da janela, como o Windows exige
                try:
                    formulario.Icon = Icon(str(icone))
                except Exception as erro:  # o pywebview já pôs o ícone; isto só reforça
                    anotar(registro, f"Ícone da janela: {erro}")
                icone_bandeja = NotifyIcon()
                icone_bandeja.Icon = Icon(str(icone), SystemInformation.SmallIconSize)  # o tamanho da bandeja
                icone_bandeja.Text = "Degrava Lab IA"
                menu = ContextMenuStrip()
                abrir = ToolStripMenuItem("Abrir o Degrava Lab IA")
                abrir.Click += mostrar
                fechar = ToolStripMenuItem("Fechar o Degrava Lab IA")
                fechar.Click += lambda *_: formulario.Close()
                menu.Items.Add(abrir)
                menu.Items.Add(fechar)
                icone_bandeja.ContextMenuStrip = menu
                icone_bandeja.MouseClick += ao_clicar
                icone_bandeja.Visible = True
                bandeja["icone"] = icone_bandeja
                anotar(registro, "Ícone na bandeja do sistema: ativo.")

            formulario.Invoke(Action(montar))
        except Exception as erro:
            anotar(registro, f"Ícone na bandeja do sistema: indisponível ({erro})")

    def tirar_da_bandeja():  # sem isto, o ícone fica "fantasma" na bandeja até passar o mouse
        icone_bandeja = bandeja.pop("icone", None)
        if icone_bandeja is not None:
            try:
                icone_bandeja.Visible = False
                icone_bandeja.Dispose()
            except Exception:
                pass

    janela.events.shown += icone_e_bandeja
    janela.events.closed += tirar_da_bandeja

    servidor = None if ja_aberto else Lancador(janela, registro, porta)

    def ao_abrir():
        if servidor:
            servidor.iniciar()
        else:
            janela.load_url(f"http://127.0.0.1:{porta}/")

    try:
        DADOS_JANELA.mkdir(exist_ok=True)
        webview.start(ao_abrir, gui="edgechromium" if os.name == "nt" else None, private_mode=False,
                      storage_path=str(DADOS_JANELA), icon=str(icone))
    except Exception as erro:  # sem WebView2 (raro no Windows 10/11): cai para o navegador
        anotar(registro, f"Janela própria indisponível ({erro}); abrindo no navegador.")
        if servidor:
            servidor.parar()
        registro.close()
        return modo_navegador()
    tirar_da_bandeja()
    anotar(registro, "Janela fechada.")
    if servidor:
        servidor.parar()
    registro.close()


if __name__ == "__main__":
    principal()
