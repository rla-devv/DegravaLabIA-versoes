"""Monta o pacote para Windows (downloads/DegravaIA.zip): o código + o Python portátil oficial.

    python empacotar.py [--novidades "o que mudou nesta versão"]

Gera também, em downloads/versao-X.Y.Z/, o que se publica para a atualização automática
(PUBLICAR-VERSAO.md): o pacote só com o código e o atualizacao.json que o app consulta.

O Python "embeddable" oficial do python.org vai na pasta python/ do pacote, para o
DegravaIA rodar num PC sem Python e sem instalar nada no Windows. O arquivo é
conferido pelo SHA-256 abaixo (a assinatura Sigstore dele, de hugo@python.org,
foi verificada quando o valor foi fixado). O _pth é ajustado para ligar o pip
(import site) e enxergar o código do DegravaIA (..).

O modelo de interlocutores (pyannote/speaker-diarization-community-1, 32 MB) também
vai no pacote, em modelos/hub, para a instalação não pedir token do Hugging Face: a
licença dele (CC-BY-4.0) permite redistribuir com crédito aos autores, que vai em
modelos/LICENCA-pyannote.txt. Precisa estar baixado neste computador (com token).
"""
import argparse
import hashlib
import json
import os
import re
import subprocess
import sys
import urllib.request
import zipfile
from pathlib import Path

AQUI = Path(__file__).resolve().parent
VERSAO = "3.14.8"
URL = f"https://www.python.org/ftp/python/{VERSAO}/python-{VERSAO}-embed-amd64.zip"
SHA256 = "a93abe456ab01bd96d7a085b3cdb6566b3063f4241360d114142fbdb07f0a310"
GET_PIP = "https://bootstrap.pypa.io/get-pip.py"
PTH = "python314.zip\n.\nLib\\site-packages\n..\nimport site\n"
LISTA = "arquivos-do-app.txt"
PYANNOTE = "pyannote/speaker-diarization-community-1"
CREDITO = f"""Modelo de identificação de interlocutores incluído no DegravaIA

{PYANNOTE}
https://huggingface.co/{PYANNOTE}
Autores: pyannote (Hervé Bredin e colaboradores), https://github.com/pyannote/pyannote-audio
Licença: Creative Commons Attribution 4.0 International (CC-BY-4.0)
https://creativecommons.org/licenses/by/4.0/

Os arquivos do modelo estão sem alterações, na pasta hub/models--pyannote--speaker-diarization-community-1.
"""


def baixar(url, destino):
    if not destino.exists():
        print(f"Baixando {url}")
        destino.parent.mkdir(parents=True, exist_ok=True)
        with urllib.request.urlopen(url, timeout=120) as r:
            destino.write_bytes(r.read())
    return destino


def arquivos_pyannote():
    """(arquivo no PC, caminho no pacote) do modelo pyannote, no formato do cache do Hugging Face
    sem atalhos (refs/ e snapshots/ com os arquivos de verdade), como no Windows."""
    from huggingface_hub import snapshot_download

    snap = Path(snapshot_download(PYANNOTE, local_files_only=True))
    pasta = snap.parent.parent
    base = f"DegravaIA/modelos/hub/{pasta.name}"
    itens = [(pasta / "refs" / "main", f"{base}/refs/main")]
    for f in sorted(snap.rglob("*")):
        if f.is_file():
            itens.append((Path(os.path.realpath(f)), f"{base}/snapshots/{snap.name}/{f.relative_to(snap).as_posix()}"))
    return itens


def principal(novidades=""):
    cache = AQUI / "downloads" / "cache"
    embed = baixar(URL, cache / f"python-{VERSAO}-embed-amd64.zip")
    if hashlib.sha256(embed.read_bytes()).hexdigest() != SHA256:
        embed.unlink()
        sys.exit("O Python baixado não confere com o SHA-256 esperado. Arquivo apagado; nada foi empacotado.")
    get_pip = baixar(GET_PIP, cache / "get-pip.py")
    try:
        pyannote = arquivos_pyannote()
    except Exception:
        sys.exit(f"O modelo {PYANNOTE} não está neste computador. Baixe-o uma vez com token "
                 "(python -m degravaia baixar-modelos) e rode de novo; nada foi empacotado.")

    arquivos = subprocess.run(["git", "ls-files"], cwd=AQUI, capture_output=True, text=True, check=True).stdout.split()
    lista = "\n".join(arquivos + [LISTA]) + "\n"  # o que é código do app (a atualização troca só isso)
    saida = AQUI / "downloads" / "DegravaIA.zip"
    with zipfile.ZipFile(saida, "w", zipfile.ZIP_DEFLATED) as z:
        for f in arquivos:
            z.write(AQUI / f, f"DegravaIA/{f}")
        z.writestr(f"DegravaIA/{LISTA}", lista)
        with zipfile.ZipFile(embed) as e:
            for nome in e.namelist():
                dados = PTH.encode() if nome.endswith("._pth") else e.read(nome)
                z.writestr(f"DegravaIA/python/{nome}", dados)
        z.write(get_pip, "DegravaIA/python/get-pip.py")
        for origem, destino in pyannote:
            z.write(origem, destino)
        z.writestr("DegravaIA/modelos/LICENCA-pyannote.txt", CREDITO)
    print(f"{saida} ({saida.stat().st_size / 2**20:.1f} MB), Python {VERSAO} portátil e modelo pyannote incluídos")

    # atualização automática: só o código, sem Python nem modelos
    versao_app = re.search(r'^VERSAO = "([^"]+)"', (AQUI / "degravaia" / "config.py").read_text("utf-8"), re.M).group(1)
    pasta = AQUI / "downloads" / f"versao-{versao_app}"
    pasta.mkdir(parents=True, exist_ok=True)
    pacote = pasta / f"DegravaIA-atualizacao-{versao_app}.zip"
    with zipfile.ZipFile(pacote, "w", zipfile.ZIP_DEFLATED) as z:
        for f in arquivos:
            z.write(AQUI / f, f"DegravaIA/{f}")
        z.writestr(f"DegravaIA/{LISTA}", lista)
    manifesto = {"versao": versao_app, "arquivo": pacote.name,
                 "sha256": hashlib.sha256(pacote.read_bytes()).hexdigest(),
                 "tamanho": pacote.stat().st_size, "novidades": novidades}
    (pasta / "atualizacao.json").write_text(json.dumps(manifesto, ensure_ascii=False, indent=2), "utf-8")
    print(f"{pasta}: {pacote.name} e atualizacao.json (versão {versao_app}) para publicar")


if __name__ == "__main__":
    ap = argparse.ArgumentParser(description="Monta o pacote do DegravaIA para Windows")
    ap.add_argument("--novidades", default="", help="o que mudou, mostrado ao usuário ao oferecer a atualização")
    principal(ap.parse_args().novidades)
