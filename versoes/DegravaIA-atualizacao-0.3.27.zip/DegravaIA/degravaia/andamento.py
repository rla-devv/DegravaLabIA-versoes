"""Andamento da importação: porcentagem real, tempo passado e quanto falta.

Cada etapa informa a fração já feita (pyannote e Whisper pelo próprio motor, wav2vec2
pelos blocos de 30 s já ouvidos). O tempo previsto de cada etapa é
    fixo (carregar o modelo) + segundos por segundo de áudio,
começando pelos valores medidos abaixo e aprendendo com cada importação feita neste
computador (arquivo .tempos.json na pasta de projetos). Durante a importação, a
previsão ainda é corrigida pelo ritmo real (tempo passado ÷ trabalho feito).
"""
import json
import time
from pathlib import Path

ETAPAS = ("preparar", "interlocutores", "transcricao", "segunda_escuta", "montagem")
NOMES = {"preparar": "Preparando o arquivo", "interlocutores": "Separando as vozes",
         "transcricao": "Transcrevendo as falas", "segunda_escuta": "Segunda escuta (conferência)",
         "montagem": "Montando o texto"}
# (fixo em s, s por s de áudio). CPU: medido em 18/10/2026 num processador de 4 núcleos,
# áudio de 2 min 10 s (pyannote 129 s, Whisper 308 s com ~30 s de carga, wav2vec2 29 s).
# GPU: estimativa inicial; o .tempos.json corrige depois da primeira importação.
PADRAO = {
    "cpu": {"preparar": (1, 0.01), "interlocutores": (5, 0.95), "transcricao": (30, 2.1),
            "segunda_escuta": (5, 0.18), "montagem": (1, 0.005)},
    "cuda": {"preparar": (1, 0.01), "interlocutores": (8, 0.06), "transcricao": (20, 0.25),
             "segunda_escuta": (6, 0.03), "montagem": (1, 0.005)},
}
ARQUIVO = ".tempos.json"


def carregar_aprendido(raiz):
    try:
        return json.loads((Path(raiz) / ARQUIVO).read_text("utf-8"))
    except (OSError, ValueError):
        return {}


def previsto(etapa, duracao, disp, aprendido):
    """(carga do modelo, trabalho proporcional ao áudio), em segundos."""
    fixo, por_s = PADRAO.get(disp, PADRAO["cpu"])[etapa]
    por_s = aprendido.get(disp, {}).get(etapa, por_s)
    return fixo, por_s * duracao


class Andamento:
    """Recebe os avisos do processo de importação e calcula o que a tela mostra."""

    def __init__(self, aprendido=None, agora=time.monotonic):
        self.agora = agora
        self.inicio = agora()
        self.aprendido = aprendido or {}
        self.duracao = None
        self.disp = "cpu"
        self.etapas = list(ETAPAS)
        self.atual, self.frac = "preparar", 0.0
        self.inicio_etapa = {"preparar": self.inicio}
        self.fim_etapa = {}
        self.maior = 0  # a porcentagem mostrada nunca volta

    def receber(self, aviso):
        """aviso: {"etapa", "frac"} e, no início, {"duracao", "disp", "etapas"}."""
        if "duracao" in aviso:
            self.duracao = float(aviso["duracao"])
        if aviso.get("disp") in PADRAO:
            self.disp = aviso["disp"]
        if aviso.get("etapas"):
            self.etapas = [e for e in ETAPAS if e in aviso["etapas"]]
        etapa = aviso.get("etapa")
        if etapa in ETAPAS and etapa != self.atual:
            t = self.agora()
            self.fim_etapa[self.atual] = t
            self.atual, self.frac = etapa, 0.0
            self.inicio_etapa[etapa] = t
        if etapa == self.atual and "frac" in aviso:
            self.frac = max(self.frac, min(1.0, float(aviso["frac"])))  # nunca anda para trás

    def estado(self):
        passado = self.agora() - self.inicio
        atual = self.etapas.index(self.atual) if self.atual in self.etapas else 0
        base = {"etapa": self.atual, "nome": NOMES[self.atual], "numero": atual + 1, "de": len(self.etapas),
                "frac_etapa": round(self.frac, 3), "passado_s": round(passado), "etapas":
                [{"id": e, "nome": NOMES[e], "feita": i < atual} for i, e in enumerate(self.etapas)]}
        if self.duracao is None:  # ainda lendo o arquivo
            return base | {"porcentagem": 0, "falta_s": None}
        prev = {e: previsto(e, self.duracao, self.disp, self.aprendido) for e in self.etapas}
        total = sum(sum(p) for p in prev.values())
        feito = sum(sum(prev[e]) for e in self.etapas[:atual])
        carga, trabalho = prev[self.atual]
        if self.frac > 0:  # já está trabalhando: o modelo terminou de carregar
            feito += carga + trabalho * self.frac
        else:  # carregando o modelo: conta o tempo já gasto, até quase toda a carga prevista
            gasto = self.agora() - self.inicio_etapa.get(self.atual, self.inicio)
            feito += min(gasto, 0.95 * carga)
        falta = max(0.0, total - feito)
        if feito > 0.05 * total and passado > 30:  # antes disso, o começo rápido do pyannote engana
            falta *= min(5.0, max(0.2, passado / feito))  # corrige pelo ritmo real deste computador
        self.maior = max(self.maior, min(99, int(100 * feito / total)))
        return base | {"porcentagem": self.maior, "falta_s": round(falta)}

    def aprender(self, raiz):
        """Guarda o ritmo de cada etapa concluída para as próximas previsões."""
        if not self.duracao or self.duracao < 20:  # áudio curto: quase só carga de modelo
            return
        self.fim_etapa.setdefault(self.atual, self.agora())
        dados = carregar_aprendido(raiz)
        meu = dados.setdefault(self.disp, {})
        for e in self.etapas:
            if e in self.inicio_etapa and e in self.fim_etapa:
                fixo, _ = PADRAO[self.disp][e]
                por_s = max(0.0, (self.fim_etapa[e] - self.inicio_etapa[e] - fixo) / self.duracao)
                meu[e] = round(por_s if e not in meu else 0.5 * meu[e] + 0.5 * por_s, 4)
        try:
            (Path(raiz) / ARQUIVO).write_text(json.dumps(dados, indent=2), "utf-8")
        except OSError:
            pass
