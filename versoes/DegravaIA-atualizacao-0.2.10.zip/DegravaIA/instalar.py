"""Degrava IA — instalação (precisa de internet só agora).

No Windows, use o instalar.bat: ele roda este arquivo com o Python portátil
oficial que vem na pasta "python" do pacote, e nada é instalado no Windows.
Sem a pasta "python" (cópia do código-fonte), roda com qualquer Python já
instalado. Etapas:
1. Python: o portátil da pasta; sem ele, procura um 3.10 a 3.14 de 64 bits
   (versões com as bibliotecas de IA) e, se não houver, instala o 3.14;
2. bibliotecas (versão para GPU se houver placa NVIDIA), dentro da pasta;
3. modelos, uma vez só (sem token: o de interlocutores vem no pacote), e diagnóstico;
4. atalho "Degrava IA" na Área de Trabalho e no Menu Iniciar (abre em janela própria).
"""
import glob
import os
import shutil
import subprocess
import sys
import webbrowser
from pathlib import Path

AQUI = Path(__file__).resolve().parent
WINDOWS = os.name == "nt"
VENV_PY = AQUI / ".venv" / ("Scripts/python.exe" if WINDOWS else "bin/python")
PY_PORTATIL = AQUI / "python" / "python.exe"  # Python oficial "embeddable", vem no pacote (empacotar.py)


def python_do_app():
    """O Python que roda o Degrava IA: o portátil da pasta, se existir; senão o do .venv."""
    return PY_PORTATIL if PY_PORTATIL.exists() else VENV_PY
VERSOES = ((3, 14), (3, 13), (3, 12), (3, 11), (3, 10))  # do mais novo para o mais antigo
# Testado em 18/10/2026: no 3.15 ainda faltam ctranslate2, torchaudio, torchcodec, onnxruntime e av.
SEM_JANELA = 0x08000000 if WINDOWS else 0  # testes de versão sem piscar janelas


def passo(texto):
    print(f"\n=== {texto}", flush=True)


def versao_de(exe):
    """(maior, menor, bits) de um python.exe, ou None se não rodar (ex.: atalho vazio da Store)."""
    try:
        r = subprocess.run([str(exe), "-c", "import sys, struct; print(*sys.version_info[:2], struct.calcsize('P') * 8)"],
                           capture_output=True, text=True, timeout=30, creationflags=SEM_JANELA,
                           stdin=subprocess.DEVNULL)
        maior, menor, bits = map(int, r.stdout.split())
        return maior, menor, bits
    except Exception:
        return None


def serve(v):
    return v is not None and v[2] == 64 and (v[0], v[1]) in VERSOES


def candidatos():
    """Todos os lugares comuns onde há Python no Windows (e no Linux, para testes)."""
    vistos = []

    def add(caminho):
        if caminho and Path(caminho).is_file() and str(caminho).lower() not in [str(v).lower() for v in vistos]:
            vistos.append(Path(caminho))

    add(sys.executable)
    py = shutil.which("py")
    for maior, menor in VERSOES:  # lançador "py" do Windows
        if py:
            try:
                # stdin vazio: se o lançador perguntar "instalar esta versão?", a resposta é não
                r = subprocess.run([py, f"-{maior}.{menor}", "-c", "import sys; print(sys.executable)"],
                                   capture_output=True, text=True, timeout=30, creationflags=SEM_JANELA,
                                   stdin=subprocess.DEVNULL)
                add(r.stdout.strip())
            except Exception:
                pass
        add(shutil.which(f"python{maior}.{menor}"))
    add(shutil.which("python"))
    add(shutil.which("python3"))
    if WINDOWS:  # registro: o instalador oficial anota onde instalou, mesmo fora do padrão
        import winreg

        for raiz in (winreg.HKEY_CURRENT_USER, winreg.HKEY_LOCAL_MACHINE):
            try:
                chave = winreg.OpenKey(raiz, r"Software\Python\PythonCore")
            except OSError:
                continue
            for i in range(winreg.QueryInfoKey(chave)[0]):
                try:
                    sub = winreg.OpenKey(chave, winreg.EnumKey(chave, i) + r"\InstallPath")
                    try:
                        add(winreg.QueryValueEx(sub, "ExecutablePath")[0])
                    except OSError:
                        add(Path(winreg.QueryValueEx(sub, "")[0]) / "python.exe")
                except OSError:
                    pass
        local, usuario = os.environ.get("LOCALAPPDATA", ""), os.environ.get("USERPROFILE", "")
        pastas = [f"{local}/Programs/Python/Python3*", f"{local}/Python/pythoncore-3*",
                  f"{os.environ.get('ProgramFiles', 'C:/Program Files')}/Python3*", "C:/Python3*",
                  f"{usuario}/anaconda3", f"{usuario}/miniconda3", f"{local}/anaconda3", f"{local}/miniconda3",
                  f"{os.environ.get('ProgramData', 'C:/ProgramData')}/anaconda3",
                  f"{os.environ.get('ProgramData', 'C:/ProgramData')}/miniconda3"]
        for padrao in pastas:
            for pasta in sorted(glob.glob(padrao), reverse=True):
                add(Path(pasta) / "python.exe")
    return vistos


def achar_python():
    """O melhor Python que serve e, à parte, os encontrados que não servem."""
    bons, ruins = [], []
    for exe in candidatos():
        v = versao_de(exe)
        if serve(v):
            bons.append((v, exe))
        elif v:
            ruins.append((v, exe))
    bons.sort(key=lambda x: (x[0][0], x[0][1]), reverse=True)
    return (bons[0][1] if bons else None), ruins


def instalar_python():
    """Instala o Python 3.14 só para este usuário, pelos instaladores oficiais já presentes."""
    print("Instalando o Python 3.14, só para este usuário (sem senha de administrador)...", flush=True)
    tentativas = []
    if shutil.which("pymanager"):  # novo instalador oficial do Python
        tentativas.append(["pymanager", "install", "3.14"])
    if shutil.which("winget"):  # instalador de programas da Microsoft
        tentativas.append(["winget", "install", "-e", "--id", "Python.Python.3.14", "--scope", "user",
                           "--accept-package-agreements", "--accept-source-agreements"])
    for cmd in tentativas:
        subprocess.run(cmd)
        exe, _ = achar_python()
        if exe:
            return exe
    return None


def rodar(*args, env=None):
    print("  >", " ".join(str(a) for a in args), flush=True)
    subprocess.run([str(a) for a in args], check=True, env=env)


def ambiente_modelos():
    """No pacote portátil, os modelos ficam na pasta modelos/ do Degrava IA, não na do usuário
    do Windows: a pasta inteira pode ser copiada para outro PC e usada sem internet."""
    env = dict(os.environ)
    if PY_PORTATIL.exists():
        env["HF_HOME"] = str(AQUI / "modelos")
    return env


def ambiente_nvidia():
    """PATH com as bibliotecas da NVIDIA (cuBLAS/cuDNN, que vêm com o torch) e modo offline."""
    env = dict(ambiente_modelos(), HF_HUB_OFFLINE="1", TRANSFORMERS_OFFLINE="1", PYTHONIOENCODING="utf-8")
    pastas = []
    for base in (AQUI / "python", AQUI / ".venv"):
        pacotes = base / "Lib" / "site-packages"
        pastas += glob.glob(str(pacotes / "torch" / "lib"))  # cuBLAS e cuDNN que vêm com o torch
        pastas += glob.glob(str(pacotes / "nvidia" / "*" / "bin"))  # instalações antigas
    if os.environ.get("CUDA_PATH"):  # CUDA instalado no próprio Windows, se houver
        pastas.append(str(Path(os.environ["CUDA_PATH"]) / "bin"))
    env["PATH"] = os.pathsep.join(pastas + [env.get("PATH", "")])
    return env


# ---------- atalhos (Área de Trabalho e Menu Iniciar) ----------
PASTA_DESKTOP = "{B4BFCC3A-DB2C-424C-B029-7FE99A87C641}"  # FOLDERID_Desktop (segue o OneDrive, se houver)
PASTA_PROGRAMAS = "{A77F5D77-2E2B-44C3-A6A2-ABA601054A51}"  # FOLDERID_Programs (Menu Iniciar)
ATALHO, ATALHO_ANTIGO = "Degrava IA.lnk", "DegravaIA.lnk"
ICONE = AQUI / "degravaia" / "web" / "degravaia-icone.ico"


def _guid(texto):
    import ctypes
    import uuid

    class GUID(ctypes.Structure):
        _fields_ = [("Data1", ctypes.c_ulong), ("Data2", ctypes.c_ushort), ("Data3", ctypes.c_ushort),
                    ("Data4", ctypes.c_ubyte * 8)]

    u = uuid.UUID(texto)
    g = GUID(u.fields[0], u.fields[1], u.fields[2])
    g.Data4[:] = list(u.bytes[8:])
    return g


def pasta_do_windows(guid):
    import ctypes

    caminho = ctypes.c_wchar_p()
    ctypes.OleDLL("shell32").SHGetKnownFolderPath(ctypes.byref(_guid(guid)), 0, None, ctypes.byref(caminho))
    try:
        return Path(caminho.value)
    finally:
        ctypes.windll.ole32.CoTaskMemFree(caminho)


def _salvar_atalho(lnk, alvo, argumentos, pasta, icone, descricao):
    """Cria o .lnk pela interface do próprio Windows (IShellLink), sem abrir outro programa."""
    import ctypes
    from ctypes import wintypes

    def metodo(objeto, indice, *tipos):
        tabela = ctypes.cast(objeto, ctypes.POINTER(ctypes.POINTER(ctypes.c_void_p)))[0]
        return ctypes.WINFUNCTYPE(ctypes.HRESULT, ctypes.c_void_p, *tipos)(tabela[indice])

    ole32 = ctypes.OleDLL("ole32")
    try:
        ole32.CoInitialize(None)
    except OSError:
        pass  # COM já iniciado neste processo
    link, arquivo = ctypes.c_void_p(), ctypes.c_void_p()
    ole32.CoCreateInstance(ctypes.byref(_guid("{00021401-0000-0000-C000-000000000046}")), None, 1,
                           ctypes.byref(_guid("{000214F9-0000-0000-C000-000000000046}")), ctypes.byref(link))
    try:
        metodo(link, 20, ctypes.c_wchar_p)(link, str(alvo))            # SetPath
        metodo(link, 11, ctypes.c_wchar_p)(link, argumentos)           # SetArguments
        metodo(link, 9, ctypes.c_wchar_p)(link, str(pasta))            # SetWorkingDirectory
        metodo(link, 7, ctypes.c_wchar_p)(link, descricao)             # SetDescription
        metodo(link, 17, ctypes.c_wchar_p, ctypes.c_int)(link, str(icone), 0)  # SetIconLocation
        iid_arquivo = _guid("{0000010B-0000-0000-C000-000000000046}")  # IPersistFile (guardado até o fim)
        metodo(link, 0, ctypes.c_void_p, ctypes.POINTER(ctypes.c_void_p))(     # QueryInterface
            link, ctypes.addressof(iid_arquivo), ctypes.byref(arquivo))
        metodo(arquivo, 6, ctypes.c_wchar_p, wintypes.BOOL)(arquivo, str(lnk), True)  # Save
    finally:
        for objeto in (arquivo, link):
            if objeto.value:
                metodo(objeto, 2)(objeto)  # Release


def criar_atalhos(so_os_existentes=False):
    """Atalho "Degrava IA" na Área de Trabalho e no Menu Iniciar: abre a janela própria do app
    (python\\pythonw.exe degravaia.pyw, sem a janela preta). Devolve onde criou.
    Com so_os_existentes, só refaz os que já existem (nome novo, ícone novo), sem recriar um
    atalho que a pessoa apagou."""
    if not WINDOWS:
        return []
    alvo = python_do_app().with_name("pythonw.exe")
    icone = ICONE
    feitos = []
    for guid in (PASTA_DESKTOP, PASTA_PROGRAMAS):
        try:
            pasta_atalho = pasta_do_windows(guid)
            lnk = pasta_atalho / ATALHO
            if so_os_existentes and not (lnk.exists() or (pasta_atalho / ATALHO_ANTIGO).exists()):
                continue
            (pasta_atalho / ATALHO_ANTIGO).unlink(missing_ok=True)  # o app se chamava "DegravaIA" até a 0.2.7
            try:
                _salvar_atalho(lnk, alvo, f'"{AQUI / "degravaia.pyw"}"', AQUI, icone, "Degrava IA — transcrição literal")
            except OSError:  # plano B: o mesmo pelo PowerShell
                comando = (f"$s=(New-Object -ComObject WScript.Shell).CreateShortcut('{lnk}');"
                           f"$s.TargetPath='{alvo}';$s.Arguments='\"{AQUI / 'degravaia.pyw'}\"';"
                           f"$s.WorkingDirectory='{AQUI}';$s.IconLocation='{icone}';$s.Save()")
                subprocess.run(["powershell", "-NoProfile", "-Command", comando], check=True,
                               creationflags=SEM_JANELA, capture_output=True)
            if lnk.exists():
                feitos.append(lnk)
        except Exception as erro:
            print(f"  Não foi possível criar o atalho ({erro}).")
    return feitos


def preparar_venv():
    """Sem o Python portátil: usa (ou instala) um Python do sistema e cria o .venv."""
    exe, ruins = achar_python()
    for (maior, menor, bits), caminho in ruins:
        print(f"  Encontrado, mas não serve: Python {maior}.{menor} ({bits} bits) em {caminho}")
    if not exe:
        if ruins:
            print("  O Degrava IA precisa do Python 3.10 a 3.14, de 64 bits: as bibliotecas de IA ainda não saíram")
            print("  para versões mais novas. O 3.14 será instalado ao lado, sem mexer no seu.")
        exe = instalar_python()
    if not exe:
        print("\nNão foi possível instalar o Python automaticamente. Vou abrir a página oficial: instale uma")
        print('versão 3.14 de 64 bits, marque "Add python.exe to PATH" e abra este instalador de novo.')
        webbrowser.open("https://www.python.org/downloads/windows/")
        return None
    v = versao_de(exe)
    print(f"  Usando Python {v[0]}.{v[1]} em {exe}")
    passo("2. Ambiente isolado (.venv)")
    if VENV_PY.exists() and not serve(versao_de(VENV_PY)):
        print("  O ambiente existente usa uma versão do Python que não serve; criando de novo.")
        shutil.rmtree(AQUI / ".venv")
    if not VENV_PY.exists():
        rodar(exe, "-m", "venv", AQUI / ".venv")
    return VENV_PY


def principal():
    print("Degrava IA — instalação")
    print("Tudo roda no seu computador. A internet só é usada agora, para baixar as bibliotecas e os modelos.")

    passo("1. Python")
    if PY_PORTATIL.exists():
        app = PY_PORTATIL
        v = versao_de(app)
        print(f"  Usando o Python {v[0]}.{v[1]} portátil da pasta do Degrava IA (nada é instalado no Windows).")
        if subprocess.run([str(app), "-m", "pip", "--version"], capture_output=True).returncode != 0:
            passo("2. Instalador de bibliotecas (pip), dentro da pasta")
            rodar(app, AQUI / "python" / "get-pip.py", "--no-warn-script-location")
    else:
        app = preparar_venv()
        if app is None:
            return 1
    rodar(app, "-m", "pip", "install", "--upgrade", "pip", "--no-warn-script-location")

    passo("3. Bibliotecas de IA")
    if shutil.which("nvidia-smi"):
        # o torch para GPU no Windows já traz o cuBLAS 12 e o cuDNN 9 que o Whisper usa
        # (ambiente_nvidia põe torch/lib no PATH): não é preciso instalá-los à parte
        print("  Placa NVIDIA encontrada: instalando a versão para GPU.")
        indice = "https://download.pytorch.org/whl/cu126"
    else:
        print("  Sem placa NVIDIA: instalando a versão para CPU (mesmo resultado, mais devagar).")
        indice = "https://download.pytorch.org/whl/cpu"
    rodar(app, "-m", "pip", "install", "--no-warn-script-location", "torch", "torchaudio", "--index-url", indice)
    try:
        rodar(app, "-m", "pip", "install", "--no-warn-script-location", "torchcodec", "--index-url", indice)
    except subprocess.CalledProcessError:
        rodar(app, "-m", "pip", "install", "--no-warn-script-location", "torchcodec")
    # bibliotecas/: versões prontas de pacotes que só existem em código-fonte (o Python portátil
    # não consegue montá-los sozinho)
    rodar(app, "-m", "pip", "install", "--no-warn-script-location", "--find-links", AQUI / "bibliotecas",
          "-r", AQUI / "requirements.txt")

    passo("4. Modelos (cerca de 5 GB, uma vez só)")
    rodar(app, "-m", "degravaia", "baixar-modelos", env=ambiente_modelos())

    passo("5. Diagnóstico")
    subprocess.run([str(app), "-m", "degravaia", "diagnostico"], env=ambiente_nvidia(), cwd=AQUI)
    if WINDOWS:
        passo("6. Atalhos")
        for lnk in criar_atalhos():
            print(f"  Criado: {lnk}")
    print("\nInstalação concluída. Para usar, dê dois cliques no atalho Degrava IA da Área de Trabalho")
    print("(ou em abrir.bat, na pasta do Degrava IA).")
    return 0


if __name__ == "__main__":
    os.chdir(AQUI)
    try:
        codigo = principal()
    except subprocess.CalledProcessError as erro:
        print(f"\nA instalação parou com erro no passo acima (código {erro.returncode}).")
        print("Se puder, mande um print desta janela.")
        codigo = 1
    except KeyboardInterrupt:
        codigo = 1
    input("\nTecle Enter para fechar esta janela.")
    sys.exit(codigo)
