"""Junta palavras e interlocutores em falas e gera o texto do corpo (item 10).

Regra: nada aqui inventa ou remove palavras do motor. Só organiza, marca
pausas/sobreposições e sinaliza o que precisa de revisão.
"""
from .config import CONFIANCA_MINIMA, PAUSA_MINIMA_S, ROTULO_INTERLOCUTOR


def _sobreposicao(a_ini, a_fim, b_ini, b_fim):
    return max(0.0, min(a_fim, b_fim) - max(a_ini, b_ini))


def atribuir_falantes(palavras, turnos):
    """Cada palavra fica com o falante de maior sobreposição; sem sobreposição, o turno mais próximo."""
    if not turnos:
        for p in palavras:
            p["falante"] = None
        return palavras
    turnos = sorted(turnos, key=lambda t: t["inicio"])
    for p in palavras:
        melhor, melhor_s = None, 0.0
        for t in turnos:
            if t["inicio"] > p["fim"]:
                break
            s = _sobreposicao(p["inicio"], p["fim"], t["inicio"], t["fim"])
            if s > melhor_s:
                melhor, melhor_s = t["falante"], s
        if melhor is None:
            meio = (p["inicio"] + p["fim"]) / 2
            melhor = min(turnos, key=lambda t: min(abs(meio - t["inicio"]), abs(meio - t["fim"])))["falante"]
        p["falante"] = melhor
    return palavras


def regioes_por_turno(turnos, juntar_s=1.0, folga_s=0.3):
    """Trechos que o Whisper transcreve separadamente, um por turno de fala (rodada 4).

    Turnos seguidos da mesma voz com menos de `juntar_s` de intervalo viram um só;
    turnos curtos demais juntam-se ao vizinho. Os trechos nunca se sobrepõem, senão o
    mesmo áudio seria transcrito duas vezes.
    """
    regs = []
    for t in sorted(turnos, key=lambda t: t["inicio"]):
        anterior = regs[-1] if regs else None
        if anterior and t["inicio"] - anterior[1] < juntar_s and (
                anterior[2] == t["falante"] or t["fim"] - t["inicio"] < juntar_s
                or anterior[1] - anterior[0] < juntar_s):
            anterior[1] = max(anterior[1], t["fim"])
        else:
            regs.append([t["inicio"], t["fim"], t["falante"]])
    for a, b in zip(regs, regs[1:]):
        folga = min(folga_s, max(0.0, (b[0] - a[1]) / 2))
        a[1] += folga
        b[0] -= folga
    if regs:
        regs[0][0] = max(0.0, regs[0][0] - folga_s)
        regs[-1][1] += folga_s
    return [(round(a, 3), round(b, 3)) for a, b, _ in regs]


def fora_das_regioes(palavras, regioes):
    """Palavras (da segunda escuta) que não tocam nenhum trecho enviado ao Whisper."""
    return [p for p in palavras
            if not any(_sobreposicao(p["inicio"], p["fim"], a, b) > 0 for a, b in regioes)]


def marcar_sobreposicoes(palavras, sobreposicoes):
    for p in palavras:
        p["sobreposicao"] = any(_sobreposicao(p["inicio"], p["fim"], s["inicio"], s["fim"]) > 0
                                for s in sobreposicoes)
    return palavras


def rotular_interlocutores(palavras):
    """Rótulos genéricos na ordem em que cada voz aparece: Interlocutor 1, 2, 3…"""
    mapa = {}
    for p in palavras:
        f = p.get("falante")
        if f is not None and f not in mapa:
            mapa[f] = ROTULO_INTERLOCUTOR.format(n=len(mapa) + 1)
    return mapa


def montar_falas(palavras):
    """Agrupa palavras consecutivas do mesmo falante. Pausas longas viram marcação."""
    for i, p in enumerate(palavras):
        p["id"] = i
        p["baixa_confianca"] = p["prob"] < CONFIANCA_MINIMA or p.get("suspeita_alucinacao", False)

    falas, atual = [], None
    for i, p in enumerate(palavras):
        if atual is None or p.get("falante") != atual["falante"]:
            atual = {"falante": p.get("falante"), "inicio": p["inicio"], "fim": p["fim"], "itens": []}
            falas.append(atual)
        elif p["inicio"] - palavras[i - 1]["fim"] >= PAUSA_MINIMA_S:
            pausa = round(p["inicio"] - palavras[i - 1]["fim"])
            atual["itens"].append({"marca": "pausa", "segundos": pausa})
        atual["itens"].append({"palavra": p["id"]})
        atual["fim"] = p["fim"]
    return falas


def tempo(segundos):
    s = int(segundos)
    return f"{s // 3600:02d}:{s % 3600 // 60:02d}:{s % 60:02d}"


def texto_corpo(dados):
    from .marcacoes import texto_da_fala

    nomes = dados["interlocutores"]
    linhas = []
    for n, fala in enumerate(dados["falas"]):
        quem = nomes.get(fala["falante"], "Interlocutor não identificado")
        texto = texto_da_fala(fala, dados, final=n == len(dados["falas"]) - 1)
        linhas.append(f"[{tempo(fala['inicio'])}] {quem}: {texto}")
    return "\n".join(linhas)
