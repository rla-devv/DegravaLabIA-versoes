"""Gera o ícone do Degrava IA no padrão visual dos apps da RLA.dev.

    python ferramentas/icone.py

Padrão (o mesmo do ícone do app de reconhecimento facial): fundo azul-marinho, placa
arredondada com borda sutil, cantoneiras ciano com brilho, o símbolo do app em malha de
pontos e linhas (ciano → azul) e uma linha de varredura horizontal no meio. No Degrava IA o
símbolo é uma onda sonora (barras de áudio), com a varredura servindo de eixo.

Saída: degravaia/web/degravaia.ico (16 a 256 px; até 64 px uma versão simplificada, sem a
malha, que viraria borrão) e degravaia/web/icone.png (256 px, para a tela de abertura).
Para outro app, troque só a função `formas()` (o símbolo central).
"""
import random
from pathlib import Path

from PIL import Image, ImageChops, ImageDraw, ImageEnhance, ImageFilter

N = 1024
FUNDO = (9, 20, 44)
PLACA_TOPO, PLACA_BASE = (24, 48, 82), (10, 24, 50)
BORDA = (52, 84, 120)
CIANO = (90, 240, 255)
AZUL = (70, 120, 255)
SAIDA = Path(__file__).resolve().parent.parent / "degravaia" / "web"


def misturar(a, b, t):
    return tuple(round(x + (y - x) * t) for x, y in zip(a, b))


def formas(alturas=(100, 175, 240, 280, 240, 175, 100), largura=50, vao=26):
    """O símbolo do app: barras de áudio simétricas (x central, meia altura, largura), em px de 1024."""
    inicio = N / 2 - (len(alturas) * largura + (len(alturas) - 1) * vao) / 2
    return [(inicio + i * (largura + vao) + largura / 2, h, largura) for i, h in enumerate(alturas)]


def brilho(camada, raios=((28, 0.55), (8, 0.6))):
    """Soma à camada cópias desfocadas e atenuadas dela mesma: o brilho de néon."""
    saida = camada.copy()
    for raio, forca in raios:
        saida = ImageChops.add(saida, ImageEnhance.Brightness(camada.filter(ImageFilter.GaussianBlur(raio))).enhance(forca))
    return saida


def base():
    img = Image.new("RGB", (N, N), FUNDO)
    # sombra da placa
    sombra = Image.new("L", (N, N), 0)
    ImageDraw.Draw(sombra).rounded_rectangle([140, 150, 890, 905], radius=120, fill=150)
    img.paste((3, 8, 20), (0, 0), sombra.filter(ImageFilter.GaussianBlur(30)))
    # placa com degradê vertical
    degrade = Image.new("RGB", (N, N))
    d = ImageDraw.Draw(degrade)
    for y in range(N):
        d.line([(0, y), (N, y)], fill=misturar(PLACA_TOPO, PLACA_BASE, min(1, max(0, (y - 130) / 760))))
    mascara = Image.new("L", (N, N), 0)
    ImageDraw.Draw(mascara).rounded_rectangle([132, 128, 892, 888], radius=118, fill=255)
    img.paste(degrade, (0, 0), mascara)
    ImageDraw.Draw(img).rounded_rectangle([132, 128, 892, 888], radius=118, outline=BORDA, width=4)
    return img


def cantoneiras(d, espessura=20):
    """Quatro cantoneiras em traço contínuo (reta, curva, reta), de espessura uniforme e pontas
    arredondadas: o traço é um círculo arrastado ao longo do caminho, sem emendas."""
    import math

    r, braco = 58, 150
    meio = espessura / 2
    for cx, cy, sx, sy in ((212, 205, 1, 1), (812, 205, -1, 1), (212, 812, 1, -1), (812, 812, -1, -1)):
        caminho = [(cx, cy + braco * sy - k * sy) for k in range(int(braco - r))]  # braço vertical
        ox, oy = cx + r * sx, cy + r * sy  # centro da curva
        for k in range(91):  # curva de 90°, de grau em grau
            a = math.radians(k)
            caminho.append((ox - r * sx * math.cos(a), oy - r * sy * math.sin(a)))
        caminho += [(cx + r * sx + k * sx, cy) for k in range(int(braco - r) + 1)]  # braço horizontal
        for x, y in caminho:
            d.ellipse([x - meio, y - meio, x + meio, y + meio], fill=CIANO)


def varredura(camada, largura=6):
    d = ImageDraw.Draw(camada)
    d.line([(212, N / 2), (812, N / 2)], fill=CIANO, width=largura)
    faixa = Image.new("RGB", (N, N))  # halo largo e suave ao redor da linha
    ImageDraw.Draw(faixa).rectangle([230, N / 2 - 26, 794, N / 2 + 26], fill=(10, 48, 62))
    return ImageChops.add(camada, faixa.filter(ImageFilter.GaussianBlur(28)))


def malha(d, pontos):
    """Barras em malha de triângulos: nós nas bordas e no meio de cada barra, ligados entre si."""
    random.seed(7)
    nos = []
    for x, h, w in formas():
        linhas = max(3, round(2 * h / 58))
        grade = []
        for j in range(linhas + 1):
            y = N / 2 - h + 2 * h * j / linhas
            estreita = 1 - (abs(y - N / 2) / h) ** 6 * 0.7  # pontas arredondadas, como cápsulas
            fila = [(x + (k - 1) * w / 2 * estreita + random.uniform(-3, 3), y + random.uniform(-3, 3))
                    for k in range(3)]
            grade.append(fila)
        for j in range(linhas):
            for k in range(2):
                a, b, c, e = grade[j][k], grade[j][k + 1], grade[j + 1][k], grade[j + 1][k + 1]
                for p, q in ((a, b), (a, c), (b, e) if (j + k) % 2 else (a, e), (c, e), (b, c) if (j + k) % 2 else (b, e)):
                    t = (p[0] - 280) / 464
                    d.line([p, q], fill=misturar(CIANO, AZUL, max(0, min(1, t))) + (200,), width=2)
        nos += [p for fila in grade for p in fila]
    # fios entre barras vizinhas (a malha continua de uma barra para a outra)
    cols = formas()
    for (x1, h1, w1), (x2, h2, w2) in zip(cols, cols[1:]):
        hm = min(h1, h2)
        for f in (-0.66, -0.2, 0.2, 0.66):
            y = N / 2 + f * hm
            t = (x1 - 280) / 464
            d.line([(x1 + w1 / 2, y), (x2 - w2 / 2, y + 14 * f)], fill=misturar(CIANO, AZUL, t) + (110,), width=2)
    for x, y in nos:
        t = (x - 280) / 464
        cor = misturar((200, 248, 255), (140, 170, 255), max(0, min(1, t)))
        d.ellipse([x - 4.5, y - 4.5, x + 4.5, y + 4.5], fill=cor + (255,))


def detalhado():
    img = base()
    neon = Image.new("RGB", (N, N))
    cantoneiras(ImageDraw.Draw(neon))
    simbolo = Image.new("RGBA", (N, N), (0, 0, 0, 0))
    malha(ImageDraw.Draw(simbolo, "RGBA"), None)
    neon.paste(simbolo, (0, 0), simbolo)
    neon = varredura(neon)
    return ImageChops.add(img, brilho(neon))


def simplificado(com_cantoneiras=True):
    """Para 16–64 px: barras cheias e bem separadas (em 16 e 24 px, sem as cantoneiras)."""
    img = base()
    neon = Image.new("RGB", (N, N))
    d = ImageDraw.Draw(neon)
    if com_cantoneiras:
        cantoneiras(d, espessura=40)
    escala = 1.0 if com_cantoneiras else 1.25
    for x, h, w in formas((150, 240, 300, 240, 150), largura=78, vao=40):
        x = N / 2 + (x - N / 2) * escala
        h, w = min(h * escala, 340), w * escala
        t = (x - 280) / 464
        d.rounded_rectangle([x - w / 2, N / 2 - h, x + w / 2, N / 2 + h], radius=int(w / 2),
                            fill=misturar(CIANO, AZUL, max(0, min(1, t))))
    return ImageChops.add(img, brilho(neon, ((14, 0.35),)))


def recortar(img):
    """Tira o fundo além da placa (o ícone do Windows fica só com a placa e a sombra)."""
    mascara = Image.new("L", (N, N), 0)
    ImageDraw.Draw(mascara).rounded_rectangle([120, 116, 904, 912], radius=128, fill=255)
    saida = img.convert("RGBA")
    saida.putalpha(mascara.filter(ImageFilter.GaussianBlur(3)))
    return saida.crop((104, 100, 920, 916)).resize((N, N), Image.LANCZOS)


if __name__ == "__main__":
    grande, medio, minimo = recortar(detalhado()), recortar(simplificado()), recortar(simplificado(False))
    tamanhos = [16, 24, 32, 48, 64, 128, 256]
    imagens = [(minimo if t <= 24 else medio if t <= 64 else grande).resize((t, t), Image.LANCZOS) for t in tamanhos]
    imagens[-1].save(SAIDA / "degravaia.ico", sizes=[(t, t) for t in tamanhos], append_images=imagens[:-1])
    grande.resize((256, 256), Image.LANCZOS).save(SAIDA / "icone.png", optimize=True)
    detalhado().save(Path(__file__).with_name("icone-1024.png"))  # com o fundo, para conferência
    print("ícone gerado:", SAIDA / "degravaia.ico", SAIDA / "icone.png")
