"""Exportação em DOCX, PDF, SRT, TXT e XLSX (item 8) com cabeçalho e rodapé
revisados pelo usuário antes de gerar (item 9).

Campos: listas de {"id", "rotulo", "valor", "incluir", "protegido"?}. Os campos
protegidos (hash) têm o valor sempre recalculado aqui: o usuário só inclui ou
remove. Cada exportação é registrada no histórico com o SHA-256 de cada arquivo
gerado (cadeia de custódia).
"""
import copy
import json
import re
from datetime import datetime
from pathlib import Path

from . import marcacoes
from .config import MODELO_DIARIZACAO, MODELO_SEGUNDA_ESCUTA, NOME_APP, VERSAO
from .montagem import tempo
from .projeto import agora, sha256

FORMATOS = ("docx", "pdf", "srt", "txt", "xlsx")
PREFERENCIAS = ".preferencias.json"  # na pasta de projetos: dados do responsável

LEGENDA = ("[inaudível HH:MM:SS]: trecho que não se ouve · [ininteligível HH:MM:SS]: ouve-se, mas não "
           "se entende · [sobreposição de vozes]: duas ou mais pessoas falando ao mesmo tempo · "
           "[pausa Ns]: silêncio de N segundos · [risos] · [choro] · palavra (?): palavra com dúvida "
           "do revisor · [HH:MM:SS]: início da fala")

FONTES_PDF = (  # Windows primeiro; as outras servem para Linux
    ("C:/Windows/Fonts/arial.ttf", "C:/Windows/Fonts/arialbd.ttf"),
    ("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"),
    ("/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf",
     "/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf"),
)


class ExportacaoInvalida(ValueError):
    pass


# ---------- campos do cabeçalho e do rodapé ----------
def _campo(cid, rotulo, valor, protegido=False):
    c = {"id": cid, "rotulo": rotulo, "valor": valor, "incluir": True}
    if protegido:
        c["protegido"] = True
    return c


def _nomes_usados(dados):
    usados = {p.get("falante") for p in dados["palavras"] if p["texto"]}
    return "; ".join(n for f, n in dados["interlocutores"].items() if f in usados)


def _hash_curto(dados):
    return dados["original"]["sha256"][:16]


def preferencias(raiz):
    try:
        return json.loads((Path(raiz) / PREFERENCIAS).read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}


def campos_padrao(proj, raiz):
    d = proj.dados
    proc = d.get("processamento", {})
    quando = proc.get("transcricao", {}).get("quando", "")
    resp = preferencias(raiz).get("responsavel", {})
    cabecalho = [
        _campo("titulo", "Título", "Transcrição de áudio"),
        _campo("arquivo", "Arquivo", d["original"]["nome"]),
        _campo("sha256", "Hash SHA-256 do original", d["original"]["sha256"], protegido=True),
        _campo("duracao", "Duração", tempo(proc.get("transcricao", {}).get("duracao_s", 0))),
        _campo("transcrito_em", "Data/hora da transcrição", _data(quando)),
        _campo("interlocutores", "Interlocutores", _nomes_usados(d)),
        _campo("legenda", "Legenda das marcações", LEGENDA),
        _campo("melhoria", "Melhoria de áudio", _texto_melhoria(proc.get("melhoria"))),
        _campo("vocabulario", "Vocabulário informado ao programa",
               ", ".join(d.get("opcoes", {}).get("vocabulario") or []) or "Nenhum"),
        _campo("programa", "Programa e modelos",
               f"{NOME_APP} {VERSAO}; transcrição: Whisper large-v3 (faster-whisper, int8); "
               f"segunda escuta: {MODELO_SEGUNDA_ESCUTA.split('/')[-1]}; interlocutores: "
               f"{MODELO_DIARIZACAO.split('/')[-1]}; revisão humana registrada no histórico do projeto"),
    ]
    rodape = [
        _campo("pagina", "Paginação", "Página X de Y"),
        _campo("arquivo_hash", "Arquivo e hash", f"{d['original']['nome']} · SHA-256 {_hash_curto(d)}…",
               protegido=True),
        _campo("gerado_em", "Data de geração", "preenchida ao gerar"),
        _campo("resp_nome", "Responsável", resp.get("nome", "")),
        _campo("resp_cargo", "Cargo", resp.get("cargo", "")),
        _campo("resp_matricula", "Matrícula", resp.get("matricula", "")),
        _campo("assinatura", "Assinatura", "________________________________"),
    ]
    return {"cabecalho": cabecalho, "rodape": rodape}


def _texto_melhoria(m):
    if not m:
        return "Nenhuma (transcrição feita sobre o áudio original)"
    usos = {"ouvir": "na escuta durante a revisão",
            "motores": "na transcrição automática e na identificação de interlocutores"}
    nivel = {"leve": "leve", "medio": "médio", "forte": "forte"}[m["nivel"]]
    return (f"Áudio processado com {m['descricao']} (nível {nivel}), em cópia, usada "
            f"{' e '.join(usos[u] for u in m['uso'])}. O arquivo original não foi alterado.")


def _data(iso):
    try:
        return datetime.fromisoformat(iso).strftime("%d/%m/%Y %H:%M")
    except (TypeError, ValueError):
        return ""


def campos_do_projeto(proj, raiz):
    """Os últimos campos usados neste projeto (ou o padrão), com os protegidos recalculados."""
    salvos = proj.dados.get("exportacao", {}).get("campos")
    return validar_campos(proj, raiz, salvos) if salvos else campos_padrao(proj, raiz)


def validar_campos(proj, raiz, campos):
    padrao = campos_padrao(proj, raiz)
    saida = {}
    for parte in ("cabecalho", "rodape"):
        base = {c["id"]: c for c in padrao[parte]}
        lista = []
        for c in (campos or {}).get(parte) or []:
            if not isinstance(c, dict) or not isinstance(c.get("id"), str):
                raise ExportacaoInvalida("Campo inválido.")
            novo = {"id": c["id"][:40], "rotulo": str(c.get("rotulo", ""))[:120],
                    "valor": str(c.get("valor", ""))[:4000], "incluir": bool(c.get("incluir", True))}
            if c["id"] in base and base[c["id"]].get("protegido"):
                novo = base[c["id"]] | {"incluir": novo["incluir"]}  # hash: só incluir ou remover
            lista.append(novo)
        for cid, c in base.items():  # um campo protegido nunca some da lista: no máximo fica desmarcado
            if c.get("protegido") and not any(x["id"] == cid for x in lista):
                lista.append(c | {"incluir": False})
        saida[parte] = lista
    return saida


# ---------- conteúdo ----------
def falas_do_documento(dados):
    """[(inicio, fim, interlocutor, texto)] como vai ao documento (marcações aplicadas, item 3)."""
    nomes, linhas = dados["interlocutores"], []
    for n, fala in enumerate(dados["falas"]):
        texto = marcacoes.texto_da_fala(fala, dados, final=n == len(dados["falas"]) - 1)
        if texto:
            linhas.append((fala["inicio"], fala["fim"], nomes.get(fala["falante"], "Interlocutor não identificado"),
                           texto))
    return linhas


def _incluidos(lista, gerado_em, pagina=None):
    saida = []
    for c in lista:
        if not c["incluir"]:
            continue
        valor = c["valor"]
        if c["id"] == "gerado_em":
            valor = gerado_em
        if c["id"] == "pagina":
            if pagina is None:
                continue
            valor = pagina
        saida.append((c["id"], c["rotulo"], valor))
    return saida


def _linha_rodape(itens):
    """Rodapé em texto: "Responsável: Fulano · Cargo: X · Página 1 de 3 …"."""
    partes = []
    for cid, rotulo, valor in itens:
        if not valor:
            continue
        partes.append(valor if cid in ("pagina", "arquivo_hash") else f"{rotulo}: {valor}")
    return " · ".join(partes)


# ---------- formatos ----------
def gerar_txt(caminho, dados, campos, gerado_em):
    linhas = [f"{r}: {v}" for _, r, v in _incluidos(campos["cabecalho"], gerado_em)]
    linhas.append("")
    linhas += [f"[{tempo(i)}] {quem}: {texto}" for i, _, quem, texto in falas_do_documento(dados)]
    rodape = _incluidos(campos["rodape"], gerado_em)
    if rodape:
        linhas += ["", "-" * 60] + [f"{r}: {v}" for _, r, v in rodape]
    Path(caminho).write_text("\n".join(linhas) + "\n", encoding="utf-8")


def _srt_tempo(s):
    ms = int(round(s * 1000))
    return f"{ms // 3600000:02d}:{ms % 3600000 // 60000:02d}:{ms % 60000 // 1000:02d},{ms % 1000:03d}"


def _tokens_com_tempo(fala, dados):
    tokens, ultimo = [], fala["inicio"]
    for p in marcacoes.partes_da_fala(fala, dados):
        if p.get("sugestao") or not p["texto"]:
            continue
        if p["tipo"] == "palavra":
            w = dados["palavras"][p["palavra"]]
            ini, fim = w["inicio"], w["fim"]
        elif p["tipo"] == "marcacao":
            ini, fim = p["marcacao"]["inicio"], p["marcacao"]["fim"]
        elif p["tipo"] == "insercao":
            ini = fim = p["insercao"]["inicio"]
        else:  # pausa: fica entre a palavra anterior e a seguinte
            ini = fim = ultimo
        ultimo = max(ultimo, fim)
        # texto com várias palavras (correção digitada, decisão de marcação): reparte o tempo
        inteiro = p["tipo"] == "pausa" or (p["tipo"] == "marcacao" and not p.get("decidida"))
        partes = [p["texto"]] if inteiro else p["texto"].split()
        passo = (fim - ini) / len(partes)
        tokens += [(w, ini + k * passo, ini + (k + 1) * passo) for k, w in enumerate(partes)]
    return tokens


def _quebrar(texto, largura=42):
    linhas, atual = [], ""
    for w in re.findall(r"\[[^\]]*\]\S*|\S+", texto):  # marcação [ ... ] nunca é partida
        if atual and len(atual) + 1 + len(w) > largura:
            linhas.append(atual)
            atual = w
        else:
            atual = f"{atual} {w}".strip()
    return linhas + ([atual] if atual else [])


def gerar_srt(caminho, dados, campos, gerado_em, max_s=7.0, largura=42):
    """Uma legenda por trecho de até ~7 s e 2 linhas, com o interlocutor no início."""
    blocos = []
    nomes = dados["interlocutores"]
    for fala in dados["falas"]:
        prefixo = nomes.get(fala["falante"], "Interlocutor não identificado") + ": "

        def cabe(grupo):
            return len(_quebrar(prefixo + " ".join(t[0] for t in grupo), largura)) <= 2

        grupo = []
        for tok in _tokens_com_tempo(fala, dados) + [None]:
            if tok is not None and (not grupo or (tok[2] - grupo[0][1] <= max_s and cabe(grupo + [tok]))):
                grupo.append(tok)
                continue
            if grupo:
                ini = grupo[0][1]
                fim = max(grupo[-1][2], ini + 0.8)
                blocos.append((ini, fim, prefixo + " ".join(t[0] for t in grupo)))
            grupo = [tok] if tok else []
    saida = []
    for n, (ini, fim, texto) in enumerate(blocos, 1):
        if n < len(blocos):
            fim = min(fim, blocos[n][0])  # sem sobrepor a legenda seguinte
        saida.append(f"{n}\n{_srt_tempo(ini)} --> {_srt_tempo(fim)}\n" + "\n".join(_quebrar(texto, largura)) + "\n")
    Path(caminho).write_text("\n".join(saida), encoding="utf-8")


def gerar_xlsx(caminho, dados, campos, gerado_em):
    from openpyxl import Workbook
    from openpyxl.styles import Alignment, Font

    wb = Workbook()
    aba = wb.active
    aba.title = "Transcrição"
    aba.append(["Início", "Fim", "Interlocutor", "Fala"])
    for ini, fim, quem, texto in falas_do_documento(dados):
        aba.append([tempo(ini), tempo(fim), quem, texto])
    for c in aba[1]:
        c.font = Font(bold=True)
    for linha in aba.iter_rows(min_row=2):
        linha[3].alignment = Alignment(wrap_text=True, vertical="top")
    for col, larg in zip("ABCD", (11, 11, 24, 100)):
        aba.column_dimensions[col].width = larg
    aba.freeze_panes = "A2"

    cab = wb.create_sheet("Cabeçalho")
    cab.append(["Campo", "Valor"])
    for _, rotulo, valor in _incluidos(campos["cabecalho"], gerado_em) + _incluidos(campos["rodape"], gerado_em):
        cab.append([rotulo, valor])
    for c in cab[1]:
        c.font = Font(bold=True)
    for linha in cab.iter_rows(min_row=2):
        linha[1].alignment = Alignment(wrap_text=True, vertical="top")
    cab.column_dimensions["A"].width = 30
    cab.column_dimensions["B"].width = 100
    # nada vira fórmula: uma fala ou um nome que comece com "=" (ou +, -, @) seria executado pelo Excel
    for planilha in wb.worksheets:
        for linha in planilha.iter_rows():
            for celula in linha:
                if celula.data_type == "f":
                    celula.data_type = "s"
    wb.save(caminho)


def _campo_word(paragrafo, codigo):
    """Campo do Word (PAGE / NUMPAGES), atualizado pelo próprio Word ao abrir e imprimir."""
    from docx.oxml import OxmlElement
    from docx.oxml.ns import qn

    run = paragrafo.add_run()
    for tipo, texto in (("begin", None), (None, codigo), ("separate", None), (None, "1"), ("end", None)):
        if tipo:
            el = OxmlElement("w:fldChar")
            el.set(qn("w:fldCharType"), tipo)
        elif texto == codigo:
            el = OxmlElement("w:instrText")
            el.set(qn("xml:space"), "preserve")
            el.text = f" {codigo} "
        else:
            el = OxmlElement("w:t")
            el.text = texto
        run._r.append(el)
    return run


def gerar_docx(caminho, dados, campos, gerado_em):
    from docx import Document
    from docx.enum.text import WD_ALIGN_PARAGRAPH
    from docx.shared import Cm, Pt

    doc = Document()
    estilo = doc.styles["Normal"]
    estilo.font.name = "Arial"
    estilo.font.size = Pt(11)
    doc.styles["Footer"].font.size = Pt(8)  # vale também para os números de página (campos)

    cab = _incluidos(campos["cabecalho"], gerado_em)
    titulo = next((v for cid, _, v in cab if cid == "titulo"), None)
    if titulo:
        t = doc.add_paragraph()
        t.alignment = WD_ALIGN_PARAGRAPH.CENTER
        r = t.add_run(titulo)
        r.bold = True
        r.font.size = Pt(14)
    tabela = doc.add_table(rows=0, cols=2)
    tabela.style = "Table Grid"
    for cid, rotulo, valor in cab:
        if cid == "titulo":
            continue
        linha = tabela.add_row().cells
        linha[0].text, linha[1].text = rotulo, valor
        linha[0].width, linha[1].width = Cm(4.5), Cm(12)
        linha[0].paragraphs[0].runs[0].bold = True
        for cel in linha:
            for p in cel.paragraphs:
                for run in p.runs:
                    run.font.size = Pt(9)
    doc.add_paragraph()
    for ini, _, quem, texto in falas_do_documento(dados):
        p = doc.add_paragraph()
        p.paragraph_format.space_after = Pt(6)
        p.add_run(f"[{tempo(ini)}] ")
        p.add_run(f"{quem}: ").bold = True
        p.add_run(texto)

    rod = _incluidos(campos["rodape"], gerado_em, pagina="__PAGINA__")
    if rod:
        p = doc.sections[0].footer.paragraphs[0]
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        texto = _linha_rodape(rod)
        antes, _, depois = texto.partition("__PAGINA__")
        if _:
            p.add_run(antes + "Página ")
            _campo_word(p, "PAGE")
            p.add_run(" de ")
            _campo_word(p, "NUMPAGES")
            p.add_run(depois)
        else:
            p.add_run(texto)
        for run in p.runs:
            run.font.size = Pt(8)
    doc.save(caminho)


def _fontes_pdf():
    for normal, negrito in FONTES_PDF:
        if Path(normal).exists() and Path(negrito).exists():
            return normal, negrito
    raise ExportacaoInvalida("Nenhuma fonte com acentos encontrada para o PDF (procurei Arial e DejaVu).")


LINHA = {"new_x": "LMARGIN", "new_y": "NEXT"}  # fpdf2: depois de cada bloco, volta à margem esquerda


def gerar_pdf(caminho, dados, campos, gerado_em):
    from fpdf import FPDF

    normal, negrito = _fontes_pdf()
    rod = _incluidos(campos["rodape"], gerado_em, pagina="Página {pagina} de {nb}")
    texto_rodape = _linha_rodape(rod)

    class Documento(FPDF):
        def footer(self):
            if not texto_rodape:
                return
            self.set_y(-18)
            self.set_font("Fonte", size=7.5)
            self.set_text_color(80)
            self.multi_cell(0, 3.6, texto_rodape.replace("{pagina}", str(self.page_no())), align="C", **LINHA)
            self.set_text_color(0)

    pdf = Documento(format="A4")
    pdf.set_margins(20, 18, 20)
    pdf.set_auto_page_break(True, margin=24)
    pdf.add_font("Fonte", "", normal)
    pdf.add_font("Fonte", "B", negrito)
    pdf.alias_nb_pages("{nb}")
    pdf.add_page()
    largura = pdf.w - pdf.l_margin - pdf.r_margin

    cab = _incluidos(campos["cabecalho"], gerado_em)
    titulo = next((v for cid, _, v in cab if cid == "titulo"), None)
    if titulo:
        pdf.set_font("Fonte", "B", 14)
        pdf.multi_cell(0, 8, titulo, align="C", **LINHA)
        pdf.ln(2)
    for cid, rotulo, valor in cab:
        if cid == "titulo":
            continue
        pdf.set_font("Fonte", "B", 8.5)
        pdf.multi_cell(largura, 4.5, rotulo, **LINHA)
        pdf.set_font("Fonte", "", 8.5)
        pdf.multi_cell(largura, 4.5, valor or "—", align="L", **LINHA)
        pdf.ln(1)
    pdf.ln(3)
    pdf.set_draw_color(150)
    pdf.line(pdf.l_margin, pdf.get_y(), pdf.w - pdf.r_margin, pdf.get_y())
    pdf.ln(4)
    for ini, _, quem, texto in falas_do_documento(dados):
        # write() com troca de fonte: o texto literal vai exatamente como está
        pdf.set_font("Fonte", "", 11)
        pdf.write(6, f"[{tempo(ini)}] ")
        pdf.set_font("Fonte", "B", 11)
        pdf.write(6, f"{quem}: ")
        pdf.set_font("Fonte", "", 11)
        pdf.write(6, texto)
        pdf.ln(7.5)
    pdf.output(caminho)


GERADORES = {"docx": gerar_docx, "pdf": gerar_pdf, "srt": gerar_srt, "txt": gerar_txt, "xlsx": gerar_xlsx}


def _nome_base(dados, momento):
    base = re.sub(r"[^A-Za-z0-9._-]+", "-", Path(dados["original"]["nome"]).stem).strip("-")[:50] or "transcricao"
    return f"{base}_transcricao_{momento:%Y%m%d-%H%M%S}"


def exportar(proj, raiz, formatos, campos):
    formatos = [f for f in FORMATOS if f in set(formatos or [])]
    if not formatos:
        raise ExportacaoInvalida("Escolha ao menos um formato.")
    campos = validar_campos(proj, raiz, campos)
    momento = datetime.now().astimezone()
    gerado_em = momento.strftime("%d/%m/%Y %H:%M")
    pasta = proj.pasta / "exportacoes"
    pasta.mkdir(exist_ok=True)
    base = _nome_base(proj.dados, momento)
    arquivos = []
    for fmt in formatos:
        caminho = pasta / f"{base}.{fmt}"
        GERADORES[fmt](caminho, proj.dados, campos, gerado_em)
        arquivos.append({"formato": fmt, "nome": caminho.name, "sha256": sha256(caminho),
                         "bytes": caminho.stat().st_size})

    pendentes = sum(1 for m in proj.dados.get("marcacoes", [])
                    if m["origem"] == "ia" and not m.get("decisao") and marcacoes.TIPOS[m["tipo"]]["substitui"])
    proj.dados.setdefault("exportacao", {})["campos"] = campos
    proj.salvar()
    proj.registrar("exportacao", {"arquivos": arquivos, "campos": copy.deepcopy(campos),
                                  "marcacoes_pendentes": pendentes, "gerado_em": agora()}, origem="usuario")
    _lembrar_responsavel(raiz, campos)
    return arquivos


def _lembrar_responsavel(raiz, campos):
    valores = {c["id"]: c["valor"] for c in campos["rodape"]}
    prefs = preferencias(raiz)
    prefs["responsavel"] = {"nome": valores.get("resp_nome", ""), "cargo": valores.get("resp_cargo", ""),
                            "matricula": valores.get("resp_matricula", "")}
    caminho = Path(raiz) / PREFERENCIAS
    tmp = caminho.with_suffix(".tmp")
    tmp.write_text(json.dumps(prefs, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(caminho)
