@echo off
rem Degrava IA - abre a tela de revisao no navegador (funciona sem internet)
rem Usa o Python portatil oficial (python.org) que vem na pasta "python": nada e instalado no Windows.
cd /d "%~dp0"
if exist "python\python.exe" goto rodar
echo A pasta "python" nao foi encontrada. Descompacte o arquivo DegravaIA.zip inteiro
echo (botao direito no zip, "Extrair tudo") e tente de novo.
pause
exit /b 1
:rodar
"python\python.exe" abrir.py
