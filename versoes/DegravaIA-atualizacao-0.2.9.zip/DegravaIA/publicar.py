"""Publica a versão atual para a atualização automática.

    python publicar.py --novidades "o que mudou"

1. Gera os pacotes (empacotar.py).
2. Põe o pacote de código em versoes/ e o atualizacao.json na raiz do repositório público
   de versões (REPO_VERSOES, clonado ao lado desta pasta: ../degravaia-versoes).
3. Faz o commit e o push. Em poucos minutos os Degrava IA abertos mostram o aviso.

Recusa publicar com alterações sem commit no código ou se a versão já foi publicada.
O pacote completo (DegravaIA.zip, ~43 MB) não vai para o repositório: entrega-se à parte.
"""
import argparse
import json
import re
import shutil
import subprocess
import sys
from pathlib import Path

AQUI = Path(__file__).resolve().parent
LEIA_ME = """# Degrava IA — versões

Pacotes da atualização automática do Degrava IA. Não há código-fonte aqui.

- `atualizacao.json`: a versão mais recente, o SHA-256 do pacote e as novidades
  (é o que o app consulta);
- `versoes/`: o pacote de código de cada versão.

Publicado pelo `publicar.py` do repositório do código.
"""


def git(*args, cwd):
    return subprocess.run(["git", *args], cwd=cwd, check=True, capture_output=True, text=True).stdout


def numeros(v):
    return tuple(int(n) for n in re.findall(r"\d+", v)[:3])


def principal():
    ap = argparse.ArgumentParser(description="Publica a versão atual do Degrava IA")
    ap.add_argument("--novidades", required=True, help="o que mudou, mostrado ao usuário no aviso")
    ap.add_argument("--repo", default=str(AQUI.parent / "degravaia-versoes"), help="clone do repositório de versões")
    args = ap.parse_args()
    repo = Path(args.repo)

    if git("status", "--porcelain", cwd=AQUI).strip():
        sys.exit("Há alterações sem commit no código. Faça o commit antes de publicar.")
    if not (repo / ".git").is_dir():
        sys.exit(f"Repositório de versões não encontrado em {repo}.")
    versao = re.search(r'^VERSAO = "([^"]+)"', (AQUI / "degravaia" / "config.py").read_text("utf-8"), re.M).group(1)
    publicado = repo / "atualizacao.json"
    if publicado.is_file() and numeros(json.loads(publicado.read_text("utf-8"))["versao"]) >= numeros(versao):
        sys.exit(f"A versão {versao} não é mais nova que a publicada. Aumente VERSAO em degravaia/config.py.")

    import empacotar

    empacotar.principal(args.novidades)
    origem = AQUI / "downloads" / f"versao-{versao}"
    manifesto = json.loads((origem / "atualizacao.json").read_text("utf-8"))
    (repo / "versoes").mkdir(exist_ok=True)
    shutil.copy2(origem / manifesto["arquivo"], repo / "versoes" / manifesto["arquivo"])
    shutil.copy2(origem / "atualizacao.json", publicado)
    (repo / "README.md").write_text(LEIA_ME, "utf-8")

    git("add", "-A", cwd=repo)
    git("commit", "-m", f"Degrava IA {versao}\n\n{args.novidades}", cwd=repo)
    git("push", "-u", "origin", "HEAD:main", cwd=repo)
    print(f"Versão {versao} publicada. Os Degrava IA abertos mostram o aviso em poucos minutos.")


if __name__ == "__main__":
    principal()
