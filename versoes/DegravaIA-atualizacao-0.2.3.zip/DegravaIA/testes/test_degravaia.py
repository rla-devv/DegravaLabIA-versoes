"""Testes das regras principais (rodam sem os modelos e sem internet).

    python -m unittest discover -s testes -v
"""
import copy
import http.client
import json
import shutil
import sys
import tempfile
import threading
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from degravaia import andamento, atualizacao, exportacao, hardware, marcacoes, montagem, motores, revisao, servidor, trechos  # noqa: E402
from degravaia.projeto import Projeto, sha256  # noqa: E402


def palavra(texto, inicio, fim, falante="A", prob=0.9, **extra):
    return {"texto": texto, "inicio": inicio, "fim": fim, "prob": prob, "falante": falante,
            "suspeita_alucinacao": False, **extra}


def projeto_de_teste(pasta):
    """Projeto pequeno: 2 pessoas, uma palavra duvidosa e uma fala com sobreposição."""
    original = Path(pasta) / "depoimento.wav"
    original.write_bytes(b"RIFF" + bytes(range(256)) * 4)
    proj = Projeto.criar(original, raiz=Path(pasta) / "projetos")
    d = proj.dados
    d["palavras"] = [
        palavra("Eu", 0.0, 0.3), palavra("vi", 0.3, 0.6), palavra("carro", 0.6, 1.0, prob=0.1),
        palavra("ontem.", 1.0, 1.4),
        palavra("Sim,", 2.0, 2.3, "B"), palavra("é", 2.3, 2.5, "B"), palavra("verdade.", 2.5, 3.0, "B"),
    ]
    d["segunda_escuta"] = [{"texto": t, "inicio": i, "fim": f} for t, i, f in
                           [("eu", 0.0, 0.3), ("vi", 0.3, 0.6), ("caro", 0.6, 1.0), ("ontem", 1.0, 1.4),
                            ("sim", 2.0, 2.3), ("é", 2.3, 2.5), ("verdade", 2.5, 3.0)]]
    d["processamento"] = {"interlocutores": {"sobreposicoes": [{"inicio": 2.3, "fim": 2.5}]},
                          "transcricao": {"duracao_s": 3.0, "quando": "2026-10-18T10:00:00+00:00"}}
    d["interlocutores"] = montagem.rotular_interlocutores(d["palavras"])
    d["falas"] = montagem.montar_falas(d["palavras"])
    marcacoes.gerar(d)
    proj.salvar()
    return proj


class Montagem(unittest.TestCase):
    def test_regioes_por_turno_nao_se_sobrepoem(self):
        turnos = [{"inicio": 0.0, "fim": 2.0, "falante": "A"}, {"inicio": 2.1, "fim": 2.4, "falante": "B"},
                  {"inicio": 2.5, "fim": 5.0, "falante": "A"}, {"inicio": 7.0, "fim": 9.0, "falante": "B"}]
        r = montagem.regioes_por_turno(turnos)
        self.assertTrue(all(a[1] <= b[0] for a, b in zip(r, r[1:])), r)  # nada transcrito duas vezes

    def test_palavra_vai_para_o_turno_de_maior_sobreposicao(self):
        ps = [palavra("x", 1.8, 2.2, falante=None)]
        montagem.atribuir_falantes(ps, [{"inicio": 0, "fim": 1.9, "falante": "A"},
                                        {"inicio": 1.9, "fim": 3, "falante": "B"}])
        self.assertEqual(ps[0]["falante"], "B")


class Literalidade(unittest.TestCase):
    def test_palavras_empilhadas_sao_suspeitas_e_nao_somem(self):
        ps = [palavra("O", 5.0, 5.0), palavra("que", 5.0, 5.0), palavra("foi?", 5.0, 5.0), palavra("Não", 5.2, 5.5)]
        motores.marcar_empilhadas(ps)
        self.assertEqual([p["suspeita_alucinacao"] for p in ps], [True, True, True, False])
        self.assertEqual(len(ps), 4)

    def test_a_e_sozinhos_nao_sao_hesitacao(self):
        self.assertEqual(marcacoes.canonico("a"), "a")
        self.assertEqual(marcacoes.canonico("e"), "e")
        for h in ("eh", "eeh", "ahn", "hum", "hmm"):
            self.assertEqual(marcacoes.canonico(h), "<hesitação>", h)

    def test_palavras_grudadas_pela_segunda_escuta(self):
        self.assertEqual(marcacoes.colados(["e", "bem", "aí"], ["ebem", "aí"]), {0, 1})

    def test_versao_limpa_nao_apaga_palavras_reais(self):
        self.assertEqual(trechos.limpar("Eh, a gente a gente foi lá e, né, voltou."), "A gente foi lá e, voltou.")


class Marcacoes(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.mkdtemp()
        self.proj = projeto_de_teste(self.tmp)

    def tearDown(self):
        shutil.rmtree(self.tmp, ignore_errors=True)

    def test_palavra_duvidosa_vira_ininteligivel_sem_entrar_no_texto(self):
        texto = montagem.texto_corpo(self.proj.dados)
        self.assertIn("[ininteligível 00:00:00]", texto)
        self.assertNotIn("carro", texto)  # sugestão do motor nunca vai ao documento sozinha
        m = next(m for m in self.proj.dados["marcacoes"] if m["tipo"] == "ininteligivel")
        self.assertEqual([s["texto"] for s in m["sugestoes"]], ["carro", "caro"])

    def test_sobreposicao_mantem_as_palavras(self):
        texto = montagem.texto_corpo(self.proj.dados)
        self.assertIn("[sobreposição de vozes] é", texto)

    def test_decisao_com_duvida_historico_e_desfazer(self):
        original = montagem.texto_corpo(self.proj.dados)
        m = next(m for m in self.proj.dados["marcacoes"] if m["tipo"] == "ininteligivel")
        revisao.alterar(self.proj, "decidir_marcacao", {"marcacao": m["id"], "modo": "duvida", "texto": "carro"})
        revisao.alterar(self.proj, "renomear_interlocutor", {"falante": "B", "depois": "Investigado"})
        revisao.alterar(self.proj, "editar_palavra", {"palavra": 0, "depois": "Eu,"})
        texto = montagem.texto_corpo(Projeto(self.proj.pasta).dados)  # salvo em disco
        self.assertIn("carro (?)", texto)
        self.assertIn("Investigado:", texto)
        for _ in range(3):
            revisao.desfazer(self.proj)
        self.assertEqual(montagem.texto_corpo(Projeto(self.proj.pasta).dados), original)
        acoes = [l["acao"] for l in revisao.historico(self.proj)]
        self.assertEqual(acoes.count("desfazer"), 3)  # desfazer acrescenta, nunca apaga

    def test_nao_ha_palavra_aqui(self):
        m = next(m for m in self.proj.dados["marcacoes"] if m["tipo"] == "ininteligivel")
        revisao.alterar(self.proj, "decidir_marcacao", {"marcacao": m["id"], "modo": "sem_palavra"})
        texto = montagem.texto_corpo(Projeto(self.proj.pasta).dados)
        self.assertIn("Eu vi ontem.", texto)  # nem a marcação nem a palavra do motor
        self.assertNotIn("ininteligível", texto)
        self.assertEqual(Projeto(self.proj.pasta).dados["palavras"][2]["texto"], "carro")  # texto da IA guardado
        revisao.desfazer(self.proj)
        self.assertIn("[ininteligível", montagem.texto_corpo(Projeto(self.proj.pasta).dados))
        with self.assertRaises(revisao.AlteracaoInvalida):  # não serve para apagar palavras numa reanálise
            revisao.alterar(self.proj, "aceitar_reanalise", {"palavras": [0], "modo": "sem_palavra"})

    def test_juntar_interlocutores_e_desfazer(self):
        original = montagem.texto_corpo(self.proj.dados)
        antes = copy.deepcopy(self.proj.dados["interlocutores"])
        revisao.alterar(self.proj, "juntar_interlocutores", {"de": "B", "para": "A", "remover_sobreposicoes": True})
        d = Projeto(self.proj.pasta).dados
        self.assertEqual(list(d["interlocutores"]), ["A"])
        self.assertTrue(all(p["falante"] == "A" for p in d["palavras"]))
        self.assertEqual(d["palavras"][4]["falante_ia"], "B")  # o que a IA disse fica guardado
        self.assertFalse(any(m["tipo"] == "sobreposicao" for m in d["marcacoes"]))
        self.assertEqual(len(d["falas"]), 1)
        self.assertNotIn("sobreposição", montagem.texto_corpo(d))
        revisao.desfazer(self.proj)
        d = Projeto(self.proj.pasta).dados
        self.assertEqual(d["interlocutores"], antes)
        self.assertEqual(montagem.texto_corpo(d), original)
        with self.assertRaises(revisao.AlteracaoInvalida):
            revisao.alterar(self.proj, "juntar_interlocutores", {"de": "A", "para": "A"})

    def test_texto_da_ia_e_preservado(self):
        revisao.alterar(self.proj, "editar_palavra", {"palavra": 1, "depois": "olhei"})
        p = Projeto(self.proj.pasta).dados["palavras"][1]
        self.assertEqual((p["texto"], p["texto_ia"], p["revisado"]), ("olhei", "vi", True))


class Exportacao(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.mkdtemp()
        self.proj = projeto_de_teste(self.tmp)
        self.raiz = Path(self.tmp) / "projetos"

    def tearDown(self):
        shutil.rmtree(self.tmp, ignore_errors=True)

    def test_hash_nao_pode_ser_alterado(self):
        campos = exportacao.campos_padrao(self.proj, self.raiz)
        hash_campo = next(c for c in campos["cabecalho"] if c["id"] == "sha256")
        hash_campo["valor"] = "adulterado"
        validos = exportacao.validar_campos(self.proj, self.raiz, campos)
        real = next(c for c in validos["cabecalho"] if c["id"] == "sha256")
        self.assertEqual(real["valor"], self.proj.dados["original"]["sha256"])

    def test_exportacao_registra_hash_de_cada_arquivo(self):
        arquivos = exportacao.exportar(self.proj, self.raiz, ["txt", "srt"], exportacao.campos_padrao(self.proj, self.raiz))
        pasta = self.proj.pasta / "exportacoes"
        for a in arquivos:
            self.assertEqual(sha256(pasta / a["nome"]), a["sha256"])
        txt = (pasta / next(a["nome"] for a in arquivos if a["formato"] == "txt")).read_text(encoding="utf-8")
        self.assertIn(self.proj.dados["original"]["sha256"], txt)
        self.assertIn("[ininteligível 00:00:00]", txt)
        ultima = revisao.historico(self.proj)[-1]
        self.assertEqual((ultima["acao"], len(ultima["detalhes"]["arquivos"])), ("exportacao", 2))

    def test_legenda_tem_no_maximo_duas_linhas(self):
        self.proj.dados["palavras"][0]["texto"] = "palavra " * 30
        arquivos = exportacao.exportar(self.proj, self.raiz, ["srt"], exportacao.campos_padrao(self.proj, self.raiz))
        srt = (self.proj.pasta / "exportacoes" / arquivos[0]["nome"]).read_text(encoding="utf-8")
        for bloco in srt.strip().split("\n\n"):
            self.assertLessEqual(len(bloco.split("\n")) - 2, 2, bloco)


class Hardware(unittest.TestCase):
    def test_falha_da_gpu_repete_na_cpu(self):
        usados = []

        def tarefa(disp):
            usados.append(disp)
            if disp == "cuda":
                raise RuntimeError("Library cublas64_12.dll is not found or cannot be loaded")
            return "ok"

        self.assertEqual(hardware.com_recuo_para_cpu(tarefa, log=lambda m: None, disp="cuda"), "ok")
        self.assertEqual(usados, ["cuda", "cpu"])

    def test_outros_erros_nao_sao_escondidos(self):
        def tarefa(disp):
            raise ValueError("arquivo corrompido")

        with self.assertRaises(ValueError):
            hardware.com_recuo_para_cpu(tarefa, log=lambda m: None, disp="cuda")


def pacote_zip(arquivos):
    import io
    import zipfile

    b = io.BytesIO()
    with zipfile.ZipFile(b, "w") as z:
        for nome, conteudo in arquivos.items():
            z.writestr(nome, conteudo)
    return b.getvalue()


class Atualizacao(unittest.TestCase):
    def setUp(self):
        self.app = Path(tempfile.mkdtemp())
        for rel, texto in {"degravaia/config.py": 'VERSAO = "0.1.0"\n', "degravaia/velho.py": "x\n",
                           "requirements.txt": "a\n", "projetos/p/projeto.json": "{}",
                           "arquivos-do-app.txt": "degravaia/config.py\ndegravaia/velho.py\nrequirements.txt\n"}.items():
            (self.app / rel).parent.mkdir(parents=True, exist_ok=True)
            (self.app / rel).write_text(texto)

    def tearDown(self):
        shutil.rmtree(self.app, ignore_errors=True)

    def test_recusa_pacote_que_sai_da_pasta_ou_mexe_em_projetos(self):
        base = {"DegravaIA/degravaia/config.py": "x", "DegravaIA/arquivos-do-app.txt": "x"}
        for ruim in ("DegravaIA/../fora.py", "DegravaIA/projetos/p/projeto.json", "DegravaIA/python/python.exe",
                     "DegravaIA/modelos/hub/x", "/etc/passwd", "outro/x.py", "DegravaIA/C:/x"):
            with self.assertRaises(atualizacao.AtualizacaoInvalida, msg=ruim):
                atualizacao.ler_pacote(pacote_zip(base | {ruim: "x"}))

    def test_troca_o_codigo_guarda_o_anterior_e_nao_toca_nos_projetos(self):
        novos = atualizacao.ler_pacote(pacote_zip({
            "DegravaIA/degravaia/config.py": 'VERSAO = "0.2.0"\n', "DegravaIA/degravaia/novo.py": "n\n",
            "DegravaIA/requirements.txt": "a\n",
            "DegravaIA/arquivos-do-app.txt": "degravaia/config.py\ndegravaia/novo.py\nrequirements.txt\n"}))
        mudou = atualizacao.aplicar(novos, self.app)
        self.assertIn('"0.2.0"', (self.app / "degravaia/config.py").read_text())
        self.assertTrue((self.app / "degravaia/novo.py").is_file())
        self.assertFalse((self.app / "degravaia/velho.py").exists())  # saiu da lista nova
        self.assertNotIn("requirements.txt", mudou)  # igual: não é reescrito
        copia = self.app / "versoes-anteriores/0.1.0"
        self.assertIn('"0.1.0"', (copia / "degravaia/config.py").read_text())
        self.assertTrue((copia / "degravaia/velho.py").is_file())
        self.assertEqual((self.app / "projetos/p/projeto.json").read_text(), "{}")

    def test_falha_volta_tudo_como_estava(self):
        import subprocess as sp
        from unittest import mock

        novos = atualizacao.ler_pacote(pacote_zip({
            "DegravaIA/degravaia/config.py": 'VERSAO = "0.2.0"\n', "DegravaIA/degravaia/novo.py": "n\n",
            "DegravaIA/requirements.txt": "b\n", "DegravaIA/arquivos-do-app.txt": "x\n"}))
        with mock.patch.object(atualizacao.subprocess, "run", side_effect=sp.CalledProcessError(1, "pip")):
            with self.assertRaises(sp.CalledProcessError):
                atualizacao.aplicar(novos, self.app)
        self.assertIn('"0.1.0"', (self.app / "degravaia/config.py").read_text())
        self.assertEqual((self.app / "requirements.txt").read_text(), "a\n")
        self.assertFalse((self.app / "degravaia/novo.py").exists())
        self.assertTrue((self.app / "degravaia/velho.py").exists())

    def test_so_oferece_versao_mais_nova(self):
        from unittest import mock

        for publicada, oferece in (("0.1.0", False), ("0.0.9", False), ("0.1.1", True), ("1.0.0", True)):
            m = json.dumps({"versao": publicada, "arquivo": f"p-{publicada}.zip", "sha256": "a" * 64}).encode()
            with mock.patch.object(atualizacao, "VERSAO", "0.1.0"), \
                    mock.patch.object(atualizacao, "_baixar", return_value=m):
                self.assertEqual(atualizacao.verificar() is not None, oferece, publicada)
        with mock.patch.object(atualizacao, "_baixar", side_effect=OSError("sem internet")):
            self.assertIsNone(atualizacao.verificar())
            with self.assertRaises(atualizacao.SemConexao):  # o botão "Buscar atualização" avisa
                atualizacao.verificar(avisar_sem_conexao=True)


class Vocabulario(unittest.TestCase):
    def test_limpa_e_limita_a_lista(self):
        v = motores.limpar_vocabulario("Cauã, Santo Ângelo;\n cauã ,, Brigada\x07 Militar")
        self.assertEqual(v, ["Cauã", "Santo Ângelo", "Brigada Militar"])
        self.assertLessEqual(len(motores.limpar_vocabulario(",".join(f"nome{i}" for i in range(200)))), 40)
        self.assertEqual(motores.limpar_vocabulario(""), [])

    def test_lista_vem_antes_do_modelo_de_fala_literal(self):
        from degravaia.config import PROMPT_HESITACOES

        self.assertTrue(motores.dicas(["Cauã"]).startswith("Cauã. "))
        self.assertTrue(motores.dicas(["Cauã"]).endswith(PROMPT_HESITACOES))
        self.assertEqual(motores.dicas([]), PROMPT_HESITACOES)


class Andamento(unittest.TestCase):
    def test_porcentagem_tempo_e_aprendizado(self):
        relogio = [0.0]
        a = andamento.Andamento(agora=lambda: relogio[0])
        self.assertEqual(a.estado()["falta_s"], None)  # ainda lendo o arquivo
        a.receber({"etapa": "preparar", "frac": 0.5, "duracao": 600, "disp": "cpu",
                   "etapas": ["preparar", "interlocutores", "transcricao", "segunda_escuta", "montagem"]})
        previsto = a.estado()["falta_s"]
        self.assertGreater(previsto, 1500)  # 10 min de áudio na CPU: ~33 min
        relogio[0] = 60
        a.receber({"etapa": "interlocutores", "frac": 0.5})
        e = a.estado()
        self.assertEqual((e["numero"], e["de"], e["etapa"]), (2, 5, "interlocutores"))
        self.assertTrue(e["etapas"][0]["feita"] and not e["etapas"][1]["feita"])
        self.assertGreater(e["porcentagem"], 0)
        # este computador está 2x mais rápido que o previsto: a estimativa encurta
        self.assertLess(e["falta_s"], previsto - 60)
        a.receber({"etapa": "interlocutores", "frac": 0.2})  # nunca anda para trás
        self.assertEqual(a.estado()["frac_etapa"], 0.5)
        for t, etapa in ((300, "transcricao"), (900, "segunda_escuta"), (950, "montagem")):
            relogio[0] = t
            a.receber({"etapa": etapa, "frac": 0})
        relogio[0] = 955
        self.assertLessEqual(a.estado()["porcentagem"], 99)
        pasta = tempfile.mkdtemp()
        a.aprender(pasta)
        aprendido = andamento.carregar_aprendido(pasta)["cpu"]
        self.assertAlmostEqual(aprendido["transcricao"], (600 - 30) / 600, places=3)
        b = andamento.Andamento(aprendido={"cpu": aprendido}, agora=lambda: 0)
        b.receber({"etapa": "preparar", "frac": 0.5, "duracao": 600, "disp": "cpu"})
        self.assertLess(b.estado()["falta_s"], previsto)  # a próxima previsão já usa o ritmo medido
        shutil.rmtree(pasta)


class ProcessoQueNaoFecha(unittest.TestCase):
    """No Windows com GPU, o processo de importação às vezes não fechava depois de salvar."""

    def test_importacao_termina_mesmo_se_o_processo_travar_ao_fechar(self):
        import subprocess
        import time
        from unittest import mock

        pasta = Path(tempfile.mkdtemp())
        (pasta / "envio").mkdir()
        arquivo = pasta / "envio" / "a.wav"
        arquivo.write_bytes(b"x")
        travado = [sys.executable, "-c", "import time; print('Projeto salvo em /x/projetos/123-a', flush=True); "
                   "time.sleep(600)"]

        def motor_falso(*_args):
            proc = subprocess.Popen(travado, stdout=subprocess.PIPE, text=True)
            proc.encerrado_por_nos = False
            return proc

        servidor._importacoes["t"] = {"estado": "rodando", "log": [], "projeto": None, "arquivo": "a.wav",
                                      "andamento": andamento.Andamento()}
        servidor._trava_motores.acquire()
        inicio = time.monotonic()
        with mock.patch.object(servidor, "_motor", motor_falso), mock.patch.object(servidor, "ESPERA_FECHAR_S", 1):
            servidor._rodar_importacao("t", arquivo, pasta, "pt", None, True)
        self.assertLess(time.monotonic() - inicio, 20)
        self.assertEqual(servidor._importacoes["t"]["estado"], "pronto")
        self.assertEqual(servidor._importacoes["t"]["projeto"], "123-a")
        self.assertTrue(servidor._trava_motores.acquire(blocking=False))  # liberou os motores
        servidor._trava_motores.release()
        shutil.rmtree(pasta, ignore_errors=True)

    def test_importar_encerra_sem_esperar_a_faxina(self):
        import subprocess

        codigo = ("import sys, threading, time; sys.argv=['x','verificar','/nao/existe'];"
                  "from degravaia import __main__ as m; threading.Thread(target=time.sleep, args=(600,)).start(); "
                  "m._sair_ja()")
        r = subprocess.run([sys.executable, "-c", codigo], cwd=Path(__file__).resolve().parent.parent, timeout=30)
        self.assertEqual(r.returncode, 0)  # uma thread presa não segura o processo


class Servidor(unittest.TestCase):
    """Item 12: só o próprio computador acessa, e outras páginas não alteram nada."""

    @classmethod
    def setUpClass(cls):
        cls.tmp = tempfile.mkdtemp()
        cls.proj = projeto_de_teste(cls.tmp)
        servidor.Manipulador.raiz = Path(cls.tmp) / "projetos"
        cls.srv = servidor.ThreadingHTTPServer(("127.0.0.1", 0), servidor.Manipulador)
        cls.porta = servidor.Manipulador.porta = cls.srv.server_address[1]
        threading.Thread(target=cls.srv.serve_forever, daemon=True).start()

    @classmethod
    def tearDownClass(cls):
        cls.srv.shutdown()
        cls.srv.server_close()
        shutil.rmtree(cls.tmp, ignore_errors=True)

    def pedir(self, metodo, caminho, corpo=None, cabecalhos=None):
        c = http.client.HTTPConnection("127.0.0.1", self.porta, timeout=5)
        h = {"Host": f"127.0.0.1:{self.porta}"} | (cabecalhos or {})
        c.request(metodo, caminho, body=json.dumps(corpo) if corpo is not None else None, headers=h)
        r = c.getresponse()
        return r.status, r.read()

    def test_lista_de_projetos(self):
        status, corpo = self.pedir("GET", "/api/projetos")
        self.assertEqual(status, 200)
        self.assertEqual(len(json.loads(corpo)["projetos"]), 1)

    def test_recusa_outro_host(self):
        status, _ = self.pedir("GET", "/api/projetos", cabecalhos={"Host": "malicioso.com"})
        self.assertEqual(status, 403)

    def test_recusa_alteracao_de_outra_pagina(self):
        url = f"/api/projetos/{self.proj.pasta.name}/desfazer"
        for origem in (None, "http://malicioso.com"):
            h = {"Content-Type": "application/json"} | ({"Origin": origem} if origem else {})
            status, _ = self.pedir("POST", url, {}, h)
            self.assertEqual(status, 403, origem)

    def test_nao_atualiza_com_projeto_aberto(self):
        from unittest import mock

        h = {"Content-Type": "application/json", "Origin": f"http://127.0.0.1:{self.porta}"}
        nova = {"versao": "9.0.0", "arquivo": "p.zip", "sha256": "a" * 64}
        with mock.patch.dict(servidor._atualizacao, nova=nova, consultado=9e12), \
                mock.patch.object(atualizacao, "instalar") as instalar:
            self.pedir("POST", "/api/aba", {"aba": "t1", "projeto": self.proj.pasta.name}, h)
            status, corpo = self.pedir("POST", "/api/atualizacao", {"versao": "9.0.0"}, h)
            self.assertEqual(status, 409)
            self.assertIn("projeto aberto", json.loads(corpo)["erro"])
            self.pedir("POST", "/api/aba", {"aba": "t1", "projeto": None}, h)  # fechou o projeto
            self.assertEqual(json.loads(self.pedir("GET", "/api/atualizacao")[1])["projetos_abertos"], [])
            instalar.assert_not_called()

    def test_excluir_projeto(self):
        import os
        import stat

        h = {"Content-Type": "application/json", "Origin": f"http://127.0.0.1:{self.porta}"}
        outro = projeto_de_teste(tempfile.mkdtemp())
        destino = servidor.Manipulador.raiz / (outro.pasta.name + "-outro")
        shutil.copytree(outro.pasta, destino)
        protegido = next((destino / "original").iterdir())
        os.chmod(protegido, stat.S_IREAD)  # como a cópia protegida do original
        url = f"/api/projetos/{destino.name}/excluir"
        self.pedir("POST", "/api/aba", {"aba": "t2", "projeto": destino.name}, h)
        self.assertEqual(self.pedir("POST", url, {}, h)[0], 409)  # aberto em outra aba
        self.pedir("POST", "/api/aba", {"aba": "t2", "projeto": None}, h)
        self.assertEqual(self.pedir("POST", url, {}, {"Content-Type": "application/json"})[0], 403)  # outra página
        self.assertEqual(self.pedir("POST", url, {}, h)[0], 200)
        self.assertFalse(destino.exists())
        self.assertTrue(self.proj.pasta.exists())  # só o escolhido sai
        self.assertEqual(self.pedir("POST", "/api/projetos/..%2F..%2Fetc/excluir", {}, h)[0], 404)

    def test_nao_sai_da_pasta_de_projetos(self):
        for caminho in ("/api/projetos/..%2F..%2Fetc", "/web/..%2Fservidor.py", "/api/projetos/%2Fetc%2Fpasswd"):
            status, _ = self.pedir("GET", caminho)
            self.assertEqual(status, 404, caminho)


if __name__ == "__main__":
    unittest.main()
