"""Rodada 4: teste da identificação de interlocutores (Etapa 1, item 5).

Monta uma "conversa" com falas de 2 ou 3 pessoas diferentes do corpus público
CORAA-MuPe, guardando quem fala em cada trecho (gabarito). Depois compara o
gabarito com o projeto gerado por `python -m degravaia importar`.

    python interlocutores.py montar --saida longo/conversa2.wav --vozes MA_HV260 MA_HV253
    python -m degravaia importar longo/conversa2.wav --falantes 2
    python interlocutores.py avaliar longo/conversa2.json projetos/<pasta>

Os arquivos parquet do corpus ficam em dados/data/ (baixados do Hugging Face,
nilc-nlp/CORAA-MUPE-ASR). Cada fala é normalizada para o mesmo volume, para que
o modelo não separe as pessoas só pela altura da gravação.
"""
import argparse
import io
import itertools
import json
import random
from pathlib import Path

import numpy as np
import pyarrow.parquet as pq
import soundfile as sf

TAXA = 16000


def _carregar_falas(pasta, vozes):
    falas = {v: [] for v in vozes}
    for arq in sorted(Path(pasta).glob("*.parquet")):
        tabela = pq.read_table(arq, columns=["speaker_code", "speaker_type", "audio_quality",
                                             "start_time", "duration", "original_text", "audio"])
        for linha in tabela.to_pylist():
            v = linha["speaker_code"]
            if v in falas and linha["speaker_type"] == "R" and linha["audio_quality"] == "high" \
                    and 1.5 <= linha["duration"] <= 9:
                falas[v].append(linha)
    for v, lista in falas.items():
        if not lista:
            raise SystemExit(f"Voz {v} não encontrada nos parquet de {pasta}")
        lista.sort(key=lambda x: x["start_time"])
    return falas


def _decodificar(linha):
    audio, taxa = sf.read(io.BytesIO(linha["audio"]["bytes"]), dtype="float32")
    if audio.ndim > 1:
        audio = audio.mean(axis=1)
    if taxa != TAXA:
        x = np.arange(0, len(audio), taxa / TAXA)
        audio = np.interp(x, np.arange(len(audio)), audio).astype("float32")
    rms = float(np.sqrt(np.mean(audio ** 2))) or 1.0
    return audio * (0.05 / rms)


def montar(args):
    rnd = random.Random(args.semente)
    falas = _carregar_falas(args.dados, args.vozes)
    # trechos seguidos da mesma entrevista, para soar como uma conversa contínua
    fila = {v: iter(lista[len(lista) // 3:]) for v, lista in falas.items()}

    ordem = []
    anterior = None
    for _ in range(args.turnos):
        v = rnd.choice([x for x in args.vozes if x != anterior])
        ordem.append(v)
        anterior = v

    partes, gabarito, t = [], [], 0.0
    for v in ordem:
        for _ in range(rnd.choice([1, 1, 2, 3])):
            linha = next(fila[v])
            audio = _decodificar(linha)
            partes.append(audio)
            gabarito.append({"inicio": round(t, 3), "fim": round(t + len(audio) / TAXA, 3),
                             "voz": v, "texto": linha["original_text"]})
            t += len(audio) / TAXA
            pausa = np.zeros(int(TAXA * rnd.uniform(0.2, 0.4)), dtype="float32")
            partes.append(pausa)
            t += len(pausa) / TAXA
        pausa = np.zeros(int(TAXA * rnd.uniform(0.3, 0.9)), dtype="float32")
        partes.append(pausa)
        t += len(pausa) / TAXA

    saida = Path(args.saida)
    saida.parent.mkdir(parents=True, exist_ok=True)
    sf.write(saida, np.concatenate(partes), TAXA, subtype="PCM_16")
    saida.with_suffix(".json").write_text(json.dumps(
        {"vozes": args.vozes, "trechos": gabarito}, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"{saida}: {t:.1f} s, {len(gabarito)} trechos, {len(ordem)} turnos")


def _voz_no_tempo(trechos, t):
    for tr in trechos:
        if tr["inicio"] <= t <= tr["fim"]:
            return tr["voz"]
    return None


def avaliar(args):
    gab = json.loads(Path(args.gabarito).read_text(encoding="utf-8"))
    proj = json.loads((Path(args.projeto) / "projeto.json").read_text(encoding="utf-8"))
    trechos, palavras, nomes = gab["trechos"], proj["palavras"], proj["interlocutores"]

    pares = []
    for p in palavras:
        voz = _voz_no_tempo(trechos, (p["inicio"] + p["fim"]) / 2)
        if voz is not None:
            pares.append((voz, p.get("falante")))
    detectados = sorted({f for _, f in pares if f is not None})

    # melhor correspondência voz real → rótulo detectado (o rótulo em si é arbitrário)
    melhor, acertos = {}, -1
    vozes = gab["vozes"]
    for perm in itertools.permutations(detectados + [None] * max(0, len(vozes) - len(detectados)), len(vozes)):
        mapa = dict(zip(vozes, perm))
        n = sum(1 for v, f in pares if mapa[v] == f)
        if n > acertos:
            melhor, acertos = mapa, n

    if not pares:
        raise SystemExit("O projeto não tem palavras transcritas.")
    print(f"Vozes reais: {len(vozes)} | interlocutores detectados: {len(detectados)}")
    for v in vozes:
        print(f"  {v} → {nomes.get(melhor[v], '(nenhum)')}")
    print(f"Palavras atribuídas à pessoa certa: {acertos}/{len(pares)} ({100 * acertos / len(pares):.1f}%)")

    inverso = {f: v for v, f in melhor.items()}
    erros = [(p, v) for p in palavras
             if (v := _voz_no_tempo(trechos, (p["inicio"] + p["fim"]) / 2)) is not None
             and inverso.get(p.get("falante")) != v]
    if erros:
        print("Palavras na pessoa errada (tempo, palavra, real → atribuída):")
        for p, v in erros[:60]:
            print(f"  {p['inicio']:7.2f}  {p['texto']:<15} {v} → {nomes.get(p.get('falante'), '?')}")

    # trocas de turno do gabarito que viraram fala nova no projeto
    trocas = [b["inicio"] for a, b in zip(trechos, trechos[1:]) if a["voz"] != b["voz"]]
    inicios = [f["inicio"] for f in proj["falas"]]
    achadas = sum(1 for t in trocas if any(abs(t - i) <= 1.0 for i in inicios))
    print(f"Trocas de interlocutor: {len(trocas)} no gabarito, {achadas} viraram fala nova (±1 s); "
          f"{len(proj['falas'])} falas no projeto")


def main():
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)
    m = sub.add_parser("montar")
    m.add_argument("--dados", default="dados/data")
    m.add_argument("--saida", required=True)
    m.add_argument("--vozes", nargs="+", required=True)
    m.add_argument("--turnos", type=int, default=16)
    m.add_argument("--semente", type=int, default=7)
    a = sub.add_parser("avaliar")
    a.add_argument("gabarito")
    a.add_argument("projeto")
    args = ap.parse_args()
    montar(args) if args.cmd == "montar" else avaliar(args)


if __name__ == "__main__":
    main()
