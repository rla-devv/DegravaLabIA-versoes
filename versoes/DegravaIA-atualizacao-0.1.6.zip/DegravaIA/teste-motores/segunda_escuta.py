"""Rodada 2: wav2vec2-CORAA sozinho e como "segunda escuta" do Whisper.

A segunda escuta compara o texto do Whisper com o do wav2vec2 e transforma em
SUGESTÕES as hesitações e repetições que só o wav2vec2 ouviu. As sugestões não
entram no texto: aqui medimos quantas estariam certas se o usuário aceitasse.

Uso:
    python segunda_escuta.py --amostras amostras --whisper resultados.json
"""
import argparse
import difflib
import json
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

import jiwer
import soundfile as sf
import torch
from transformers import Wav2Vec2ForCTC, Wav2Vec2Processor

from comparar import HESITACOES, MULETAS, contar, normalizar, repeticoes

MODELO = "Edresson/wav2vec2-large-xlsr-coraa-portuguese"
WHISPER_BASE = "whisper-large-v3+prompt"


def transcrever(modelo, proc, caminho):
    audio, sr = sf.read(caminho, dtype="float32")
    if audio.ndim > 1:
        audio = audio.mean(axis=1)
    entrada = proc(audio, sampling_rate=sr, return_tensors="pt")
    with torch.inference_mode():
        logits = modelo(entrada.input_values).logits
    return normalizar(proc.batch_decode(logits.argmax(-1))[0])


def sugestoes(whisper, w2v):
    """Palavras que só o wav2vec2 ouviu e que são hesitação, 'né' ou repetição."""
    a, b = whisper.split(), w2v.split()
    saida, sugeridas = [], []
    for op, i1, i2, j1, j2 in difflib.SequenceMatcher(a=a, b=b, autojunk=False).get_opcodes():
        saida.extend(a[i1:i2])
        if op in ("insert", "replace"):
            for k in range(j1, j2):
                p = b[k]
                anterior = saida[-1] if saida else None
                if p in HESITACOES or p in MULETAS or p == anterior:
                    saida.append(p)
                    sugeridas.append(p)
    return " ".join(saida), sugeridas


def acertos(sugeridas_txt, ref):
    """Quantas palavras sugeridas casam com a referência no alinhamento."""
    h, r = sugeridas_txt.split(), ref.split()
    casadas = set()
    for op, i1, i2, j1, j2 in difflib.SequenceMatcher(a=h, b=r, autojunk=False).get_opcodes():
        if op == "equal":
            casadas.update(range(i1, i2))
    return casadas


def metricas(refs, hip):
    r_txt, h_txt = [refs[k] for k in hip], [hip[k] for k in hip]
    rp, hp = " ".join(r_txt).split(), " ".join(h_txt).split()
    return {
        "wer_literal": round(jiwer.wer(r_txt, h_txt), 3),
        "hesitacoes": f"{contar(hp, HESITACOES)} / {contar(rp, HESITACOES)}",
        "ne": f"{contar(hp, MULETAS)} / {contar(rp, MULETAS)}",
        "repeticoes": f"{repeticoes(hp)} / {repeticoes(rp)}",
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--amostras", default="amostras")
    ap.add_argument("--whisper", default="resultados.json")
    ap.add_argument("--saida", default="resultados_rodada2.json")
    args = ap.parse_args()

    dados = json.loads(Path(args.whisper).read_text(encoding="utf-8"))
    refs, whisper = dados["referencias"], dados["motores"][WHISPER_BASE]["transcricoes"]

    proc = Wav2Vec2Processor.from_pretrained(MODELO)
    modelo = Wav2Vec2ForCTC.from_pretrained(MODELO).eval()

    w2v, combinado, detalhe = {}, {}, {}
    total_sug = total_certas = 0
    inicio, duracao = time.time(), 0.0
    for a in sorted(Path(args.amostras).glob("*.wav")):
        duracao += sf.info(a).duration
        w2v[a.stem] = transcrever(modelo, proc, a)
        texto, sug = sugestoes(whisper[a.stem], w2v[a.stem])
        combinado[a.stem] = texto
        # posições, no texto combinado, das palavras que vieram como sugestão
        base = whisper[a.stem].split()
        pos_sug, bi = [], 0
        for i, p in enumerate(texto.split()):
            if bi < len(base) and p == base[bi]:
                bi += 1
            else:
                pos_sug.append(i)
        certas = len(set(pos_sug) & acertos(texto, refs[a.stem]))
        total_sug += len(pos_sug)
        total_certas += certas
        detalhe[a.stem] = {"wav2vec2": w2v[a.stem], "whisper": whisper[a.stem],
                           "com_sugestoes": texto, "sugeridas": sug, "certas": certas}
    tempo = time.time() - inicio

    res = {
        "wav2vec2 sozinho": metricas(refs, w2v) | {"fator_tempo_real": round(tempo / duracao, 2)},
        WHISPER_BASE: metricas(refs, whisper),
        "whisper + sugestões aceitas": metricas(refs, combinado),
        "sugestoes": {"total": total_sug, "certas": total_certas,
                      "precisao": round(total_certas / total_sug, 2) if total_sug else None},
    }
    for k, v in res.items():
        print(k, v, flush=True)
    Path(args.saida).write_text(json.dumps({"resumo": res, "trechos": detalhe},
                                           ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
