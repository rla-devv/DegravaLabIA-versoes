"""Degrava Lab IA. Este arquivo roda antes de qualquer outro módulo do app e, portanto, antes de
qualquer biblioteca: nada sai deste computador sem a pessoa pedir."""
import os as _os
import sys as _sys

# Telemetria das bibliotecas, desligada antes de qualquer import. Forçado (não setdefault): nem uma
# variável de ambiente de fora religa. O pyannote 4 manda métricas de uso para otel.pyannote.ai por padrão.
SEM_TELEMETRIA = {
    "PYANNOTE_METRICS_ENABLED": "0",  # pyannote.audio.telemetry
    "HF_HUB_DISABLE_TELEMETRY": "1",  # huggingface_hub (e o transformers, que usa o mesmo)
    "DO_NOT_TRACK": "1",  # o padrão geral, que o huggingface_hub também respeita
    "OTEL_SDK_DISABLED": "true",  # OpenTelemetry, por onde o pyannote envia
}
_os.environ.update(SEM_TELEMETRIA)

# O onnxruntime (que o pyannote carrega se estiver instalado) manda telemetria da Microsoft
# (mobile.events.data.microsoft.com) mesmo com disable_telemetry_events(). O app não o usa: o Whisper
# roda sem o filtro de voz (vad_filter=False) e o pyannote, sem ele, usa o PyTorch. Então nunca é carregado.
_sys.modules.setdefault("onnxruntime", None)

# Com os modelos instalados, as bibliotecas não falam com o Hugging Face (nem para conferir se há
# revisão nova). Só o "baixar-modelos" (instalação e reparo) precisa dele.
BAIXA_MODELOS = "baixar-modelos" in _sys.argv[1:]
_os.environ["HF_HUB_OFFLINE"] = _os.environ["TRANSFORMERS_OFFLINE"] = "0" if BAIXA_MODELOS else "1"
