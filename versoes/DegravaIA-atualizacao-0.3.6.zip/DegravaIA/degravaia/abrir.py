"""Degrava IA — o "Degrava IA.bat" da pasta roda isto (python -m degravaia.abrir).

    Degrava IA.bat               instala na primeira vez; depois, abre o app
    Degrava IA.bat instalar      roda a instalação de novo
    Degrava IA.bat diagnostico   mostra o que o app encontrou (GPU, modelos…)
    Degrava IA.bat --navegador   abre no navegador, com a janela preta

No Windows, com o pywebview instalado, abre em janela própria (degravaia\\janela.pyw) e
cria o atalho na Área de Trabalho se ainda não houver. Com --navegador, ou sem o
pywebview, abre como abaixo, no navegador:

Funciona sem internet: liga o modo offline das bibliotecas (item 1 dos requisitos)
e põe no PATH as bibliotecas da NVIDIA para o Whisper usar a GPU. Mantenha esta
janela aberta enquanto usa; para encerrar, feche-a.

Tudo o que aparece aqui vai também para registro.txt (fica mesmo se a janela fechar).
Se o programa da tela cair, ele é aberto de novo sozinho.
"""
import os
import subprocess
import sys
import time
from datetime import datetime
from pathlib import Path

from degravaia.instalar import AQUI, JANELA, ambiente_nvidia, instalar, python_do_app

REGISTRO = AQUI / "registro.txt"
PARA_ABRIR = ("Das próximas vezes, abra pelo atalho \"Abrir o Degrava IA\" nesta pasta ou pelo atalho\n"
              "\"Degrava IA\" na Área de Trabalho e no Menu Iniciar.")
REINICIAR = 3  # o servidor pede para reabrir (atualização instalada; atualizacao.py)
# grupo de processos próprio: um sinal de "encerrar" vindo de outro processo da janela
# (ex.: a importação fechando depois de usar a GPU) não derruba o servidor
GRUPO_PROPRIO = subprocess.CREATE_NEW_PROCESS_GROUP if os.name == "nt" else 0


def abrir_registro():
    if REGISTRO.exists() and REGISTRO.stat().st_size > 2_000_000:  # guarda só o mais recente
        REGISTRO.replace(REGISTRO.with_suffix(".anterior.txt"))
    return open(REGISTRO, "a", encoding="utf-8", errors="replace")


def anotar(registro, texto):
    print(texto, flush=True)
    registro.write(f"{datetime.now():%Y-%m-%d %H:%M:%S} {texto}\n")
    registro.flush()


def rodar_servidor(app, comando, registro):
    """Roda o servidor mostrando a saída aqui e gravando no registro; devolve o código de saída."""
    proc = subprocess.Popen([str(app), "-u", "-m", "degravaia", *comando], env=ambiente_nvidia(),
                            stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, encoding="utf-8",
                            errors="replace", creationflags=GRUPO_PROPRIO)
    try:
        for linha in proc.stdout:
            print(linha, end="", flush=True)
            registro.write(f"{datetime.now():%Y-%m-%d %H:%M:%S} {linha}")
            registro.flush()
        return proc.wait()
    except KeyboardInterrupt:  # Ctrl+C nesta janela: encerra o servidor também
        proc.terminate()
        raise


def abrir_em_janela(app):
    """Abre a janela própria (degravaia\\janela.pyw, sem janela preta). False se não der."""
    if os.name != "nt":
        return False
    tem_janela = subprocess.run([str(app), "-c", "import webview"], capture_output=True).returncode == 0
    pythonw = app.with_name("pythonw.exe")
    if not tem_janela or not pythonw.exists():
        return False
    # os atalhos: o servidor, ao abrir, cria o da pasta se faltar (instalar.arrumar_pasta)
    subprocess.Popen([str(pythonw), str(JANELA)], cwd=AQUI,
                     creationflags=subprocess.DETACHED_PROCESS | subprocess.CREATE_NEW_PROCESS_GROUP)
    return True


def instalado(app):
    return app.exists() and subprocess.run([str(app), "-c", "import faster_whisper"],
                                           capture_output=True).returncode == 0


def esconder_lista():
    """A lista de arquivos do app fica na raiz (as atualizações antigas a procuram ali), mas
    escondida: na pasta, a pessoa vê só o "Degrava IA.bat" e o LEIA-ME."""
    lista = AQUI / "arquivos-do-app.txt"
    if os.name == "nt" and lista.exists():
        try:
            import ctypes

            ctypes.windll.kernel32.SetFileAttributesW(str(lista), 0x2)  # FILE_ATTRIBUTE_HIDDEN
        except Exception:
            pass


def principal():
    os.chdir(AQUI)
    esconder_lista()
    navegador = "--navegador" in sys.argv
    comando = [a for a in sys.argv[1:] if a != "--navegador"] or ["revisar"]
    app = python_do_app()
    if comando == ["instalar"] or not instalado(app):  # primeira vez: instala e já abre
        if comando != ["instalar"]:
            print("Primeira vez: o Degrava IA vai ser instalado (precisa de internet só agora).\n")
        codigo = instalar()
        app = python_do_app()
        if codigo or comando == ["instalar"] or not instalado(app):
            if not codigo and instalado(app):
                print(f"\n{PARA_ABRIR}")
            input("\nTecle Enter para fechar esta janela.")
            return codigo or (0 if comando == ["instalar"] else 1)
        print(f"\nPronto! O Degrava IA está abrindo. {PARA_ABRIR}")
        comando = ["revisar"]
        if not navegador and abrir_em_janela(app):
            time.sleep(6)  # tempo de ler a mensagem; depois esta tela preta fecha sozinha
            return 0
    if comando == ["revisar"] and not navegador and abrir_em_janela(app):
        return 0
    if comando != ["revisar"]:  # outros comandos (diagnóstico etc.): roda uma vez e mostra
        codigo = subprocess.run([str(app), "-m", "degravaia", *comando], env=ambiente_nvidia()).returncode
        input("\nTecle Enter para fechar.")
        return codigo
    quedas = []
    with abrir_registro() as registro:
        anotar(registro, "=== Degrava IA aberto")
        try:
            codigo = rodar_servidor(app, comando, registro)
            while True:
                if codigo == REINICIAR:
                    anotar(registro, "Abrindo a versão nova…")
                elif codigo != 0:
                    quedas = [t for t in quedas if time.time() - t < 600] + [time.time()]
                    anotar(registro, f"O programa da tela parou (código {codigo}).")
                    if len(quedas) > 5:  # caindo em sequência: para e mostra
                        anotar(registro, "Parou várias vezes seguidas. Envie o arquivo registro.txt para o suporte.")
                        input("\nTecle Enter para fechar.")
                        return codigo
                    anotar(registro, "Abrindo de novo em 2 segundos… (a tela no navegador volta sozinha)")
                    time.sleep(2)
                else:
                    return 0
                codigo = rodar_servidor(app, ["revisar", "--nao-abrir"], registro)
        except KeyboardInterrupt:
            anotar(registro, "Encerrado nesta janela.")
            return 0


if __name__ == "__main__":
    sys.exit(principal())
