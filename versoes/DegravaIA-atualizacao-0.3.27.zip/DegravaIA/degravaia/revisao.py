"""Alterações da revisão humana, com histórico e desfazer (itens 5, 13 e 14).

Cada alteração é aplicada ao projeto, salva na hora e registrada no
`historico.jsonl` com o antes e o depois. O texto da IA nunca se perde: a
primeira edição de uma palavra guarda o original em `texto_ia` (e a primeira
troca de interlocutor, em `falante_ia`). Desfazer não apaga nada do histórico:
acrescenta uma linha "desfazer" que aponta para a alteração revertida.
"""
import copy
import json

from . import marcacoes, montagem
from .config import ROTULO_INTERLOCUTOR

TIPOS = ("editar_palavra", "atribuir_falante", "renomear_interlocutor", "juntar_interlocutores",
         "decidir_marcacao", "tipo_marcacao", "criar_marcacao", "remover_marcacao",
         "decidir_insercao", "inserir_texto", "aceitar_reanalise")
# alterações em marcações/inserções guardam o objeto inteiro antes e depois (item 14)
LISTAS = {"decidir_marcacao": "marcacoes", "tipo_marcacao": "marcacoes", "criar_marcacao": "marcacoes",
          "remover_marcacao": "marcacoes", "decidir_insercao": "insercoes", "inserir_texto": "insercoes",
          "aceitar_reanalise": "marcacoes"}


class AlteracaoInvalida(ValueError):
    pass


def historico(proj):
    caminho = proj.pasta / "historico.jsonl"
    if not caminho.exists():
        return []
    return [json.loads(linha) for linha in caminho.read_text(encoding="utf-8").splitlines() if linha.strip()]


def _desfeitas(linhas):
    return {l["detalhes"]["desfaz"] for l in linhas if l["acao"] == "desfazer"}


def _proximo_id(linhas):
    return 1 + max((l.get("id", 0) for l in linhas), default=0)


def _palavra(proj, i):
    palavras = proj.dados["palavras"]
    if not isinstance(i, int) or not 0 <= i < len(palavras):
        raise AlteracaoInvalida(f"Palavra inexistente: {i}")
    return palavras[i]


def _remontar(proj):
    proj.dados["falas"] = montagem.montar_falas(proj.dados["palavras"])


def _aplicar(proj, tipo, d):
    """Aplica `d` ({…, "depois"}) e devolve os detalhes completos, com o "antes"."""
    if tipo == "editar_palavra":
        p = _palavra(proj, d["palavra"])
        texto = str(d["depois"]).strip()
        antes = p["texto"]
        if texto == antes:
            raise AlteracaoInvalida("Texto igual ao atual.")
        p.setdefault("texto_ia", antes)
        p["texto"] = texto
        p["revisado"] = p["texto"] != p["texto_ia"]
        return {"palavra": d["palavra"], "antes": antes, "depois": texto, "texto_ia": p["texto_ia"]}

    if tipo == "atribuir_falante":
        ids = d["palavras"]
        if not ids or not isinstance(ids, list):
            raise AlteracaoInvalida("Nenhuma palavra selecionada.")
        destino, criado = d["depois"], False
        nomes = proj.dados["interlocutores"]
        if destino not in nomes:
            if destino != "novo":
                raise AlteracaoInvalida(f"Interlocutor inexistente: {destino}")
            n = len(nomes) + 1
            while f"NOVO_{n}" in nomes:
                n += 1
            destino = f"NOVO_{n}"
            nomes[destino] = ROTULO_INTERLOCUTOR.format(n=len(nomes) + 1)
            criado = True
        antes = {}
        for i in ids:
            p = _palavra(proj, i)
            antes[str(i)] = p.get("falante")
            p.setdefault("falante_ia", p.get("falante"))
            p["falante"] = destino
        _remontar(proj)
        return {"palavras": ids, "antes": antes, "depois": destino, "criado": criado}

    if tipo == "juntar_interlocutores":
        # a IA separou uma pessoa em duas (ex.: entonação muito diferente): tudo de `de` vai para `para`
        nomes, de, para = proj.dados["interlocutores"], d.get("de"), d.get("para")
        if de not in nomes or para not in nomes or de == para:
            raise AlteracaoInvalida("Escolha dois interlocutores diferentes.")
        antes = {}
        for i, p in enumerate(proj.dados["palavras"]):
            if p.get("falante") == de:
                antes[str(i)] = de
                p.setdefault("falante_ia", de)
                p["falante"] = para
        nome = nomes.pop(de)
        removidas, sobrepostas = [], []
        if d.get("remover_sobreposicoes"):  # com uma voz só, "vozes sobrepostas" deixa de fazer sentido
            marcas = proj.dados.setdefault("marcacoes", [])
            removidas = [m for m in marcas if m["tipo"] == "sobreposicao" and m["origem"] == "ia"]
            marcas[:] = [m for m in marcas if m not in removidas]
            for i, p in enumerate(proj.dados["palavras"]):
                if p.get("sobreposicao"):
                    sobrepostas.append(i)
                    p["sobreposicao"] = False
        _remontar(proj)
        return {"de": de, "para": para, "nome": nome, "antes": antes, "marcacoes_removidas": removidas,
                "palavras_sobrepostas": sobrepostas}

    if tipo == "renomear_interlocutor":
        nomes = proj.dados["interlocutores"]
        f, nome = d["falante"], str(d["depois"]).strip()
        if f not in nomes:
            raise AlteracaoInvalida(f"Interlocutor inexistente: {f}")
        if not nome or nome == nomes[f]:
            raise AlteracaoInvalida("Nome vazio ou igual ao atual.")
        antes, nomes[f] = nomes[f], nome
        return {"falante": f, "antes": antes, "depois": nome}

    if tipo in LISTAS:
        return _alterar_lista(proj, tipo, LISTAS[tipo], d)

    raise AlteracaoInvalida(f"Tipo de alteração desconhecido: {tipo}")


def _decisao(d):
    modo = d.get("modo")
    if modo not in marcacoes.MODOS:
        raise AlteracaoInvalida(f"Modo de inserção desconhecido: {modo}")
    texto = str(d.get("texto") or "").strip()
    if modo == "sem_palavra":
        return {"modo": modo, "texto": ""}
    if modo != "marcacao" and not texto:
        raise AlteracaoInvalida("Texto vazio.")
    return {"modo": modo, "texto": texto}


def _objeto(lista, oid):
    for obj in lista:
        if obj["id"] == oid:
            return obj
    raise AlteracaoInvalida(f"Item inexistente: {oid}")


def _alterar_lista(proj, tipo, nome, d):
    lista = proj.dados.setdefault(nome, [])
    novo_id = 1 + max((o["id"] for o in lista), default=0)
    if tipo in ("criar_marcacao", "inserir_texto", "aceitar_reanalise"):
        antes = None
        if tipo == "aceitar_reanalise":
            ids = sorted(set(d.get("palavras") or []))
            if not ids:
                raise AlteracaoInvalida("Nenhuma palavra selecionada.")
            for i in ids:
                _palavra(proj, i)
            ocupadas = {i for m in lista if marcacoes.TIPOS[m["tipo"]]["substitui"] for i in m["palavras"]}
            if ocupadas & set(ids):
                raise AlteracaoInvalida("Parte do trecho já tem uma marcação: decida pela própria marcação.")
            decisao = _decisao(d)
            if decisao["modo"] in ("marcacao", "sem_palavra"):
                raise AlteracaoInvalida("Escolha como inserir o texto.")
            ps = proj.dados["palavras"]
            sug = [{"origem": str(x.get("origem", ""))[:120], "texto": str(x.get("texto", ""))[:2000]}
                   for x in (d.get("sugestoes") or [])[:5]]
            depois = {"id": novo_id, "tipo": "reanalise", "inicio": ps[ids[0]]["inicio"], "fim": ps[ids[-1]]["fim"],
                      "palavras": ids, "antes_de": None, "origem": "usuario",
                      "sugestoes": [{"origem": "texto anterior", "texto": " ".join(ps[i]["texto"] for i in ids)}] + sug,
                      "decisao": decisao}
        elif tipo == "criar_marcacao":
            # "tipo" já é o nome da alteração; o tipo da marcação vem em "marcacao"
            if d.get("marcacao") not in marcacoes.TIPOS:
                raise AlteracaoInvalida(f"Marcação desconhecida: {d.get('marcacao')}")
            ids = sorted(set(d.get("palavras") or []))
            for i in ids:
                _palavra(proj, i)
            if ids:
                ps = proj.dados["palavras"]
                ini, fim, antes_de = ps[ids[0]]["inicio"], ps[ids[-1]]["fim"], None
                sug = [{"origem": "texto anterior", "texto": " ".join(ps[i]["texto"] for i in ids)}]
            else:
                antes_de = d.get("antes_de")
                ini = fim = _palavra(proj, antes_de)["inicio"]
                sug = []
            depois = {"id": novo_id, "tipo": d["marcacao"], "inicio": ini, "fim": fim, "palavras": ids,
                      "antes_de": antes_de, "origem": "usuario", "sugestoes": sug,
                      "decisao": {"modo": "marcacao", "texto": ""}}
        else:
            decisao = _decisao(d | {"modo": d.get("modo", "normal")})
            if decisao["modo"] in ("marcacao", "sem_palavra"):
                raise AlteracaoInvalida("Escolha como inserir o texto.")
            p = _palavra(proj, d.get("antes_de"))
            depois = {"id": novo_id, "antes_de": d["antes_de"], "inicio": p["inicio"], "texto": decisao["texto"],
                      "origem": "usuario", "decisao": decisao}
        lista.append(depois)
    else:
        chave = "marcacao" if nome == "marcacoes" else "insercao"
        obj = _objeto(lista, d.get(chave))
        antes = copy.deepcopy(obj)
        if tipo in ("decidir_marcacao", "decidir_insercao"):
            obj["decisao"] = _decisao(d)
            # "não há palavra aqui" só vale para marcação que esconde palavras (ininteligível etc.)
            if obj["decisao"]["modo"] == "sem_palavra" and (
                    tipo != "decidir_marcacao" or not marcacoes.TIPOS[obj["tipo"]]["substitui"]):
                raise AlteracaoInvalida("Esta opção só vale para marcações como [ininteligível].")
        elif tipo == "tipo_marcacao":
            if d.get("depois") not in marcacoes.TIPOS or d["depois"] == obj["tipo"]:
                raise AlteracaoInvalida("Tipo de marcação inválido.")
            obj["tipo"] = d["depois"]
        elif tipo == "remover_marcacao":
            lista.remove(obj)
        depois = None if tipo == "remover_marcacao" else copy.deepcopy(obj)
        if antes == depois:
            raise AlteracaoInvalida("Nada mudou.")
    return {"lista": nome, "id": (depois or antes)["id"], "antes": antes, "depois": depois}


def alterar(proj, tipo, detalhes):
    linhas = historico(proj)
    completo = _aplicar(proj, tipo, detalhes)
    proj.salvar()
    proj.registrar(tipo, completo, origem="usuario", id=_proximo_id(linhas))
    return completo


def _reverter(proj, tipo, d):
    if tipo == "editar_palavra":
        p = _palavra(proj, d["palavra"])
        p["texto"] = d["antes"]
        p["revisado"] = p["texto"] != p.get("texto_ia", p["texto"])
    elif tipo == "atribuir_falante":
        for i, f in d["antes"].items():
            _palavra(proj, int(i))["falante"] = f
        if d.get("criado") and not any(p.get("falante") == d["depois"] for p in proj.dados["palavras"]):
            proj.dados["interlocutores"].pop(d["depois"], None)
        _remontar(proj)
    elif tipo == "renomear_interlocutor":
        proj.dados["interlocutores"][d["falante"]] = d["antes"]
    elif tipo == "juntar_interlocutores":
        for i, f in d["antes"].items():
            _palavra(proj, int(i))["falante"] = f
        nomes = proj.dados["interlocutores"]
        nomes[d["de"]] = d["nome"]
        # devolve a ordem original (Interlocutor 1, 2, …): pela primeira fala de cada um
        primeira = {}
        for p in proj.dados["palavras"]:
            primeira.setdefault(p.get("falante"), p["inicio"])
        proj.dados["interlocutores"] = dict(sorted(nomes.items(), key=lambda kv: primeira.get(kv[0], 1e12)))
        marcas = proj.dados.setdefault("marcacoes", [])
        marcas.extend(copy.deepcopy(d.get("marcacoes_removidas", [])))
        marcas.sort(key=lambda o: (o.get("inicio", 0), o["id"]))
        for i in d.get("palavras_sobrepostas", []):
            _palavra(proj, i)["sobreposicao"] = True
        _remontar(proj)
    elif tipo in LISTAS:
        lista = proj.dados.setdefault(d["lista"], [])
        lista[:] = [o for o in lista if o["id"] != d["id"]]
        if d["antes"] is not None:
            lista.append(copy.deepcopy(d["antes"]))
            lista.sort(key=lambda o: (o.get("inicio", 0), o["id"]))


def desfazer(proj):
    """Reverte a última alteração do usuário que ainda não foi desfeita."""
    linhas = historico(proj)
    feitas = _desfeitas(linhas)
    for l in reversed(linhas):
        if l.get("origem") == "usuario" and l["acao"] in TIPOS and l["id"] not in feitas:
            _reverter(proj, l["acao"], l["detalhes"])
            proj.salvar()
            proj.registrar("desfazer", {"desfaz": l["id"], "acao": l["acao"]},
                           origem="usuario", id=_proximo_id(linhas))
            return l
    raise AlteracaoInvalida("Não há alteração para desfazer.")


def alteracoes_do_usuario(proj):
    """Histórico da revisão para a tela, com a marca do que foi desfeito."""
    linhas = historico(proj)
    feitas = _desfeitas(linhas)
    return [l | {"desfeita": l.get("id") in feitas} for l in linhas if l.get("origem") == "usuario"]
