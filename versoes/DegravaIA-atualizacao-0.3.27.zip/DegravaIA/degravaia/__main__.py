"""Linha de comando.

    python -m degravaia importar ARQUIVO [--falantes N] [--idioma pt|auto|en|es…]
    python -m degravaia revisar [--porta 8765]
    python -m degravaia diagnostico | baixar-modelos | restaurar-versao
    python -m degravaia mostrar PASTA_DO_PROJETO
    python -m degravaia verificar PASTA_DO_PROJETO
"""
import argparse
import sys

from . import montagem
from .projeto import Projeto


def main(argv=None):
    ap = argparse.ArgumentParser(prog="degravaia", description="Degrava Lab IA — Transcrição de áudios")
    sub = ap.add_subparsers(dest="cmd", required=True)

    imp = sub.add_parser("importar", help="importa um áudio/vídeo e transcreve")
    imp.add_argument("arquivo")
    imp.add_argument("--idioma", default="pt", help="pt (padrão), auto ou código do idioma")
    imp.add_argument("--falantes", type=int, help="número de interlocutores, se souber")
    imp.add_argument("--sem-interlocutores", action="store_true", help="não separa as vozes")
    imp.add_argument("--projetos", default="projetos", help="pasta onde ficam os projetos")
    imp.add_argument("--melhoria", choices=("leve", "medio", "forte"),
                     help="melhoria de áudio em cópia (desligada por padrão)")
    imp.add_argument("--vocabulario", help="nomes e termos do áudio, separados por vírgula")
    imp.add_argument("--procedencia", help=argparse.SUPPRESS)  # usado pela tela de revisão
    imp.add_argument("--sem-texto", action="store_true", help=argparse.SUPPRESS)

    # usado pela tela de revisão (item 11): roda num processo à parte e responde em JSON
    rea = sub.add_parser("reanalisar", help=argparse.SUPPRESS)
    rea.add_argument("projeto")
    rea.add_argument("--palavras", type=int, nargs="+", required=True)
    rea.add_argument("--nivel")

    rev = sub.add_parser("revisar", help="abre a tela de revisão no navegador")
    rev.add_argument("--projetos", default="projetos", help="pasta onde ficam os projetos")
    rev.add_argument("--porta", type=int, default=8765)
    rev.add_argument("--nao-abrir", action="store_true", help="não abre o navegador sozinho")

    sub.add_parser("diagnostico", help="mostra o que o app encontrou: GPU, ffmpeg, modelos, fonte do PDF")
    sub.add_parser("baixar-modelos", help="baixa os modelos uma vez (depois funciona sem internet)")
    sub.add_parser("restaurar-versao", help="volta para a versão anterior do app, guardada na atualização")

    for nome, ajuda in (("mostrar", "mostra a transcrição de um projeto"),
                        ("verificar", "confere o hash do original guardado")):
        p = sub.add_parser(nome, help=ajuda)
        p.add_argument("projeto")

    args = ap.parse_args(argv)
    if sys.stdout.encoding and sys.stdout.encoding.lower() != "utf-8":
        sys.stdout.reconfigure(encoding="utf-8")

    if args.cmd == "importar":
        from .pipeline import processar

        import json

        # usado pela tela: avisos de andamento numa linha própria, que ela não mostra no registro
        from .motores import ModeloIncompleto

        andamento = (lambda a: print("@andamento " + json.dumps(a), flush=True)) if args.sem_texto else None
        try:
            proj = processar(args.arquivo, raiz=args.projetos, idioma=args.idioma,
                             num_falantes=args.falantes, com_interlocutores=not args.sem_interlocutores,
                             procedencia=args.procedencia, melhoria=args.melhoria,
                             vocabulario=[args.vocabulario] if args.vocabulario else None,
                             log=lambda m: print(m, flush=True), andamento=andamento)
        except ModeloIncompleto as erro:  # a tela mostra a mensagem no lugar de "veja os detalhes"
            print(("@erro " if args.sem_texto else "") + str(erro), flush=True)
            return 1
        if not args.sem_texto:
            print()
            print(montagem.texto_corpo(proj.dados))
        _sair_ja()
    elif args.cmd == "reanalisar":
        import json

        from .trechos import reanalisar

        print(json.dumps(reanalisar(Projeto(args.projeto), sorted(set(args.palavras)), args.nivel),
                         ensure_ascii=False))
        _sair_ja()
    elif args.cmd == "revisar":
        from .servidor import servir

        return servir(raiz=args.projetos, porta=args.porta, abrir=not args.nao_abrir)
    elif args.cmd == "diagnostico":
        from .diagnostico import diagnostico

        return diagnostico()
    elif args.cmd == "baixar-modelos":
        from .diagnostico import baixar_modelos

        return baixar_modelos()
    elif args.cmd == "restaurar-versao":
        from .atualizacao import restaurar

        return restaurar()
    elif args.cmd == "mostrar":
        print(montagem.texto_corpo(Projeto(args.projeto).dados))
    elif args.cmd == "verificar":
        proj = Projeto(args.projeto)
        ok, atual = proj.verificar_integridade()
        print(f"Registrado: {proj.dados['original']['sha256']}")
        print(f"Atual:      {atual}")
        print("ÍNTEGRO: o arquivo não foi alterado." if ok else "ATENÇÃO: o arquivo foi ALTERADO!")
        return 0 if ok else 1


def _sair_ja():
    """Encerra sem a faxina do Python. No Windows, depois de usar a GPU, as bibliotecas do
    Whisper (ctranslate2) e do torch às vezes travam ao fechar, e o processo ficava parado
    depois de "Projeto salvo". Tudo já está gravado em disco neste ponto."""
    import os

    sys.stdout.flush()
    sys.stderr.flush()
    os._exit(0)


if __name__ == "__main__":
    sys.exit(main())
