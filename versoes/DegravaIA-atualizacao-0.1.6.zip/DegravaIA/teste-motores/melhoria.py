"""Rodada 6: a melhoria de áudio do item 6 ajuda ou atrapalha a transcrição?

Usa os mesmos trechos da rodada 5 (calibrar_confianca.py, mesma semente). Para
cada nível de melhoria, gera a cópia melhorada com os filtros do próprio app
(degravaia.audio.MELHORIAS), transcreve com a mesma configuração e compara o
erro literal com o do áudio sem melhoria (já medido na rodada 5).

    python melhoria.py transcrever --ruins 40 --bons 10
    python melhoria.py analisar
"""
import argparse
import io
import json
import sys
import tempfile
from pathlib import Path

import jiwer
import numpy as np
import soundfile as sf

AQUI = Path(__file__).resolve().parent
sys.path.insert(0, str(AQUI.parent))
sys.path.insert(0, str(AQUI))
import calibrar_confianca as cal  # noqa: E402
from comparar import HESITACOES, normalizar  # noqa: E402

SAIDA = AQUI / "resultados_melhoria.json"


def _selecao(args):
    base = json.loads(cal.SAIDA.read_text(encoding="utf-8"))
    amostras = cal._amostras(args.dados, 70, 5)[:len(base)]
    ruins = [k for k, b in enumerate(base) if b["qualidade"] == "low"][:args.ruins]
    bons = [k for k, b in enumerate(base) if b["qualidade"] == "high"][:args.bons]
    return base, amostras, bons + ruins


def transcrever(args):
    from faster_whisper import WhisperModel

    from degravaia import audio
    from degravaia.config import MODELO_WHISPER, PROMPT_HESITACOES

    base, amostras, indices = _selecao(args)
    modelo = WhisperModel(MODELO_WHISPER, device="cpu", compute_type="int8")
    resultados = json.loads(SAIDA.read_text(encoding="utf-8")) if SAIDA.exists() else {}
    with tempfile.TemporaryDirectory() as tmp:
        for n, k in enumerate(indices, 1):
            l = amostras[k]
            assert l["original_text"] == base[k]["referencia"]
            bruto = Path(tmp) / "bruto.wav"
            onda, taxa = sf.read(io.BytesIO(l["audio"]["bytes"]), dtype="float32")
            sf.write(bruto, onda, taxa)
            item = resultados.setdefault(str(k), {"qualidade": base[k]["qualidade"],
                                                  "referencia": base[k]["referencia"],
                                                  "sem": " ".join(p["texto"] for p in base[k]["palavras"])})
            for nivel in audio.MELHORIAS:
                if nivel in item:
                    continue
                destino = Path(tmp) / f"{nivel}.wav"
                audio.melhorar(bruto, destino, nivel, taxa=16000)
                melhorado, _ = sf.read(destino, dtype="float32")
                segs, _ = modelo.transcribe(melhorado.astype(np.float32), language="pt", hotwords=PROMPT_HESITACOES,
                                            beam_size=5, word_timestamps=True, condition_on_previous_text=False,
                                            vad_filter=False)
                item[nivel] = " ".join(w.word.strip() for s in segs for w in (s.words or []))
            print(f"{n}/{len(indices)} {item['qualidade']} | sem: {item['sem'][:40]} | forte: {item['forte'][:40]}",
                  flush=True)
            SAIDA.write_text(json.dumps(resultados, ensure_ascii=False, indent=1), encoding="utf-8")


def _comparavel(texto):
    saida = []
    for w in normalizar(texto).split():
        if not any(c.isdigit() for c in w):
            saida += cal.COLOQUIAL.get(w, w).split()
    return " ".join(saida)


def analisar(args):
    resultados = json.loads(SAIDA.read_text(encoding="utf-8"))
    print("| Áudio | Trechos | Sem melhoria | Leve | Médio | Forte |")
    print("|---|---|---|---|---|---|")
    for q, nome in (("high", "bom"), ("low", "ruim")):
        itens = [r for r in resultados.values() if r["qualidade"] == q and "forte" in r]
        if not itens:
            continue
        refs = [_comparavel(r["referencia"]) for r in itens]
        celulas = []
        for cond in ("sem", "leve", "medio", "forte"):
            hips = [_comparavel(r[cond]) for r in itens]
            hes = sum(1 for h in hips for w in h.split() if w in HESITACOES)
            celulas.append(f"{100 * jiwer.wer(refs, hips):.1f}% ({hes} hes.)")
        print(f"| {nome} | {len(itens)} | " + " | ".join(celulas) + " |")
    refs_hes = sum(1 for r in resultados.values() for w in _comparavel(r["referencia"]).split() if w in HESITACOES)
    print(f"\nErro literal (menor é melhor); entre parênteses, hesitações escritas (referência: {refs_hes}).")


def main():
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)
    t = sub.add_parser("transcrever")
    t.add_argument("--dados", default=str(AQUI / "dados/data"))
    t.add_argument("--ruins", type=int, default=40)
    t.add_argument("--bons", type=int, default=10)
    sub.add_parser("analisar")
    args = ap.parse_args()
    transcrever(args) if args.cmd == "transcrever" else analisar(args)


if __name__ == "__main__":
    main()
