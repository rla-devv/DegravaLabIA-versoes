# Roteiro de teste no seu PC (Windows)

Tudo o que foi construído até aqui foi testado em Linux, só com CPU e com áudios
de um corpus público. Este roteiro confere o que só dá para ver na sua máquina.
Anote o resultado de cada passo (ok / problema + mensagem) e me envie.

## 0. Antes de começar
- **Python:** não precisa. O pacote traz o Python portátil oficial na pasta
  `python`, e nada é instalado no Windows.
- **Na máquina com a GTX 1650:** driver NVIDIA atualizado.
- **Conta ou token do Hugging Face:** não precisa. O modelo de interlocutores
  vem dentro do pacote e os outros dois são de download livre.
- **Internet:** só durante a instalação, para baixar cerca de 8 GB entre
  bibliotecas e modelos. Tudo fica dentro da pasta do DegravaIA.

## 1. Instalação
1. Descompacte o `DegravaIA.zip` inteiro (botão direito → Extrair tudo) e dê
   dois cliques em **`instalar.bat`**.
2. No fim aparece o **diagnóstico**. **Me envie o texto dele**. Na GTX 1650,
   confira se as duas linhas de GPU dizem "sim" / "NVIDIA GeForce GTX 1650".

## 2. Abrir sem internet
1. **Desligue a internet** (Wi-Fi/cabo).
2. Dê dois cliques em **`abrir.bat`**. O navegador abre em `http://127.0.0.1:8765/`.
3. Do celular, na mesma rede, tente abrir `http://<IP do PC>:8765/`.
   **Não deve abrir** (item 12).

## 3. Importar um áudio real
Use um depoimento real, de preferência de **10 a 30 minutos**, com 2 ou 3
pessoas.
1. **Importar arquivo…** → escolha o arquivo → informe o número de pessoas →
   **Importar**.
2. **Anote o tempo total** da importação e a duração do áudio.
3. **Na GTX 1650:** abra outro Prompt de Comando e rode `nvidia-smi -l 2`
   durante a importação. **Anote o maior valor de memória usada** (o limite é
   4096 MiB). Se der erro de memória, me envie a mensagem.

## 4. Conferir a qualidade (o mais importante)
Ouça pelo menos 5 minutos e confira:
- **Literalidade:** "é…", "né", "tipo", repetições e falas cortadas aparecem
  como foram ditas?
- **Interlocutores:** as falas estão na pessoa certa? Quantas trocas erradas
  em 5 minutos?
- **`[ininteligível …]`:** os trechos marcados eram mesmo ruins? Algum trecho
  ruim ficou sem marca?
- **Palavras inventadas:** algo escrito que não foi dito? Se houver, anote o
  minuto.

## 5. Revisão e exportação
1. **Corrigir:**
   - corrija uma palavra (duplo clique);
   - troque o interlocutor de uma fala;
   - renomeie um interlocutor;
   - decida uma marcação;
   - desfaça (Ctrl+Z).
2. **Player:** teste 0,5x/0,75x (a voz não deve ficar distorcida), a repetição
   (Alt+L) e os atalhos.
3. **Reabrir:** feche o navegador e a janela preta, abra de novo pelo
   `abrir.bat`. As alterações e a posição do áudio continuam lá?
4. **Exportar:**
   - exporte DOCX, PDF e XLSX;
   - abra no **Word** e confira: acentos, "Página X de Y" no rodapé e tabela
     do cabeçalho;
   - abra o PDF e o XLSX.
5. **Ajuda por trecho:** use **Trecho ▾ → Reanalisar** num trecho ruim e anote
   quanto tempo leva.

## 6. Me envie
- o texto do diagnóstico;
- tempo da importação × duração do áudio, e memória máxima da GPU;
- suas notas da seção 4;
- qualquer mensagem de erro, com print da janela preta se houver.
