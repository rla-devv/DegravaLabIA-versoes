// Degrava Lab IA — tela de revisão (itens 4, 5, 7, 12, 13 e 14 dos requisitos).
// Nada aqui altera arquivos de áudio; toda alteração de texto vai ao servidor,
// que salva na hora e registra no histórico.
"use strict";

const $ = (id) => document.getElementById(id);
const audio = $("audio");
const CONFIANCA_MINIMA = 0.5;
const SALTO_S = 3;

let projetoId = null;
let dados = null;          // palavras, falas, interlocutores…
let spans = [];            // span de cada palavra, pelo índice
let ancora = null;         // início da seleção (Shift+clique)
let selecao = null;        // [i, j] índices de palavras
let loop = null;           // {inicio, fim}
let atual = -1;            // palavra tocando agora
let rolagemManual = 0;     // instante da última rolagem feita pelo usuário

// ---------- utilitários ----------
function tempo(s, decimos = false) {
  s = Math.max(0, s || 0);
  const h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), seg = Math.floor(s % 60);
  const base = [h, m, seg].map((n) => String(n).padStart(2, "0")).join(":");
  return decimos ? `${base}.${Math.floor((s % 1) * 10)}` : base;
}

function el(tag, props = {}, ...filhos) {
  const e = document.createElement(tag);
  for (const [k, v] of Object.entries(props)) {
    if (k === "class") e.className = v;
    else if (k === "dataset") Object.assign(e.dataset, v);
    else if (k.startsWith("on")) e.addEventListener(k.slice(2), v);
    else e[k] = v;
  }
  for (const f of filhos) if (f != null) e.append(f);
  return e;
}

// Mensagens: na revisão, o "Salvando… / Tudo salvo" fica pequeno no topo; os avisos (projeto excluído,
// erros) aparecem num aviso flutuante embaixo, que some sozinho, sem empurrar os botões do cabeçalho
let avisoTempo = null;
function estado(texto, erro = false) {
  const s = $("estado");
  if (document.body.classList.contains("em-revisao") && !erro) {
    s.textContent = texto;
    s.classList.remove("erro");
    return;
  }
  const a = $("aviso-rapido");
  a.querySelector("span").textContent = texto;
  a.classList.toggle("erro", erro);
  a.hidden = false;
  clearTimeout(avisoTempo);
  avisoTempo = setTimeout(() => { a.hidden = true; }, erro ? 9000 : 4000);
}

// O programa da janela preta não respondeu (fechado ou reiniciando): mensagem que diz o que fazer
const SEM_PROGRAMA = "O Degrava Lab IA não respondeu. Aguarde alguns segundos e tente de novo; se continuar, " +
  "feche o Degrava Lab IA e abra de novo pelo atalho.";

async function chamar(url, opcoes) {
  try {
    return await fetch(url, opcoes);
  } catch (e) {
    throw new Error(SEM_PROGRAMA);
  }
}

async function api(caminho, corpo) {
  const opcoes = corpo === undefined ? {} : {
    method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(corpo) };
  const r = await chamar(`/api/projetos${caminho}`, opcoes);
  const j = await r.json();
  if (!r.ok) throw new Error(j.erro || `Erro ${r.status}`);
  return j;
}

function corDe(falante) {
  const chaves = Object.keys(dados.interlocutores);
  const i = chaves.indexOf(falante);
  return i < 0 ? "var(--linha)" : `var(--f${(i % 6) + 1})`;
}

function nomeDe(falante) {
  return dados.interlocutores[falante] || "Interlocutor não identificado";
}

// ---------- lista de projetos ----------
async function mostrarLista() {
  $("lista").hidden = false;
  $("titulo").textContent = "";
  const { projetos, pasta, versao, janela } = await api("");
  if (versao) $("versao").textContent = versao;
  document.documentElement.classList.toggle("janela-propria", !!janela);
  $("pasta").textContent = pasta;
  $("vazio").hidden = projetos.length > 0;
  $("projetos").replaceChildren(...projetos.map((p) => {
    const pend = p.pendentes ? el("span", { class: "status pendente" }, `${p.pendentes} decisão(ões) pendente(s)`)
      : el("span", { class: "status pronto" }, "Sem pendências");
    return el("li", { class: "cartao" },
      el("div", {},
        el("h3", {}, p.arquivo),
        el("div", { class: "meta" },
          el("span", {}, `Importado em ${new Date(p.importado_em).toLocaleString("pt-BR")}`),
          el("span", {}, `Duração ${p.duracao_s ? tempo(p.duracao_s) : "—"}`),
          el("span", {}, `${p.interlocutores} interlocutor(es)`),
          el("span", {}, `${p.alteracoes} alteração(ões) na revisão`), pend)),
      el("div", { class: "acoes" },
        el("a", { class: "pilula primario", href: `/projeto/${encodeURIComponent(p.id)}` }, "Abrir"),
        el("button", { class: "pilula perigo", type: "button", title: "Apagar este projeto da pasta",
          onclick: () => excluirProjeto(p) }, "Excluir")));
  }));
}

async function excluirProjeto(p) {
  if (!await perguntar({ titulo: "Excluir o projeto?", sim: "Excluir", perigo: true, texto: [
    `"${p.arquivo}"`,
    "Isso apaga da pasta a cópia do áudio original, a transcrição, o histórico de revisão e os documentos " +
      "exportados deste projeto. Não dá para desfazer.",
    "O arquivo de áudio que você importou (fora do Degrava Lab IA) não é tocado."] })) return;
  try {
    await api(`/${encodeURIComponent(p.id)}/excluir`, {});
    estado(`Projeto "${p.arquivo}" excluído.`);
    mostrarLista();
  } catch (e) {
    estado(e.message, true);
  }
}

// ---------- importação pela tela (item 15: idioma escolhido aqui) ----------
function abrirImportacao(arquivo) {
  if (arquivo instanceof File) {
    const dt = new DataTransfer();
    dt.items.add(arquivo);
    $("imp-arquivo").files = dt.files;
  }
  $("imp-form").hidden = false;
  $("imp-andamento").hidden = true;
  $("imp-iniciar").hidden = false;
  $("imp-iniciar").disabled = false;
  if (!$("importar").open) $("importar").showModal();
}

function iniciarImportacao() {
  const arquivo = $("imp-arquivo").files[0];
  if (!arquivo) { avisar("Escolha um arquivo", "Escolha o áudio ou vídeo que vai ser transcrito."); return; }
  const q = new URLSearchParams({ nome: arquivo.name, idioma: $("imp-idioma").value,
    falantes: $("imp-falantes").value || "", interlocutores: $("imp-interlocutores").checked ? "1" : "0",
    vocabulario: $("imp-vocabulario").value.trim(),
    melhoria: $("imp-melhoria").value });
  $("imp-form").hidden = true;
  $("imp-andamento").hidden = false;
  $("imp-iniciar").disabled = true;
  $("imp-iniciar").hidden = true;  // durante o processamento, o botão só confundiria
  $("imp-fim").hidden = true;
  $("imp-log").textContent = "Enviando o arquivo para o programa (fica neste computador)…\n";
  mostrarAndamento(null);
  $("imp-detalhes").open = false;
  const xhr = new XMLHttpRequest();  // XHR: mostra o progresso do envio
  xhr.open("POST", `/api/importar?${q}`);
  xhr.setRequestHeader("Content-Type", "application/octet-stream");
  xhr.upload.onprogress = (ev) => {
    if (!ev.lengthComputable) return;
    const pct = Math.floor((100 * ev.loaded) / ev.total);
    $("imp-barra").value = pct;
    $("imp-pct").textContent = `${pct}%`;
    $("imp-etapa").textContent = "Copiando o arquivo para o programa (fica neste computador)";
  };
  xhr.onload = () => {
    let j = {};
    try { j = JSON.parse(xhr.responseText); } catch (e) { /* resposta inesperada */ }
    if (xhr.status !== 200) { terminarImportacao(false, j.erro || `Erro ${xhr.status}`); return; }
    $("imp-barra").value = 0;
    $("imp-pct").textContent = "0%";
    acompanhar(j.tarefa);
  };
  xhr.onerror = () => terminarImportacao(false, "Falha no envio.");
  xhr.send(arquivo);
}

// ---------- andamento da importação (andamento.py) ----------
let andamento = null;     // último estado recebido do servidor
let recebidoEm = 0;       // quando chegou: o relógio da tela anda entre uma consulta e outra
let relogio = null;

function duracaoTexto(s) {
  s = Math.max(0, Math.round(s));
  const h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), seg = s % 60;
  return h ? `${h}:${String(m).padStart(2, "0")}:${String(seg).padStart(2, "0")}`
    : `${String(m).padStart(2, "0")}:${String(seg).padStart(2, "0")}`;
}

function faltaTexto(s) {
  if (s == null) return "Calculando o tempo restante…";
  if (s < 45) return "Falta menos de 1 minuto";
  const min = Math.ceil(s / 60);
  if (min < 60) return `Falta cerca de ${min} min`;
  return `Falta cerca de ${Math.floor(min / 60)} h ${String(min % 60).padStart(2, "0")} min`;
}

function atualizarRelogio() {
  if (!andamento) return;
  const extra = (Date.now() - recebidoEm) / 1000;  // segundos desde a última consulta
  $("imp-passado").textContent = duracaoTexto(andamento.passado_s + extra);
  const falta = andamento.falta_s == null ? null : andamento.falta_s - extra;
  $("imp-falta").textContent = falta != null && falta <= 0 ? "Quase lá…" : faltaTexto(falta);
}

function mostrarAndamento(a) {
  andamento = a;
  recebidoEm = Date.now();
  clearInterval(relogio);
  if (!a) {
    $("imp-etapas").replaceChildren();
    $("imp-passado").textContent = "00:00";
    $("imp-falta").textContent = "Calculando o tempo restante…";
    return;
  }
  $("imp-barra").value = a.porcentagem;
  $("imp-pct").textContent = `${a.porcentagem}%`;
  $("imp-etapa").textContent = `Etapa ${a.numero} de ${a.de}: ${a.nome}` +
    (a.frac_etapa > 0 && a.frac_etapa < 1 ? ` (${Math.floor(a.frac_etapa * 100)}%)` : "…");
  $("imp-etapas").replaceChildren(...a.etapas.map((e) =>
    el("li", { class: e.feita ? "feita" : e.id === a.etapa ? "atual" : "" }, e.nome)));
  atualizarRelogio();
  relogio = setInterval(atualizarRelogio, 1000);  // o tempo passado anda a cada segundo: dá para ver que não travou
}

async function acompanhar(tarefa) {
  let j;
  try {
    const r = await fetch(`/api/importacoes/${tarefa}`);
    j = await r.json();
    if (r.status === 404) {  // o programa da tela reiniciou no meio: a importação pode ter terminado
      clearInterval(relogio);
      terminarImportacao(false, "o programa reiniciou durante a importação. Veja em Seus projetos se o " +
        "projeto foi salvo; se não, importe de novo.");
      if (!projetoId) mostrarLista();
      return;
    }
  } catch (e) {  // o programa não respondeu (reiniciando?): tenta de novo
    setTimeout(() => acompanhar(tarefa), 3000);
    return;
  }
  $("imp-log").textContent = j.log.join("\n");
  $("imp-log").scrollTop = $("imp-log").scrollHeight;
  if (j.estado === "rodando") {
    mostrarAndamento(j.andamento);
    setTimeout(() => acompanhar(tarefa), 1500);
  } else {
    clearInterval(relogio);
    if (j.estado === "pronto") {
      $("imp-pct").textContent = "100%";
      $("imp-etapa").textContent = `Pronto em ${duracaoTexto(j.andamento.passado_s)}`;
      $("imp-passado").textContent = duracaoTexto(j.andamento.passado_s);
      $("imp-falta").textContent = "";
      $("imp-etapas").querySelectorAll("li").forEach((li) => { li.className = "feita"; });
    } else {
      $("imp-detalhes").open = true;  // mostra o erro
    }
    terminarImportacao(j.estado === "pronto", j.estado === "pronto" ? null : (j.erro || "Veja os detalhes técnicos acima."), j.projeto);
  }
}

function terminarImportacao(ok, erro, projeto) {
  clearInterval(relogio);
  $("imp-barra").value = ok ? 100 : 0;
  $("imp-iniciar").hidden = true;
  const fim = $("imp-fim");
  fim.hidden = false;
  fim.replaceChildren(ok
    ? el("a", { class: "primario botao-link", href: `/projeto/${encodeURIComponent(projeto)}` }, "Abrir o projeto para revisar")
    : el("b", { class: "erro" }, `Não foi possível importar: ${erro}`));
  if (ok && !projetoId) mostrarLista();  // na revisão, a lista não aparece por baixo
}

$("botao-importar").addEventListener("click", () => {
  abrirImportacao();
  if (!$("imp-arquivo").files.length) $("imp-arquivo").click();
});
// arrastar e soltar um arquivo em qualquer lugar de qualquer página (também na revisão)
let arrastes = 0;  // dragenter/dragleave disparam a cada elemento: conta para saber quando saiu da janela
const comArquivo = (ev) => ev.dataTransfer && Array.from(ev.dataTransfer.types).includes("Files");
const importando = () => $("importar").open && !$("imp-andamento").hidden;
function mostrarCortina(sim) {
  $("cortina").hidden = !sim;
  $("soltar").classList.toggle("arrastando", sim);
}
document.addEventListener("dragenter", (ev) => {
  if (!comArquivo(ev)) return;
  ev.preventDefault();
  arrastes++;
  if (!importando()) mostrarCortina(true);
});
document.addEventListener("dragover", (ev) => {
  if (!comArquivo(ev)) return;
  ev.preventDefault();  // sem isto o navegador abre o arquivo no lugar da página
  ev.dataTransfer.dropEffect = importando() ? "none" : "copy";
});
document.addEventListener("dragleave", (ev) => {
  if (!comArquivo(ev)) return;
  if (--arrastes <= 0) { arrastes = 0; mostrarCortina(false); }
});
document.addEventListener("drop", (ev) => {
  if (!comArquivo(ev)) return;
  ev.preventDefault();
  arrastes = 0;
  mostrarCortina(false);
  const arquivo = ev.dataTransfer.files[0];
  if (arquivo && !importando()) abrirImportacao(arquivo);
});
$("imp-iniciar").addEventListener("click", iniciarImportacao);

// ---------- revisão ----------
async function abrirProjeto(id) {
  projetoId = id;
  document.body.classList.add("em-revisao");
  const j = await api(`/${encodeURIComponent(id)}`);
  dados = j.dados;
  $("revisao").hidden = false;
  $("botao-exportar").hidden = false;
  const o = dados.original;
  $("titulo").textContent = `${o.nome}  ·  SHA-256 ${o.sha256.slice(0, 12)}…`;
  $("titulo").title = `SHA-256 ${o.sha256}`;
  document.title = `${o.nome} — Degrava Lab IA`;
  audio.src = `/api/projetos/${encodeURIComponent(id)}/audio`;
  const pos = (dados.revisao && dados.revisao.posicao_s) || 0;
  audio.addEventListener("loadedmetadata", () => {
    $("barra").max = audio.duration;
    $("duracao").textContent = tempo(audio.duration);
    if (pos) audio.currentTime = pos;
  }, { once: true });
  $("caixa-versao").hidden = !dados.melhoria;
  definirVelocidade(1);
  desenharTudo();
  carregarHistorico();
  estado("Tudo salvo");
}

function desenharTudo() {
  const rolagem = window.scrollY;
  desenharTexto();
  desenharInterlocutores();
  desenharPendencias();
  aplicarSelecao();
  atual = -1;
  marcarAtual();
  window.scrollTo(0, rolagem);
}

function classesPalavra(p) {
  const c = ["p"];
  if (p.texto === "") c.push("apagado");
  else if (p.revisado) c.push("revisado");
  else if (p.suspeita_alucinacao) c.push("suspeita");
  else if (p.prob < CONFIANCA_MINIMA) c.push("baixa");
  else if (p.discorda) c.push("discorda");
  if (p.sobreposicao) c.push("sobrep");
  return c.join(" ");
}

function dicaPalavra(p) {
  const partes = [`${tempo(p.inicio, true)}`, `certeza ${Math.round(p.prob * 100)}%`];
  if (p.texto_ia !== undefined && p.texto_ia !== p.texto) partes.push(`IA: "${p.texto_ia}"`);
  if (p.suspeita_alucinacao) partes.push("possível trecho inventado pelo motor: ouvir");
  if (p.discorda) partes.push(p.ouvido_segunda ? `segunda escuta ouviu: "${p.ouvido_segunda}"` : "segunda escuta não ouviu nada aqui");
  if (p.sobreposicao) partes.push("vozes sobrepostas");
  if (p.falante_ia !== undefined && p.falante_ia !== p.falante) partes.push(`IA atribuiu a ${nomeDe(p.falante_ia)}`);
  return partes.join(" · ");
}

function marcacaoPorId(id) { return dados.marcacoes.find((m) => m.id === id); }
function insercaoPorId(id) { return dados.insercoes.find((x) => x.id === id); }

const ROTULOS = { ininteligivel: "ininteligível", inaudivel: "inaudível", sobreposicao: "sobreposição de vozes",
  risos: "risos", choro: "choro", reanalise: "trecho reanalisado" };
const SUBSTITUI = { ininteligivel: true, inaudivel: true, risos: true, choro: true, sobreposicao: false, reanalise: true };
const NIVEIS = { leve: "leve", medio: "médio", forte: "forte" };

function pendente(m) { return m.origem === "ia" && !m.decisao && SUBSTITUI[m.tipo]; }

// O texto vem do servidor já como vai ao documento (marcacoes.partes_da_fala).
// O que é só sugestão aparece apagado e NÃO vai ao documento (item 3).
function desenharTexto() {
  const texto = $("texto");
  spans = new Array(dados.palavras.length);
  const blocos = dados.falas.map((fala, nf) => {
    const corpo = el("div", { class: "frase" });
    let grupo = null;  // palavras escondidas por uma marcação ficam juntas, como sugestão
    fala.partes.forEach((parte, k) => {
      const destino = parte.tipo === "palavra" && parte.sugestao && grupo ? grupo : corpo;
      if (k && destino === corpo) corpo.append(" ");
      if (destino === grupo) grupo.append(" ");
      if (parte.tipo === "pausa") {
        corpo.append(el("span", { class: "marcacao" }, parte.texto));
      } else if (parte.tipo === "marcacao") {
        const m = marcacaoPorId(parte.marcacao);
        const cls = ["marca", m.tipo, parte.decidida ? "decidida" : "", pendente(m) ? "pendente" : "",
          m.origem === "usuario" ? "do-usuario" : ""].join(" ");
        const botao = el("button", { class: cls, dataset: { m: m.id },
          title: parte.decidida ? `Decidido por você no lugar de [${ROTULOS[m.tipo]}]` :
            pendente(m) ? "Marcação da IA: clique para ouvir e decidir" : "Marcação",
          onclick: (ev) => painelMarcacao(ev, m) }, parte.texto || "∅");
        if (parte.decidida && !parte.texto) {  // "não há palavra aqui": só um sinal discreto para poder rever
          botao.classList.add("sem-palavra");
          botao.title = `Você decidiu que não há palavra aqui (antes [${ROTULOS[m.tipo]}]). Nada vai ao documento. Clique para rever.`;
        }
        corpo.append(botao);
        grupo = SUBSTITUI[m.tipo] ? el("span", { class: "sugerido", title: "Texto do motor: não vai ao documento" }) : null;
        if (grupo) corpo.append(grupo);
        return;
      } else if (parte.tipo === "insercao") {
        const x = insercaoPorId(parte.insercao);
        corpo.append(el("button", { class: parte.sugestao ? "ins sug" : "ins", dataset: { x: x.id },
          title: parte.sugestao ? `A segunda escuta ouviu "${x.texto}" aqui: clique para decidir` :
            (x.origem === "usuario" ? "Inserido por você" : "Sugestão aceita por você"),
          onclick: (ev) => painelInsercao(ev, x) }, parte.sugestao ? `+ ${parte.texto}` : parte.texto));
      } else {
        const i = parte.palavra, p = dados.palavras[i];
        const s = el("span", { class: classesPalavra(p), title: dicaPalavra(p), dataset: { i } },
          p.texto === "" ? (p.texto_ia || "") : p.texto);
        spans[i] = s;
        destino.append(s);
      }
      if (parte.tipo !== "palavra" || !parte.sugestao) grupo = null;
    });
    const ids = fala.itens.filter((x) => "palavra" in x).map((x) => x.palavra);
    const corrigida = ids.some((i) => {
      const p = dados.palavras[i];
      return p.falante_ia !== undefined && p.falante_ia !== p.falante;
    });
    const cab = el("div", { class: "cab" },
      el("button", { class: "hora", title: "Ir para o início da fala",
        onclick: () => irPara(fala.inicio) }, `[${tempo(fala.inicio)}]`),
      el("button", { class: "quem", title: "Trocar o interlocutor desta fala ou da seleção",
        onclick: (ev) => menuInterlocutor(ev, nf) }, `${nomeDe(fala.falante)}:`),
      corrigida ? el("span", { class: "marca-rev", title: "Interlocutor corrigido por você" }, "corrigido") : null);
    const bloco = el("section", { class: "fala" }, cab, corpo);
    bloco.style.setProperty("--cor", corDe(fala.falante));
    return bloco;
  });
  texto.replaceChildren(...blocos);
}

function desenharInterlocutores() {
  const usados = {};
  for (const p of dados.palavras) if (p.falante != null) usados[p.falante] = (usados[p.falante] || 0) + 1;
  const caixa = $("interlocutores");
  caixa.replaceChildren(...Object.entries(dados.interlocutores).map(([f, nome]) => {
    const campo = el("input", { value: nome, title: "Renomear (Enter salva)",
      onkeydown: (ev) => { if (ev.key === "Enter") campo.blur(); if (ev.key === "Escape") { campo.value = nome; campo.blur(); } },
      onchange: () => alterar({ tipo: "renomear_interlocutor", falante: f, depois: campo.value })
        .catch(() => { campo.value = nome; }) });
    const outros = Object.keys(dados.interlocutores).filter((o) => o !== f);
    const juntar = outros.length ? el("button", { class: "icone-mini", type: "button", title: "Juntar com outro interlocutor",
      onclick: (ev) => menuJuntar(ev, f) }, "⋯") : null;
    const linha = el("div", { class: "interlocutor" }, el("span", { class: "bola" }), campo,
      el("small", {}, `${usados[f] || 0} pal.`), juntar);
    linha.style.setProperty("--cor", corDe(f));
    // voz com muito pouca fala: costuma ser a mesma pessoa com outra entonação (grito, choro, imitação)
    const total = Object.values(usados).reduce((a, b) => a + b, 0);
    const parte = (usados[f] || 0) / (total || 1);
    if (outros.length && usados[f] && parte < 0.1) {
      const i = dados.palavras.findIndex((p) => p.falante === f);
      const maior = outros.reduce((a, b) => ((usados[a] || 0) >= (usados[b] || 0) ? a : b));
      return el("div", {}, linha, el("div", { class: "aviso pequeno" },
        `Só ${Math.max(1, Math.round(parte * 100))}% das palavras. Pode ser a mesma pessoa com outra entonação: ouça e, se for, junte. `,
        el("button", { class: "link", onclick: () => irPara(dados.palavras[i].inicio) }, "Ouvir"), " · ",
        el("button", { class: "link", onclick: () => juntarInterlocutores(f, maior) }, `Juntar com ${nomeDe(maior)}`)));
    }
    return linha;
  }));
}

function menuJuntar(ev, de) {
  ev.stopPropagation();
  const menu = $("menu");
  menu.replaceChildren(el("div", { class: "dica" }, `Juntar ${nomeDe(de)} com:`),
    ...Object.keys(dados.interlocutores).filter((o) => o !== de).map((para) =>
      el("button", { role: "menuitem", onclick: () => { fecharMenu(); juntarInterlocutores(de, para); } }, nomeDe(para))));
  const r = ev.currentTarget.getBoundingClientRect();
  menu.style.left = `${r.left + window.scrollX - 160}px`;
  menu.style.top = `${r.bottom + window.scrollY + 4}px`;
  menu.hidden = false;
}

async function juntarInterlocutores(de, para) {
  if (!await perguntar({ titulo: "Juntar interlocutores?", sim: "Juntar", texto: [
    `Juntar "${nomeDe(de)}" com "${nomeDe(para)}".`,
    `Todas as falas de ${nomeDe(de)} passam a ser de ${nomeDe(para)}. Fica no histórico e dá para desfazer (Ctrl+Z).`] })) return;
  const sobra = Object.keys(dados.interlocutores).length - 1;
  const nSobrep = dados.marcacoes.filter((m) => m.tipo === "sobreposicao" && m.origem === "ia").length;
  const remover = sobra === 1 && nSobrep > 0 && await perguntar({
    titulo: "Remover as marcações de sobreposição?", sim: "Remover", nao: "Manter", texto: [
      `Agora há uma voz só. Remover também as ${nSobrep} marcação(ões) de [sobreposição de vozes] feitas pela IA?`] });
  await alterar({ tipo: "juntar_interlocutores", de, para, remover_sobreposicoes: remover });
}

function desenharPendencias() {
  const marcas = dados.marcacoes.filter(pendente);
  const ins = dados.insercoes.filter((x) => x.origem === "ia" && !x.decisao);
  $("pendencias").textContent = marcas.length + ins.length === 0
    ? "Nada pendente. O documento está pronto para exportar."
    : `${marcas.length} trecho(s) marcado(s) e ${ins.length} sugestão(ões) da segunda escuta aguardando sua decisão.`;
  $("proxima").disabled = $("anterior").disabled = marcas.length + ins.length === 0;
}

let pendenciaAtual = null;  // instante da última pendência aberta por Próxima/Anterior

function proximaPendencia(direcao = 1) {
  const itens = [
    ...dados.marcacoes.filter(pendente).map((m) => ({ t: m.inicio, sel: `[data-m="${m.id}"]` })),
    ...dados.insercoes.filter((x) => x.origem === "ia" && !x.decisao).map((x) => ({ t: x.inicio, sel: `[data-x="${x.id}"]` })),
  ].sort((a, b) => a.t - b.t);
  // referência: a pendência aberta por último, se o áudio ainda está perto dela; senão, onde o áudio está
  const perto = pendenciaAtual !== null && audio.currentTime >= pendenciaAtual - 1.5 && audio.currentTime <= pendenciaAtual + 3;
  const ref = perto ? pendenciaAtual : audio.currentTime - 0.05;
  const alvo = direcao > 0
    ? itens.find((x) => x.t > ref + 0.01) || itens[0]
    : [...itens].reverse().find((x) => x.t < ref - 0.01) || itens[itens.length - 1];
  if (!alvo) return;
  pendenciaAtual = alvo.t;
  const botao = document.querySelector(alvo.sel);
  irPara(Math.max(0, alvo.t - 1));
  botao.scrollIntoView({ block: "center" });
  botao.click();
}

// ---------- marcações e sugestões (item 3) ----------
function abrirPainel(ancora, filhos) {
  const menu = $("menu");
  menu.replaceChildren(...filhos);
  const r = ancora.getBoundingClientRect();
  menu.style.left = `${Math.min(r.left, window.innerWidth - 340) + window.scrollX}px`;
  menu.style.top = `${r.bottom + window.scrollY + 4}px`;
  menu.hidden = false;
}

function ouvirTrecho(inicio, fim) {
  loop = { inicio: Math.max(0, inicio - 0.5), fim: fim + 0.5 };
  $("loop").classList.add("ativo");
  $("loop").textContent = `⟲ ${tempo(loop.inicio)}–${tempo(loop.fim)}`;
  audio.currentTime = loop.inicio;
  audio.play();
}

// Ao aceitar, o app pergunta como inserir: com dúvida, normal, digitado ou manter a marcação.
function perguntarComoInserir(ancora, texto, decidir, rotuloManter) {
  const campo = el("input", { class: "editor largo", value: texto, placeholder: "Digite o texto" });
  const duvida = el("input", { type: "checkbox" });
  abrirPainel(ancora, [
    el("div", { class: "dica" }, "Como inserir no documento?"),
    el("button", { onclick: () => decidir("duvida", texto) }, `Com indicação de dúvida: ${texto} (?)`),
    el("button", { onclick: () => decidir("normal", texto) }, `Como texto normal: ${texto}`),
    el("div", { class: "linha-digitar" }, campo,
      el("label", { class: "opcao" }, duvida, " (?)"),
      el("button", { class: "ok", onclick: () => decidir(duvida.checked ? "duvida" : "digitado", campo.value) }, "Inserir")),
    el("button", { onclick: () => decidir("marcacao", "") }, rotuloManter),
  ]);
  campo.addEventListener("keydown", (ev) => {
    ev.stopPropagation();
    if (ev.key === "Enter") decidir(duvida.checked ? "duvida" : "digitado", campo.value);
  });
}

function painelMarcacao(ev, m) {
  ev.stopPropagation();
  const ancora = ev.currentTarget;
  const decidir = (modo, texto) => {
    fecharMenu();
    alterar({ tipo: "decidir_marcacao", marcacao: m.id, modo, texto });
  };
  const filhos = [
    el("div", { class: "dica" }, `[${ROTULOS[m.tipo]}] ${tempo(m.inicio, true)}–${tempo(m.fim, true)}` +
      (m.origem === "ia" ? " · marcada pela IA" : " · marcada por você")),
    el("button", { onclick: () => ouvirTrecho(m.inicio, m.fim) }, "▶ Ouvir em repetição"),
  ];
  if (SUBSTITUI[m.tipo]) {
    if (m.sugestoes.length) filhos.push(el("div", { class: "dica" }, "Sugestões (não estão no documento):"));
    for (const sug of m.sugestoes) {
      filhos.push(el("button", { class: "sugestao",
        onclick: () => perguntarComoInserir(ancora, sug.texto, decidir, `Manter [${ROTULOS[m.tipo]}]`) },
        `“${sug.texto}”`, el("small", {}, ` ${sug.origem}`)));
    }
    filhos.push(el("button", { onclick: () => perguntarComoInserir(ancora, "", decidir, `Manter [${ROTULOS[m.tipo]}]`) },
      "Digitar outra palavra…"));
    filhos.push(el("button", { onclick: () => decidir("marcacao", "") }, `Manter [${ROTULOS[m.tipo]}]`));
    filhos.push(el("button", { title: "Você ouviu e não há palavra aqui (ruído, respiração): a marcação sai e nada entra no documento",
      onclick: () => decidir("sem_palavra", "") }, "Não há palavra aqui"));
  }
  if (SUBSTITUI[m.tipo] && m.palavras.length) {
    const decidirCom = (texto) => perguntarComoInserir(ancora, texto, decidir, `Manter [${ROTULOS[m.tipo]}]`);
    filhos.push(el("div", { class: "linha-digitar" },
      el("button", { class: "ok", onclick: () => reanalisar(ancora, m.palavras, null, decidirCom) }, "Reanalisar"),
      ...Object.entries(NIVEIS).map(([k, v]) => el("button", { class: "ok", title: `Reanalisar com áudio melhorado (${v})`,
        onclick: () => reanalisar(ancora, m.palavras, k, decidirCom) }, `melhorado ${v}`))));
  }
  if (m.tipo !== "reanalise") {
    const tipos = el("select", { onchange: (e) => { fecharMenu(); alterar({ tipo: "tipo_marcacao", marcacao: m.id, depois: e.target.value }); } },
      ...Object.entries(ROTULOS).filter(([k]) => k !== "reanalise").map(([k, v]) => el("option", { value: k, selected: k === m.tipo }, v)));
    filhos.push(el("div", { class: "linha-digitar" }, el("span", { class: "dica" }, "Trocar por:"), tipos));
  }
  if (m.origem === "usuario" || !SUBSTITUI[m.tipo])
    filhos.push(el("button", { onclick: () => { fecharMenu(); alterar({ tipo: "remover_marcacao", marcacao: m.id }); } },
      "Remover marcação"));
  abrirPainel(ancora, filhos);
}

function painelInsercao(ev, x) {
  ev.stopPropagation();
  const ancora = ev.currentTarget;
  const decidir = (modo, texto) => {
    fecharMenu();
    alterar({ tipo: "decidir_insercao", insercao: x.id, modo, texto });
  };
  abrirPainel(ancora, [
    el("div", { class: "dica" }, x.origem === "ia" ? `A segunda escuta ouviu “${x.texto}” aqui (${tempo(x.inicio, true)})`
      : `Inserido por você (${tempo(x.inicio, true)})`),
    el("button", { onclick: () => ouvirTrecho(x.inicio - 0.5, x.inicio + 1) }, "▶ Ouvir em repetição"),
    el("button", { onclick: () => perguntarComoInserir(ancora, x.texto, decidir, "Recusar (não inserir)") }, `Aceitar “${x.texto}”…`),
    el("button", { onclick: () => perguntarComoInserir(ancora, "", decidir, "Recusar (não inserir)") }, "Digitar outra palavra…"),
    el("button", { onclick: () => decidir("marcacao", "") }, "Recusar (não inserir)"),
  ]);
}

// ---------- ajuda por trecho (item 11) ----------
function idsSelecionados() {
  if (selecao) {
    const ids = [];
    for (let i = selecao[0]; i <= selecao[1]; i++) ids.push(i);
    return ids;
  }
  return ancora !== null ? [ancora] : [];
}

async function reanalisar(ancoraEl, ids, nivel, aoEscolher) {
  abrirPainel(ancoraEl, [el("div", { class: "dica" },
    `Reanalisando${nivel ? ` com áudio melhorado (${NIVEIS[nivel]})` : ""}… pode levar até um minuto.`)]);
  try {
    const r = await api(`/${encodeURIComponent(projetoId)}/trecho`, { acao: "reanalisar", palavras: ids, nivel });
    const filhos = [el("div", { class: "dica" }, `${tempo(r.inicio, true)}–${tempo(r.fim, true)} · atual: “${r.atual}”`),
      el("button", { onclick: () => ouvirTrecho(r.inicio, r.fim) }, "▶ Ouvir em repetição")];
    if (!r.sugestoes.length) filhos.push(el("div", { class: "dica" }, "Os motores não ouviram nada no trecho."));
    else filhos.push(el("div", { class: "dica" }, "Resultados (não estão no documento):"));
    for (const sug of r.sugestoes)
      filhos.push(el("button", { class: "sugestao", onclick: () => aoEscolher(sug.texto, r.sugestoes) },
        `“${sug.texto}”`, el("small", {}, ` ${sug.origem}`)));
    abrirPainel(ancoraEl, filhos);
  } catch (e) {
    abrirPainel(ancoraEl, [el("div", { class: "dica" }, `Não foi possível reanalisar: ${e.message}`)]);
  }
}

function menuTrecho(ev) {
  ev.stopPropagation();
  const botao = ev.currentTarget;  // depois do clique, ev.currentTarget vira null
  const ids = idsSelecionados();
  if (!ids.length) {
    abrirPainel(botao, [el("div", { class: "dica" }, "Selecione um trecho (clique e Shift+clique) e depois em Trecho.")]);
    return;
  }
  const ps = dados.palavras, ini = ps[ids[0]].inicio, fim = ps[ids[ids.length - 1]].fim;
  const aceitar = (texto, sugestoes) => perguntarComoInserir(botao, texto, (modo, t) => {
    fecharMenu();
    alterar({ tipo: "aceitar_reanalise", palavras: ids, modo, texto: t, sugestoes }).then(limparSelecao);
  }, "Cancelar (manter como está)");
  abrirPainel(botao, [
    el("div", { class: "dica" }, `Trecho ${tempo(ini, true)}–${tempo(fim, true)} (${ids.length} palavras)`),
    el("button", { onclick: async () => {
      try {
        const r = await api(`/${encodeURIComponent(projetoId)}/trecho`, { acao: "limpa", palavras: ids });
        abrirPainel(botao, [el("div", { class: "dica" }, "Versão limpa: só para leitura, não vai ao documento"),
          el("div", { class: "comparar" }, el("b", {}, "Literal"), el("p", {}, r.literal),
            el("b", {}, "Limpa"), el("p", {}, r.limpa || "(vazio)"))]);
      } catch (e) { estado(e.message, true); }
    } }, "Ver versão limpa"),
    el("button", { onclick: () => reanalisar(botao, ids, null, aceitar) }, "Reanalisar (mais tentativas)"),
    ...Object.entries(NIVEIS).map(([k, v]) => el("button", { onclick: () => reanalisar(botao, ids, k, aceitar) },
      `Reanalisar com áudio melhorado (${v})`)),
    el("button", { onclick: () => { fecharMenu(); definirVelocidade(0.75); ouvirTrecho(ini, fim); } },
      "Ouvir isolado (repetição a 0,75x)"),
  ]);
}

// Marcar à mão: com seleção, a marcação substitui o trecho; sem seleção, entra antes da palavra clicada.
function menuMarcar(ev) {
  ev.stopPropagation();
  const botao = ev.currentTarget;  // depois do clique, ev.currentTarget vira null
  const ids = [];
  if (selecao) for (let i = selecao[0]; i <= selecao[1]; i++) ids.push(i);
  const antes = ancora;
  if (!ids.length && antes === null) {
    abrirPainel(botao, [el("div", { class: "dica" },
      "Clique numa palavra (ou selecione um trecho com Shift+clique) e depois em Marcar.")]);
    return;
  }
  const alvo = ids.length ? `Trecho selecionado (${ids.length} palavras)` : `Antes de “${dados.palavras[antes].texto}”`;
  const criar = (tipo) => {
    fecharMenu();
    alterar(ids.length ? { tipo: "criar_marcacao", marcacao: tipo, palavras: ids } : { tipo: "criar_marcacao", marcacao: tipo, antes_de: antes })
      .then(limparSelecao);
  };
  const filhos = [el("div", { class: "dica" }, alvo),
    ...Object.entries(ROTULOS).filter(([k]) => k !== "reanalise").map(([k, v]) => el("button", { onclick: () => criar(k) }, `[${v}]`))];
  if (!ids.length) {
    const inserir = (modo, texto) => {
      fecharMenu();
      alterar({ tipo: "inserir_texto", antes_de: antes, modo, texto });
    };
    filhos.push(el("button", { onclick: () => perguntarComoInserir(botao, "", inserir, "Cancelar") },
      "Inserir texto aqui…"));
  }
  abrirPainel(botao, filhos);
}

// ---------- seleção, edição e interlocutor ----------
function aplicarSelecao() {
  document.querySelectorAll(".p.sel").forEach((s) => s.classList.remove("sel"));
  if (!selecao) return;
  for (let i = selecao[0]; i <= selecao[1]; i++) spans[i] && spans[i].classList.add("sel");
}

function limparSelecao() {
  selecao = null;
  ancora = null;
  aplicarSelecao();
}

$("texto").addEventListener("click", (ev) => {
  const s = ev.target.closest(".p");
  if (!s || s.querySelector("input")) return;
  const i = Number(s.dataset.i);
  if (ev.shiftKey && ancora !== null) {
    selecao = [Math.min(ancora, i), Math.max(ancora, i)];
    window.getSelection().removeAllRanges();
  } else {
    ancora = i;
    selecao = null;
    irPara(dados.palavras[i].inicio);
  }
  aplicarSelecao();
});

$("texto").addEventListener("dblclick", (ev) => {
  const s = ev.target.closest(".p");
  if (s && !s.querySelector("input")) editarPalavra(Number(s.dataset.i));
});

function editarPalavra(i) {
  const p = dados.palavras[i], s = spans[i];
  const original = s.textContent;
  const campo = el("input", { class: "editor", value: p.texto, size: Math.max(4, p.texto.length + 2) });
  let feito = false;
  const fechar = (salvar) => {
    if (feito) return;
    feito = true;
    const novo = campo.value.trim();
    s.textContent = original;
    if (salvar && novo !== p.texto) alterar({ tipo: "editar_palavra", palavra: i, depois: novo });
  };
  campo.addEventListener("keydown", (ev) => {
    ev.stopPropagation();
    if (ev.key === "Enter") fechar(true);
    if (ev.key === "Escape") fechar(false);
  });
  campo.addEventListener("input", () => { campo.size = Math.max(4, campo.value.length + 2); });
  campo.addEventListener("blur", () => fechar(false));
  s.replaceChildren(campo);
  campo.focus();
  campo.select();
}

function menuInterlocutor(ev, nf) {
  ev.stopPropagation();
  const fala = dados.falas[nf];
  const daFala = fala.itens.filter((x) => "palavra" in x).map((x) => x.palavra);
  let alvo = daFala, dica = `Fala inteira (${daFala.length} palavras)`;
  if (selecao) {
    const sel = [];
    for (let i = selecao[0]; i <= selecao[1]; i++) sel.push(i);
    alvo = sel;
    dica = `Trecho selecionado (${sel.length} palavras)`;
  }
  const menu = $("menu");
  const opcoes = Object.entries(dados.interlocutores).map(([f, nome]) =>
    el("button", { role: "menuitem", disabled: !selecao && f === fala.falante,
      onclick: () => { fecharMenu(); alterar({ tipo: "atribuir_falante", palavras: alvo, depois: f }).then(limparSelecao); } },
      nome));
  opcoes.push(el("button", { role: "menuitem",
    onclick: () => { fecharMenu(); alterar({ tipo: "atribuir_falante", palavras: alvo, depois: "novo" }).then(limparSelecao); } },
    "+ Novo interlocutor"));
  menu.replaceChildren(el("div", { class: "dica" }, `Atribuir a: ${dica}`), ...opcoes);
  const r = ev.currentTarget.getBoundingClientRect();
  menu.style.left = `${r.left + window.scrollX}px`;
  menu.style.top = `${r.bottom + window.scrollY + 4}px`;
  menu.hidden = false;
}

function fecharMenu() { $("menu").hidden = true; }
// composedPath: o painel pode ter trocado de conteúdo durante o próprio clique
document.addEventListener("click", (ev) => { if (!ev.composedPath().includes($("menu"))) fecharMenu(); });

async function alterar(corpo) {
  estado("Salvando…");
  try {
    const j = await api(`/${encodeURIComponent(projetoId)}/alteracao`, corpo);
    receber(j);
    return j;
  } catch (e) {
    estado(`Não salvo: ${e.message}`, true);
    throw e;
  }
}

async function desfazer() {
  estado("Desfazendo…");
  try {
    receber(await api(`/${encodeURIComponent(projetoId)}/desfazer`, {}));
  } catch (e) {
    estado(e.message, true);
  }
}

function receber(j) {
  for (const k of ["palavras", "falas", "interlocutores", "marcacoes", "insercoes"]) dados[k] = j[k];
  desenharTudo();
  carregarHistorico();
  estado(`Salvo às ${new Date().toLocaleTimeString("pt-BR")}`);
}

// ---------- histórico (item 14) ----------
function descrever(l) {
  const d = l.detalhes;
  const ir = (i) => el("button", { class: "link", onclick: () => { irPara(dados.palavras[i].inicio); } },
    tempo(dados.palavras[i] ? dados.palavras[i].inicio : 0));
  if (l.acao === "editar_palavra")
    return [ir(d.palavra), ` "${d.antes}" → `, d.depois === "" ? "(apagada)" : `"${d.depois}"`];
  if (l.acao === "atribuir_falante")
    return [ir(d.palavras[0]), ` ${d.palavras.length} palavra(s) → ${nomeDe(d.depois)}`];
  if (l.acao === "renomear_interlocutor") return [`Renomeado: "${d.antes}" → "${d.depois}"`];
  if (l.acao === "juntar_interlocutores")
    return [`"${d.nome}" juntado com ${nomeDe(d.para)} (${Object.keys(d.antes).length} palavras` +
      (d.marcacoes_removidas.length ? `; ${d.marcacoes_removidas.length} sobreposição(ões) removida(s)` : "") + ")"];
  if (l.acao === "desfazer") return [`Desfeita a alteração nº ${d.desfaz}`];
  if (l.acao === "exportacao") return [`Exportado: ${d.arquivos.map((a) => a.formato.toUpperCase()).join(", ")}`];
  const obj = d.depois || d.antes;
  const ir2 = () => el("button", { class: "link", onclick: () => irPara(obj.inicio) }, tempo(obj.inicio));
  const como = (dec) => !dec ? "" : dec.modo === "marcacao" ? "manter a marcação" :
    dec.modo === "sem_palavra" ? "não há palavra aqui" :
    dec.modo === "duvida" ? `"${dec.texto} (?)"` : `"${dec.texto}"`;
  if (l.acao === "decidir_marcacao") return [ir2(), ` [${ROTULOS[obj.tipo]}] → ${como(d.depois.decisao)}`];
  if (l.acao === "tipo_marcacao") return [ir2(), ` [${ROTULOS[d.antes.tipo]}] → [${ROTULOS[d.depois.tipo]}]`];
  if (l.acao === "criar_marcacao") return [ir2(), ` marcado [${ROTULOS[obj.tipo]}]`];
  if (l.acao === "remover_marcacao") return [ir2(), ` removida [${ROTULOS[obj.tipo]}]`];
  if (l.acao === "decidir_insercao") return [ir2(), ` sugestão "${obj.texto}" → ${d.depois.decisao.modo === "marcacao" ? "recusada" : como(d.depois.decisao)}`];
  if (l.acao === "inserir_texto") return [ir2(), ` inserido ${como(obj.decisao)}`];
  if (l.acao === "aceitar_reanalise") return [ir2(), ` reanálise: "${obj.sugestoes[0].texto}" → ${como(obj.decisao)}`];
  return [l.acao];
}

async function carregarHistorico() {
  const { alteracoes } = await api(`/${encodeURIComponent(projetoId)}/historico`);
  $("desfazer").disabled = !alteracoes.some((l) => !["desfazer", "exportacao"].includes(l.acao) && !l.desfeita);
  const itens = alteracoes.slice().reverse().map((l) => el("li", {
    class: l.desfeita ? "desfeita" : "", value: l.id },
    el("span", { class: "quando" }, new Date(l.quando).toLocaleString("pt-BR") + " "), ...descrever(l)));
  if (!itens.length) itens.push(el("li", { class: "quando" }, "Nenhuma alteração ainda: o texto é o da transcrição automática."));
  $("historico").replaceChildren(...itens);
}

// ---------- reprodução (item 7) ----------
function irPara(s) {
  audio.currentTime = Math.max(0, Math.min(s, audio.duration || s));
  marcarAtual();
  salvarPosicao();
}

function definirVelocidade(v) {
  audio.preservesPitch = true;  // velocidade reduzida sem mudar o tom da voz
  audio.playbackRate = v;
  document.querySelectorAll("[data-vel]").forEach((b) => b.classList.toggle("ativo", Number(b.dataset.vel) === v));
}

function alternarLoop() {
  if (loop) {
    loop = null;
  } else if (selecao) {
    loop = { inicio: dados.palavras[selecao[0]].inicio, fim: dados.palavras[selecao[1]].fim };
  } else {
    const t = audio.currentTime;
    const fala = dados.falas.find((f) => f.inicio <= t && t <= f.fim + 0.5) ||
      dados.falas.find((f) => f.inicio >= t);
    if (fala) loop = { inicio: fala.inicio, fim: fala.fim };
  }
  $("loop").classList.toggle("ativo", !!loop);
  $("loop").textContent = loop ? `⟲ ${tempo(loop.inicio)}–${tempo(loop.fim)}` : "⟲ Repetir";
  if (loop) { audio.currentTime = loop.inicio; audio.play(); }
}

function tocarPausar() { audio.paused ? audio.play() : audio.pause(); }

function indicePalavra(t) {
  const ps = dados.palavras;
  let lo = 0, hi = ps.length - 1, r = -1;
  while (lo <= hi) {
    const m = (lo + hi) >> 1;
    if (ps[m].inicio <= t) { r = m; lo = m + 1; } else hi = m - 1;
  }
  return r >= 0 && t <= ps[r].fim + 0.3 ? r : -1;
}

function marcarAtual() {
  const t = audio.currentTime;
  $("tempo").textContent = tempo(t, true);
  if (document.activeElement !== $("barra")) $("barra").value = t;
  const i = dados ? indicePalavra(t) : -1;
  if (i === atual) return;
  if (atual >= 0 && spans[atual]) spans[atual].classList.remove("atual");
  atual = i;
  if (i < 0 || !spans[i]) return;
  spans[i].classList.add("atual");
  if ($("acompanhar").checked && !audio.paused && Date.now() - rolagemManual > 3000) {
    const r = spans[i].getBoundingClientRect();
    const topo = $("revisao").querySelector(".player").getBoundingClientRect().bottom;
    if (r.top < topo + 20 || r.bottom > window.innerHeight - 40)
      spans[i].scrollIntoView({ block: "center", behavior: "smooth" });
  }
}

function quadro() {
  if (loop && audio.currentTime >= loop.fim) audio.currentTime = loop.inicio;
  marcarAtual();
  if (!audio.paused) requestAnimationFrame(quadro);
}

let ultimoSalvo = 0;
function salvarPosicao(forcar = true) {
  if (!projetoId) return;
  const agora = Date.now();
  if (!forcar && agora - ultimoSalvo < 5000) return;
  ultimoSalvo = agora;
  api(`/${encodeURIComponent(projetoId)}/posicao`, { segundos: audio.currentTime }).catch(() => {});
}

audio.addEventListener("play", () => { $("tocar").classList.add("tocando"); requestAnimationFrame(quadro); });
audio.addEventListener("pause", () => { $("tocar").classList.remove("tocando"); salvarPosicao(); });
audio.addEventListener("timeupdate", () => { marcarAtual(); salvarPosicao(false); });
audio.addEventListener("error", () => estado("Não foi possível carregar o áudio.", true));
$("tocar").addEventListener("click", tocarPausar);
$("voltar").addEventListener("click", () => irPara(audio.currentTime - SALTO_S));
$("avancar").addEventListener("click", () => irPara(audio.currentTime + SALTO_S));
$("barra").addEventListener("input", (ev) => irPara(Number(ev.target.value)));
$("loop").addEventListener("click", alternarLoop);
$("desfazer").addEventListener("click", desfazer);
$("marcar").addEventListener("click", menuMarcar);
$("trecho").addEventListener("click", menuTrecho);
$("proxima").addEventListener("click", (ev) => { ev.stopPropagation(); proximaPendencia(1); });
$("anterior").addEventListener("click", (ev) => { ev.stopPropagation(); proximaPendencia(-1); });
document.querySelectorAll("[data-vel]").forEach((b) =>
  b.addEventListener("click", () => definirVelocidade(Number(b.dataset.vel))));
window.addEventListener("wheel", () => { rolagemManual = Date.now(); }, { passive: true });
window.addEventListener("touchmove", () => { rolagemManual = Date.now(); }, { passive: true });

// ---------- atalhos de teclado ----------
const VELOCIDADES = { "1": 0.5, "2": 0.75, "3": 1 };
document.addEventListener("keydown", (ev) => {
  if ($("revisao").hidden) return;
  if (document.querySelector("dialog[open]")) return;  // com um popup aberto, as teclas são dele (Esc, Enter)
  const editando = ev.target.matches("input:not([type=range]):not([type=checkbox]), textarea");
  if (editando) return;
  const k = ev.key;
  let feito = true;
  if (k === "Escape") {
    if (!$("menu").hidden) fecharMenu(); else tocarPausar();
  } else if (ev.ctrlKey && k === "ArrowLeft") irPara(audio.currentTime - SALTO_S);
  else if (ev.ctrlKey && k === "ArrowRight") irPara(audio.currentTime + SALTO_S);
  else if ((ev.altKey || ev.ctrlKey) && VELOCIDADES[k]) definirVelocidade(VELOCIDADES[k]);
  else if ((ev.altKey || ev.ctrlKey) && k.toLowerCase() === "l") alternarLoop();
  else if (ev.altKey && k.toLowerCase() === "m") $("marcar").click();
  else if (ev.altKey && k.toLowerCase() === "t") $("trecho").click();
  else if (ev.altKey && k.toLowerCase() === "n") proximaPendencia(ev.shiftKey ? -1 : 1);
  else if (ev.ctrlKey && !ev.shiftKey && k.toLowerCase() === "z") desfazer();
  else feito = false;
  if (feito) ev.preventDefault();
});

// ---------- exportação (itens 8 e 9) ----------
const NOMES_FORMATOS = { docx: "Word (DOCX)", pdf: "PDF", srt: "Legenda (SRT)", txt: "Texto (TXT)", xlsx: "Excel (XLSX)" };
let campos = null;

function linhaCampo(lista, c, tbody) {
  const tr = el("tr", { class: c.incluir ? "" : "desligado" });
  const marca = el("input", { type: "checkbox", checked: c.incluir, title: "Incluir no documento",
    onchange: () => { c.incluir = marca.checked; tr.classList.toggle("desligado", !c.incluir); } });
  const rotulo = el("input", { type: "text", value: c.rotulo, readOnly: !!c.protegido,
    oninput: () => { c.rotulo = rotulo.value; } });
  const valor = el("textarea", { value: c.valor, readOnly: !!c.protegido || c.id === "gerado_em" || c.id === "pagina",
    rows: Math.min(4, Math.ceil(c.valor.length / 70) || 1), oninput: () => { c.valor = valor.value; } });
  const extra = c.protegido ? el("span", { class: "trava", title: "O hash não pode ser alterado" }, "🔒")
    : c.id.startsWith("extra") ? el("button", { type: "button", class: "remover", title: "Remover campo",
      onclick: () => { lista.splice(lista.indexOf(c), 1); tr.remove(); } }, "✕") : "";
  tr.append(el("td", {}, marca), el("td", { class: "rotulo" }, rotulo), el("td", {}, valor), el("td", {}, extra));
  tbody.append(tr);
}

function desenharCampos() {
  for (const [parte, id] of [["cabecalho", "exp-cabecalho"], ["rodape", "exp-rodape"]]) {
    const tbody = $(id);
    tbody.replaceChildren();
    for (const c of campos[parte]) linhaCampo(campos[parte], c, tbody);
  }
}

function acrescentarCampo(parte) {
  const n = 1 + campos[parte].filter((c) => c.id.startsWith("extra")).length;
  const c = { id: `extra${Date.now()}${n}`, rotulo: "Novo campo", valor: "", incluir: true };
  campos[parte].push(c);
  linhaCampo(campos[parte], c, $(parte === "cabecalho" ? "exp-cabecalho" : "exp-rodape"));
}

function listaArquivos(arquivos) {
  return el("ul", {}, ...arquivos.map((a) => el("li", {},
    el("a", { href: `/api/projetos/${encodeURIComponent(projetoId)}/exportacoes/${encodeURIComponent(a.nome)}` }, a.nome),
    el("br"), el("code", {}, `SHA-256 ${a.sha256}`))));
}

async function abrirExportacao() {
  const j = await api(`/${encodeURIComponent(projetoId)}/exportacao`);
  campos = j.campos;
  $("exp-formatos").replaceChildren(...j.formatos.map((f) => el("label", {},
    el("input", { type: "checkbox", value: f, checked: f === "docx" || f === "pdf" }), ` ${NOMES_FORMATOS[f]}`)));
  $("exp-pendentes").hidden = !j.pendentes;
  $("exp-pendentes").textContent = `${j.pendentes} marcação(ões) ainda sem decisão. Elas irão ao documento como ` +
    "marcação ([ininteligível …]), como manda a regra. Você pode exportar assim ou decidir antes.";
  $("exp-resultado").hidden = true;
  $("exp-anteriores-caixa").hidden = !j.anteriores.length;
  $("exp-anteriores").replaceChildren(...j.anteriores.map((x) => el("li", {},
    new Date(x.quando).toLocaleString("pt-BR"), listaArquivos(x.arquivos))));
  desenharCampos();
  $("exportar").showModal();
}

async function gerarExportacao() {
  const formatos = [...document.querySelectorAll("#exp-formatos input:checked")].map((x) => x.value);
  const botao = $("exp-gerar");
  botao.disabled = true;
  botao.textContent = "Gerando…";
  try {
    const j = await api(`/${encodeURIComponent(projetoId)}/exportar`, { formatos, campos });
    const caixa = $("exp-resultado");
    caixa.replaceChildren(el("b", {}, "Arquivos gerados"),
      el("p", { class: "nota pequena" }, "Salvos na pasta exportacoes do projeto; clique para baixar. " +
        "O hash de cada arquivo ficou registrado no histórico."), listaArquivos(j.arquivos));
    caixa.hidden = false;
    caixa.scrollIntoView({ block: "nearest" });
    carregarHistorico();
  } catch (e) {
    avisar("Não foi possível exportar", e.message);
  } finally {
    botao.disabled = false;
    botao.textContent = "Gerar arquivos";
  }
}

// Destaque "motores discordam" (item 16): liga/desliga, lembrado neste navegador
function verDiscordancia(ligado) {
  document.body.classList.toggle("ver-discorda", ligado);
  $("ver-discorda").checked = ligado;
  try { localStorage.setItem("degravaia.discorda", ligado ? "1" : "0"); } catch (e) { /* sem armazenamento */ }
}
let discordaSalvo = "1";
try { discordaSalvo = localStorage.getItem("degravaia.discorda") ?? "1"; } catch (e) { /* sem armazenamento */ }
verDiscordancia(discordaSalvo === "1");
$("ver-discorda").addEventListener("change", (ev) => verDiscordancia(ev.target.checked));

// Original ou cópia melhorada (item 6): troca a fonte mantendo a posição e o estado
$("versao-audio").addEventListener("change", (ev) => {
  const t = audio.currentTime, tocando = !audio.paused, vel = audio.playbackRate;
  audio.src = `/api/projetos/${encodeURIComponent(projetoId)}/audio` + (ev.target.value === "melhorado" ? "?versao=melhorado" : "");
  audio.addEventListener("loadedmetadata", () => {
    audio.currentTime = t;
    definirVelocidade(vel);
    if (tocando) audio.play();
  }, { once: true });
});

$("botao-exportar").addEventListener("click", abrirExportacao);
$("exp-gerar").addEventListener("click", gerarExportacao);
$("exp-mais-cab").addEventListener("click", () => acrescentarCampo("cabecalho"));
$("exp-mais-rod").addEventListener("click", () => acrescentarCampo("rodape"));

// ---------- tema claro/escuro: abre no escuro até a pessoa escolher; a escolha fica salva ----------
function temaAtual() {
  return document.documentElement.dataset.theme === "claro" ? "claro" : "escuro";
}
function mostrarTema() {
  const escuro = temaAtual() === "escuro";
  // o ícone e o rótulo mostram o tema atual
  $("tema").querySelector("use").setAttribute("href", escuro ? "#i-lua" : "#i-sol");
  $("tema").querySelector("span").textContent = escuro ? "Tema escuro" : "Tema claro";
  $("tema").title = escuro ? "Tema escuro (clique para o claro)" : "Tema claro (clique para o escuro)";
}
try {
  const escolhido = localStorage.getItem("degravaia.tema-escolhido");
  if (escolhido === "claro" || escolhido === "escuro") document.documentElement.dataset.theme = escolhido;
} catch (e) { /* sem armazenamento */ }
mostrarTema();
$("tema").addEventListener("click", () => {
  const novo = temaAtual() === "escuro" ? "claro" : "escuro";
  document.documentElement.dataset.theme = novo;
  try { localStorage.setItem("degravaia.tema-escolhido", novo); } catch (e) { /* sem armazenamento */ }
  mostrarTema();
});

// ---------- balões de ajuda "?" ----------
// Abrem ao passar o mouse, ao focar com o teclado ou ao tocar; fecham ao sair, com Esc ou clicando fora.
let balaoDe = null;
function mostrarBalao(botao) {
  const b = $("balao");
  b.textContent = botao.dataset.dica;
  b.hidden = false;
  if (balaoDe && balaoDe !== botao) balaoDe.setAttribute("aria-expanded", "false");
  balaoDe = botao;
  botao.setAttribute("aria-expanded", "true");
  const r = botao.getBoundingClientRect(), largura = b.offsetWidth, altura = b.offsetHeight;
  let esquerda = r.left + r.width / 2 - largura / 2;
  esquerda = Math.max(8, Math.min(esquerda, window.innerWidth - largura - 8));
  let topo = r.bottom + 8;
  if (topo + altura > window.innerHeight - 8) topo = r.top - altura - 8;
  b.style.left = `${esquerda + window.scrollX}px`;
  b.style.top = `${topo + window.scrollY}px`;
}
function esconderBalao() {
  $("balao").hidden = true;
  if (balaoDe) balaoDe.setAttribute("aria-expanded", "false");
  balaoDe = null;
}
for (const botao of document.querySelectorAll(".ajuda[data-dica]")) {
  botao.setAttribute("aria-label", `Ajuda: ${botao.dataset.dica}`);
  botao.setAttribute("aria-expanded", "false");
  botao.addEventListener("mouseenter", () => mostrarBalao(botao));
  botao.addEventListener("mouseleave", () => { if (document.activeElement !== botao) esconderBalao(); });
  botao.addEventListener("focus", () => mostrarBalao(botao));
  botao.addEventListener("blur", esconderBalao);
  botao.addEventListener("click", (ev) => {
    ev.preventDefault();
    ev.stopPropagation();
    balaoDe === botao && !$("balao").hidden ? esconderBalao() : mostrarBalao(botao);
  });
}
document.addEventListener("click", (ev) => { if (!ev.target.closest(".ajuda")) esconderBalao(); });
document.addEventListener("keydown", (ev) => {
  if (ev.key === "Escape" && balaoDe) { esconderBalao(); ev.stopPropagation(); }  // Esc fecha o balão sem pausar o áudio
}, true);
window.addEventListener("scroll", esconderBalao, { passive: true });

// Guia rápido: aberto na primeira vez, depois lembra se foi fechado
try { if (localStorage.getItem("degravaia.guia") === "fechado") $("guia").open = false; } catch (e) { /* sem armazenamento */ }
$("guia").addEventListener("toggle", () => {
  try { localStorage.setItem("degravaia.guia", $("guia").open ? "aberto" : "fechado"); } catch (e) { /* sem armazenamento */ }
});

// ---------- atualização do app (atualizacao.py) ----------
// A tela do projeto avisa o servidor que está aberta: com projeto aberto, a atualização é recusada.
const ABA = Math.random().toString(36).slice(2);
function sinalAba(projeto, aoSair = false) {
  fetch("/api/aba", { method: "POST", headers: { "Content-Type": "application/json" }, keepalive: aoSair,
    body: JSON.stringify({ aba: ABA, projeto }) }).catch(() => {});
}

async function apiAtualizacao(corpo) {
  const r = await chamar("/api/atualizacao", corpo === undefined ? {} : {
    method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(corpo) });
  const j = await r.json();
  if (!r.ok) throw new Error(j.erro || `Erro ${r.status}`);
  return j;
}

// ---------- botão Copiar (detalhes técnicos): o texto inteiro, para mandar ao suporte ----------
async function copiarTexto(texto) {
  try {
    await navigator.clipboard.writeText(texto);
  } catch (e) {  // sem a área de transferência moderna: o jeito antigo
    const campo = el("textarea", { style: "position:fixed;opacity:0" }, texto);
    document.body.append(campo);
    campo.select();
    const ok = document.execCommand("copy");
    campo.remove();
    if (!ok) throw e;
  }
}
document.addEventListener("click", async (ev) => {
  const botao = ev.target.closest("[data-copiar]");
  if (!botao) return;
  const rotulo = botao.querySelector("span");
  try {
    await copiarTexto($(botao.dataset.copiar).textContent);
    rotulo.textContent = "Copiado";
    botao.classList.add("feito");
  } catch (e) {
    rotulo.textContent = "Não foi possível copiar";
  }
  setTimeout(() => { rotulo.textContent = "Copiar"; botao.classList.remove("feito"); }, 2000);
});

// ---------- perguntas e avisos no padrão do app (no lugar de confirm() e alert() do navegador) ----------
// perguntar({titulo, texto: [parágrafos], sim, nao, perigo}) → Promise<true|false>; Esc, X e clique fora = não
function perguntar({ titulo, texto, sim = "Confirmar", nao = "Cancelar", perigo = false }) {
  const d = $("dlg-pergunta");
  $("pergunta-titulo").textContent = titulo;
  $("pergunta-texto").replaceChildren(...[].concat(texto).map((t) => el("p", {}, t)));
  $("pergunta-sim").textContent = sim;
  $("pergunta-sim").classList.toggle("perigo", perigo);
  $("pergunta-nao").textContent = nao;
  $("pergunta-nao").hidden = !nao;
  return new Promise((resolver) => {
    let resposta = false;
    $("pergunta-sim").onclick = () => { resposta = true; d.close(); };
    $("pergunta-nao").onclick = () => d.close();
    d.addEventListener("close", () => resolver(resposta), { once: true });
    d.showModal();
    $(perigo ? "pergunta-nao" : "pergunta-sim").focus();  // numa ação que apaga, o foco fica no "não"
  });
}
const avisar = (titulo, texto) => perguntar({ titulo, texto, sim: "Entendi", nao: "" });

// ---------- popups (<dialog>): fecham no X, no Esc, clicando fora e no botão de fechar ----------
// ao abrir, o foco vai para o próprio popup (o navegador o poria no X, que aparecia contornado)
const abrirPopupNativo = HTMLDialogElement.prototype.showModal;
HTMLDialogElement.prototype.showModal = function () {
  abrirPopupNativo.call(this);
  if (this.classList.contains("janela")) this.focus();
};
document.querySelectorAll("dialog").forEach((d) => {
  d.addEventListener("click", (ev) => {
    if (ev.target !== d) return;  // o clique foi no fundo escurecido, fora da caixa
    if (d.id === "importar" && importando()) return;  // a importação em andamento fica à vista
    d.close();
  });
});
document.addEventListener("click", (ev) => {
  const botao = ev.target.closest(".fechar-dialogo");
  if (botao) botao.closest("dialog").close();
});
$("abrir-privacidade").addEventListener("click", () => $("dlg-privacidade").showModal());

async function procurarAtualizacao(pedida = false) {
  // o resultado em destaque, com ícone: procurando, em dia (verde), versão nova (laranja) ou erro (vermelho)
  const situacao = (tipo, titulo, texto = "") => {
    $("atu-situacao").hidden = false;
    $("atu-situacao").className = `situacao ${tipo}`;
    $("atu-situacao").querySelector("use").setAttribute("href",
      { ok: "#i-check", nova: "#i-baixar", erro: "#i-info", procurando: "#i-recarregar" }[tipo]);
    $("atu-sit-titulo").textContent = titulo;
    $("atu-mensagem").textContent = texto;
  };
  const mostrarNova = (sim) => {
    $("atualizacao").hidden = !sim;
    $("atu-instalar").hidden = $("atu-depois").hidden = !sim;
    $("atu-fechar").hidden = sim;
  };
  if (pedida) {
    mostrarNova(false);
    situacao("procurando", "Procurando versão nova…");
    if (!$("dlg-atualizacao").open) $("dlg-atualizacao").showModal();
  }
  let j;
  try {
    const r = await fetch(`/api/atualizacao${pedida ? "?forcar=1" : ""}`);
    j = await r.json();
  } catch (e) {  // programa fora do ar: só avisa se a pessoa pediu
    if (pedida) situacao("erro", "Não foi possível consultar as atualizações", SEM_PROGRAMA);
    return;
  }
  // a consulta automática não abre nada: só o botão do topo muda para "Nova versão X"
  $("atu-ponto").hidden = !j.nova;
  $("procurar-atualizacao").classList.toggle("tem-nova", !!j.nova);
  $("atu-rotulo").textContent = j.nova ? `Nova versão ${j.nova.versao}` : "Buscar atualização";
  if (!j.nova) {
    if (pedida && j.sem_conexao) situacao("erro", "Não foi possível consultar as atualizações", "Confira a internet e tente de novo.");
    else if (pedida) situacao("ok", "Você já está na versão mais recente", `Versão ${j.versao}.`);
    return;
  }
  situacao("nova", `Nova versão disponível: ${j.nova.versao}`, `Você usa a versão ${j.versao}.`);
  $("atu-novidades").textContent = j.nova.novidades || "";
  $("atu-estado").textContent = j.erro || "";
  if (pedida) mostrarNova(true);
  $("atu-instalar").onclick = () => instalarAtualizacao(j.nova.versao);
  $("atu-depois").onclick = () => $("dlg-atualizacao").close();
}

async function instalarAtualizacao(versao) {
  // sem confirm(): o próprio popup, com "Atualizar agora" e "Agora não", já é a confirmação
  const aviso = $("atu-estado");
  $("atu-instalar").disabled = $("atu-depois").disabled = true;
  aviso.classList.remove("erro");
  aviso.textContent = "Baixando e instalando… não feche o Degrava Lab IA.";
  try {
    await apiAtualizacao({ versao });
    // nada fecha: o servidor sai, o lançador faz o resto e o abre de novo. A página consulta /api/saude
    // a cada 1,5 s e recarrega quando a versão nova responde (no app instalado, o lançador já recarrega
    // a janela; isto cobre a versão de navegador)
    for (;;) {
      await new Promise((ok) => setTimeout(ok, 1500));
      let saude = null;
      try { saude = await (await fetch("/api/saude", { cache: "no-store" })).json(); } catch (e) { /* reabrindo */ }
      if (saude && saude.versao === versao) { location.reload(); return; }
      if (saude) {  // ainda a versão atual: instalando, ou a instalação falhou (nada mudou)
        let j = null;
        try { j = await apiAtualizacao(); } catch (e) { /* reabrindo */ }
        if (j && j.estado === "parado" && j.erro) throw new Error(j.erro);
        aviso.textContent = j && j.estado === "reiniciando" ? "A versão nova está abrindo…"
          : "Baixando e instalando… não feche o Degrava Lab IA.";
      } else {
        aviso.textContent = "A versão nova está abrindo…";
      }
    }
  } catch (e) {
    aviso.textContent = e.message;
    aviso.classList.add("erro");
    $("atu-instalar").disabled = $("atu-depois").disabled = false;
  }
}

$("apoie").addEventListener("click", () => $("dlg-apoio").showModal());
$("copiar-link-apoio").addEventListener("click", async () => {
  const rotulo = $("copiar-link-apoio").querySelector("span");
  try {
    await copiarTexto("https://link.mercadopago.com.br/rladevapps");
    rotulo.textContent = "Copiado!";
  } catch (e) {
    rotulo.textContent = "Não foi possível copiar";
  }
  setTimeout(() => { rotulo.textContent = "Copiar link"; }, 2000);
});
$("procurar-atualizacao").addEventListener("click", () => procurarAtualizacao(true));

// ---------- início ----------
(async () => {
  const m = location.pathname.match(/^\/projeto\/([^/]+)$/);
  try {
    if (m) {
      const id = decodeURIComponent(m[1]);
      sinalAba(id);
      setInterval(() => sinalAba(id), 15000);
      window.addEventListener("pagehide", () => sinalAba(null, true));
      await abrirProjeto(id);
    } else {
      $("procurar-atualizacao").hidden = false;  // atualizar só pela página inicial (sem projeto aberto)
      $("apoie").hidden = false;
      await mostrarLista();
      procurarAtualizacao();
      setInterval(() => procurarAtualizacao(), 15 * 60 * 1000);  // quem deixa o app aberto também vê
    }
  } catch (e) {
    estado(e.message, true);
  }
})();
