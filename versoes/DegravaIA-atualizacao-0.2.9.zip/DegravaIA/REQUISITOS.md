# Degrava IA — Transcrição de áudios

_Requisitos do app de transcrição literal com identificação de interlocutores._

## Escopo
- **Uso:** jurídico/policial, **somente pessoal** (um usuário).
- **Entrada:** arquivos de áudio ou vídeo.
- **Saída:** transcrição **sempre literal**.
- **Regra de construção:** cada ferramenta só entra no app após autorização
  explícita do usuário. Nada além das necessidades.

## Ferramentas autorizadas
1. **Processamento 100% local/offline.** Nenhum arquivo sai da máquina
   (sigilo e cadeia de custódia). Isso exclui qualquer API de nuvem.
2. **Integridade do arquivo original.** Ao importar: hash SHA-256 + data/hora,
   registrados no cabeçalho da transcrição. O original nunca é modificado; o
   app trabalha só com cópias.
3. **Marcações forenses padronizadas.** A IA **nunca inventa palavras** em
   trechos ruins. No lugar delas entra uma marca com o minuto:
   `[inaudível 00:12:31]`, `[ininteligível]`, `[sobreposição de vozes]`,
   `[pausa 4s]`, `[risos]`, `[choro]`.
   - **Sugestão da IA, com decisão do usuário:** se a IA tiver um palpite para
     o trecho, o app mostra a sugestão na tela de revisão, mas **não a insere**
     no texto. Quem decide é o usuário: aceitar a sugestão, digitar outra
     palavra ou manter a marcação.
   - Enquanto o usuário não decidir, o documento fica com a marcação.
   - **A cada aceitação, o app pergunta como inserir**, e o usuário escolhe:
     com indicação de dúvida (`carro (?)`), como texto normal (`carro`),
     texto digitado por ele ou manter a marcação original.
4. **Destaque de baixa confiança.** Cada palavra recebe uma nota de certeza;
   as duvidosas aparecem destacadas **só na tela de revisão**, para o usuário
   ouvir e confirmar. O destaque não vai para o documento final.
5. **Identificação de interlocutores (pyannote, local).** Rótulos genéricos
   "Interlocutor 1, 2, 3…"; o usuário pode informar o número de pessoas,
   renomear cada uma (ex.: "Investigado", "João da Silva") e corrigir com um
   clique um trecho atribuído à pessoa errada.
6. **Melhoria de áudio, opcional e desligada por padrão.** Redução de ruído e
   normalização de volume, locais, ativadas por arquivo. Regras:
   - o áudio melhorado é sempre uma **cópia**; o original fica intacto;
   - o documento registra se houve melhoria e qual (ex.: "Áudio processado
     com redução de ruído, nível médio").
7. **Ferramentas de reprodução para revisão** (nenhuma altera arquivos):
   - clicar no texto leva o áudio ao ponto, e o texto acompanha a reprodução;
   - velocidade reduzida (0,5x / 0,75x) sem distorcer a voz;
   - repetição de trecho (loop);
   - atalhos de teclado (tocar/pausar, voltar 3 s etc.).
8. **Formatos de exportação:** DOCX, PDF, SRT (legenda com interlocutor),
   TXT e Excel (XLSX).
   - Bibliotecas autorizadas (locais): python-docx (DOCX), fpdf2 (PDF) e
     openpyxl (XLSX). SRT e TXT usam só o Python.
   - Cada exportação fica no histórico com o SHA-256 de cada arquivo gerado.
9. **Cabeçalho e rodapé, confirmados antes de gerar.** Padrão proposto:
   nome do arquivo, hash SHA-256, duração, data/hora da transcrição,
   interlocutores, legenda das marcações, melhoria de áudio aplicada e
   programa/modelo usado. **Antes de cada exportação o app mostra todos os
   campos do cabeçalho e do rodapé, e o usuário revisa, altera, remove ou
   acrescenta antes de gerar.**
   - **Hash:** o usuário só pode incluir ou remover, nunca alterar o valor.
   - **Rodapé padrão:** página X de Y; nome do arquivo + hash curto; data de
     geração; campo para responsável (nome/cargo/matrícula + assinatura).
   - **Excel:** mesmos dados dos outros documentos. Cabeçalho numa aba
     separada; na aba principal, uma linha por fala com tempo, interlocutor e
     fala literal.
10. **Tempo no corpo:** no início de cada fala, ex.:
    `[00:03:15] Interlocutor 1: ...`
11. **Ajuda por trecho (substitui o botão "Limpar fala" global).** O usuário
    seleciona um trecho (ou clica num tempo) e escolhe num menu; **não há
    comando por frase digitada** (dispensa modelo de linguagem local).
    Opções:
    - ver versão limpa, ao lado do literal, só para leitura;
    - reanalisar o trecho (modelo maior / mais tentativas);
    - reanalisar com áudio melhorado (cópia, só daquele trecho);
    - ouvir isolado (loop + velocidade reduzida).
    Tudo aparece só na tela; **nada entra no documento sem aceitação do
    usuário**, seguindo a mesma regra das sugestões (item 3).
12. **Interface: página no navegador local.** O programa roda no PC e abre
    no Chrome/Edge. Acessível **somente pelo próprio computador**
    (`127.0.0.1`), sem internet e sem acesso por outros dispositivos da rede.
13. **Projetos com salvamento automático.** Cada arquivo vira um projeto que
    pode ser fechado e reaberto de onde parou.
14. **Histórico de alterações.** Registra cada mudança da revisão (texto da
    IA → texto do usuário, com data/hora), permite desfazer e distingue o
    que foi transcrição automática do que foi revisão humana.
15. **Idioma:** português por padrão; outros idiomas selecionáveis e opção
    de detecção automática.
16. **Motores de transcrição (definidos por teste: ver `teste-motores/RESULTADOS.md`).**
    - **Principal:** Whisper large-v3 (faster-whisper, int8) + prompt de hesitações via
      `hotwords` (vale para o áudio inteiro; ver rodada 3).
      Foi o mais literal entre os testados (erro 23,5%, contra
      29,3% sem o prompt).
    - **Segunda escuta:** wav2vec2-CORAA (`Edresson/wav2vec2-large-xlsr-coraa-portuguese`,
      Apache 2.0). Gera **sugestões** de hesitações/repetições que o Whisper
      pulou (nunca inseridas sozinhas; item 3), e os trechos em que os dois
      motores discordam entram no **destaque de baixa confiança** (item 4).
      Teste: 7 sugestões, 7 corretas.
    - Os dois rodam em sequência para caber nos 4 GB da GTX 1650.
    - **Descartados:** CrisperWhisper (não funciona em português: entra em laço
      e é 30× mais lento), Whisper sem prompt (omite hesitações) e Whisper
      turbo (menos preciso).

## Ambiente
- **Sistema:** Windows.
- **Máquina A:** NVIDIA GeForce GTX 1650 (4 GB VRAM).
- **Máquina B:** sem GPU dedicada (só CPU).
- O app deve **detectar a GPU sozinho** e usar CPU quando não houver, com o
  mesmo resultado nas duas máquinas, mudando só a velocidade.
- 4 GB de VRAM limitam o tamanho do modelo: usar versões quantizadas
  (int8) e testar se o modelo literal escolhido cabe na memória.

## Ferramentas recusadas
- APIs de nuvem (decorre do item 1).
- Comando de ajuda por frase digitada / modelo de linguagem local (item 11).
- Senha/criptografia dos projetos.
- Botão "Limpar fala" global (substituído pela ajuda por trecho, item 11).
- Motores CrisperWhisper, Whisper sem prompt e Whisper turbo (item 16).

> As seções abaixo vieram da conversa exploratória e são **propostas**, não
> decisões. Só valem depois de autorizadas na lista acima.

## ⚠️ REQUISITO CRÍTICO: transcrição literal (verbatim)

**A transcrição deve ser sempre literal.** Hesitações ("é…", "hã", "ahn"), muletas
("tipo", "né", "então", "aí"), repetições e falsos começos devem ser preservados.

### Ressalva técnica (não esquecer)
O Whisper, por padrão, **tende a omitir** hesitações e muletas, entregando um texto
"meio limpo". Isso viola o requisito acima. Para garantir o literal:
- usar um modelo ajustado para transcrição verbatim (ex.: **CrisperWhisper**), e/ou
- orientar o Whisper com um *prompt* inicial contendo hesitações, induzindo-o a transcrevê-las;
- validar com áudios de teste que contenham muitas hesitações antes de escolher o modelo.

### Ordem obrigatória do processamento
1. **Transcrever o mais literal possível.**
2. **Limpar depois, apenas sob comando do usuário.**

Nunca o contrário: transcrever limpo e tentar recuperar o literal **não funciona**.

## ~~Limpeza de fala global~~ (substituída pelo item 11)
- Nunca automática. Acionada pelo botão **"Limpar fala"**.
- A transcrição literal é **sempre guardada** como fonte original; a versão limpa é
  uma visualização derivada, não destrutiva (liga/desliga).
- Opções selecionáveis:
  - remover hesitações
  - remover muletas
  - remover repetições
  - remover falsos começos
  - encurtar silêncios longos (limite ajustável, ex.: > 1,5 s)
- Pré-visualização dos trechos que seriam removidos (riscados/destacados), com
  opção de manter itens individualmente (ex.: "tipo" com sentido real em "esse tipo de contrato").
- Exportação em duas versões: **Literal** e **Limpa**.
- Limpeza do **texto** e corte no **áudio/vídeo** são ações separadas, cada uma com pré-visualização.

## Pipeline base
1. Normalização de áudio (ffmpeg: `highpass`, `loudnorm`)
2. Melhoria de áudio opcional, com níveis leve/médio/forte (DeepFilterNet, Demucs)
   - limpeza agressiva pode piorar a transcrição; permitir usar áudio limpo só na
     diarização e o original na transcrição (ou vice-versa)
3. Transcrição literal com timestamps por palavra (WhisperX / CrisperWhisper)
4. Diarização (pyannote.audio), com opção de informar o número de falantes e amostras de voz
5. Tela de revisão para corrigir falantes e renomeá-los
6. Exportação: SRT, VTT, ASS (cor por falante), TXT, DOCX, PDF, JSON, CSV

## ~~MVP sugerido~~ (substituído pela lista de ferramentas autorizadas)
Transcrição literal + falantes + melhoria de áudio + legenda SRT + botão "Limpar fala"
+ resumo/ata com IA.
