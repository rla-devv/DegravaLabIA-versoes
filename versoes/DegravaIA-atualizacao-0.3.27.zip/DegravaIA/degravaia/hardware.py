"""Detecta GPU NVIDIA; sem ela, tudo roda na CPU com o mesmo resultado."""


def dispositivo():
    try:
        import ctranslate2

        if ctranslate2.get_cuda_device_count() > 0:
            return "cuda"
    except Exception:
        pass
    return "cpu"


def tipo_computacao(disp):
    # GTX 1650 (4 GB): int8 nos pesos para caber na memória
    return "int8_float16" if disp == "cuda" else "int8"


def liberar_gpu():
    try:
        import gc

        import torch

        gc.collect()
        if torch.cuda.is_available():
            torch.cuda.empty_cache()
    except Exception:
        pass


def erro_de_gpu(erro):
    """Falha típica de GPU sem as bibliotecas da NVIDIA (cuBLAS/cuDNN) ou sem memória."""
    texto = str(erro).lower()
    return any(t in texto for t in ("cuda", "cublas", "cudnn", ".dll", "out of memory", "gpu"))


def dispositivo_torch():
    """GPU para o wav2vec2 e o pyannote (biblioteca torch), se houver."""
    try:
        import torch

        return "cuda" if torch.cuda.is_available() else "cpu"
    except Exception:
        return "cpu"


def com_recuo_para_cpu(tarefa, log=print, disp=None):
    """Roda `tarefa(dispositivo)` na GPU, se houver; se a GPU falhar, repete na CPU.

    O resultado é o mesmo nas duas (só muda a velocidade), então o recuo é seguro.
    """
    disp = disp or dispositivo()
    if disp == "cpu":
        return tarefa("cpu")
    try:
        return tarefa(disp)
    except (RuntimeError, OSError, ValueError) as erro:
        if not erro_de_gpu(erro):
            raise
        log(f"  A GPU não pôde ser usada ({str(erro).strip()[:120]}); continuando na CPU, mais devagar.")
        liberar_gpu()
        return tarefa("cpu")