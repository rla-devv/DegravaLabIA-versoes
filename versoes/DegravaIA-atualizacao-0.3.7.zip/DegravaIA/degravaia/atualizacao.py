"""Atualização do próprio app (código), pedida pelo usuário na tela inicial.

Como funciona:
- ao abrir, a tela pergunta ao servidor local se há versão nova; ele baixa só o arquivo
  `atualizacao.json` do repositório público REPO_VERSOES (nenhum dado do usuário é
  enviado: é um download comum, como abrir uma página). O publicar.py põe lá o
  atualizacao.json e o pacote em versoes/;
- o usuário confirma; o pacote de código (poucos MB) é baixado e conferido pelo SHA-256;
- os arquivos atuais que mudam vão para versoes-anteriores/<versão>/ e os novos entram
  no lugar. Nunca são tocadas as pastas python/, modelos/, projetos/ e .venv/;
- se o requirements.txt mudou, as bibliotecas são atualizadas; se algo falhar, tudo volta;
- o servidor reinicia sozinho (degravaia/abrir.py ou degravaia/janela.pyw) e a tela recarrega.

Sem internet, ou enquanto REPO_VERSOES não existir, a consulta falha em silêncio e o app
segue normalmente. Publicar uma versão: PUBLICAR-VERSAO.md.
"""
import hashlib
import json
import re
import shutil
import subprocess
import sys
import zipfile
from pathlib import Path
from urllib.request import Request, urlopen

from .config import NOME_TECNICO, REPO_VERSOES, VERSAO

RAIZ_APP = Path(__file__).resolve().parent.parent
LISTA = "arquivos-do-app.txt"  # arquivos do código, gerada pelo empacotar.py; fica na raiz (as versões
# já instaladas a procuram ali para aceitar a atualização), escondida no Windows
PROTEGIDAS = ("python/", "modelos/", "projetos/", ".venv/", "versoes-anteriores/", ".atualizacao/", ".git/",
              "dados-janela/", "Abrir Degrava IA.lnk", "Abrir o Degrava IA.lnk")  # o atalho da pasta é da instalação, não do pacote
REINICIAR = 3  # código de saída que pede ao lançador (abrir.py, janela.pyw) para abrir o servidor de novo


class AtualizacaoInvalida(Exception):
    pass


def url_manifesto():
    return f"https://raw.githubusercontent.com/{REPO_VERSOES}/main/atualizacao.json"


def url_pacote(versao, arquivo):
    return f"https://raw.githubusercontent.com/{REPO_VERSOES}/main/versoes/{arquivo}"


def numeros(versao):
    return tuple(int(n) for n in re.findall(r"\d+", versao)[:3])


def _baixar(url, timeout):
    pedido = Request(url, headers={"User-Agent": f"{NOME_TECNICO}/{VERSAO}"})
    with urlopen(pedido, timeout=timeout) as r:
        return r.read()


def baixar_conferido(url, destino, sha256, timeout=120):
    """Baixa um arquivo e só o põe no lugar (via .novo) se o SHA-256 conferir com o esperado."""
    dados = _baixar(url, timeout)
    if hashlib.sha256(dados).hexdigest() != sha256:
        raise AtualizacaoInvalida(f"O arquivo baixado não confere com o SHA-256 esperado: {url}")
    destino = Path(destino)
    destino.parent.mkdir(parents=True, exist_ok=True)
    novo = destino.with_name(destino.name + ".novo")
    novo.write_bytes(dados)
    novo.replace(destino)
    return destino


class SemConexao(Exception):
    pass


def verificar(timeout=6, avisar_sem_conexao=False):
    """A versão nova publicada, se houver; None sem internet, sem novidade ou se o
    endereço ainda não existir. Com avisar_sem_conexao, a falha de rede vira SemConexao."""
    if not REPO_VERSOES:
        return None
    try:
        dados = _baixar(url_manifesto(), timeout)
    except Exception as erro:
        if avisar_sem_conexao:
            raise SemConexao(str(erro)) from erro
        return None
    try:
        m = json.loads(dados)
        if not re.fullmatch(r"\d+\.\d+\.\d+", m["versao"]) or not re.fullmatch(r"[0-9a-f]{64}", m["sha256"]) \
                or not re.fullmatch(r"[A-Za-z0-9._-]+\.zip", m["arquivo"]):
            return None
    except Exception:
        return None
    if numeros(m["versao"]) <= numeros(VERSAO):
        return None
    return {"versao": m["versao"], "arquivo": m["arquivo"], "sha256": m["sha256"],
            "tamanho": m.get("tamanho"), "novidades": str(m.get("novidades", ""))[:4000]}


def _caminho_seguro(nome):
    """Caminho relativo dentro da pasta do app, fora das pastas protegidas; None se não for."""
    if not nome.startswith("DegravaIA/") or nome.endswith("/"):
        return None
    rel = nome[len("DegravaIA/"):]
    partes = rel.split("/")
    if not rel or rel.startswith("/") or "\\" in rel or ":" in rel or any(p in ("", ".", "..") for p in partes):
        return None
    if any(rel.startswith(p) for p in PROTEGIDAS):
        return None
    return rel


def ler_pacote(dados_zip):
    """{caminho relativo: conteúdo} do pacote de código, recusando qualquer coisa estranha."""
    import io

    novos = {}
    with zipfile.ZipFile(io.BytesIO(dados_zip)) as z:
        for info in z.infolist():
            if info.is_dir():
                continue
            rel = _caminho_seguro(info.filename)
            if rel is None:
                raise AtualizacaoInvalida(f"Arquivo fora do lugar no pacote: {info.filename}")
            novos[rel] = z.read(info)
    if "degravaia/config.py" not in novos or LISTA not in novos:
        raise AtualizacaoInvalida("O pacote baixado não é uma atualização do Degrava IA.")
    return novos


def _so_cache(pasta):
    """Pasta vazia ou só com cache do Python (__pycache__/*.pyc): pode sair."""
    return all(f.suffix == ".pyc" for f in Path(pasta).rglob("*") if f.is_file())


# pastas que a 0.3.0 tirou da raiz (código foi para degravaia/; desenvolvimento ficou no repositório).
# A atualização que trouxe a 0.3.0 ainda era a antiga: apagou os arquivos e deixou as pastas.
SOBRAS = ("bibliotecas", "ferramentas", "teste-motores", "testes", "__pycache__")


def limpar_sobras(raiz=RAIZ_APP):
    """Ao iniciar: apaga as pastas antigas que ficaram vazias (nunca uma com arquivos de verdade)."""
    for nome in SOBRAS:
        pasta = Path(raiz) / nome
        if pasta.is_dir() and _so_cache(pasta):
            shutil.rmtree(pasta, ignore_errors=True)


def aplicar(novos, raiz=RAIZ_APP, atualizar_bibliotecas=True):
    """Troca os arquivos do código. Guarda os atuais em versoes-anteriores/<versão>/ e
    devolve tudo como estava se algo falhar. Devolve a lista de arquivos alterados."""
    raiz = Path(raiz)
    atual = re.search(r'^VERSAO = "([^"]+)"', (raiz / "degravaia" / "config.py").read_text("utf-8"), re.M)
    copia = raiz / "versoes-anteriores" / (atual.group(1) if atual else VERSAO)
    if copia.exists():
        shutil.rmtree(copia)
    antigos = set((raiz / LISTA).read_text("utf-8").split()) if (raiz / LISTA).is_file() else set()
    sairam = sorted(a for a in antigos - set(novos) if _caminho_seguro("DegravaIA/" + a) and (raiz / a).is_file())
    mudam = [rel for rel, conteudo in sorted(novos.items())
             if not (raiz / rel).is_file() or (raiz / rel).read_bytes() != conteudo]
    criados = [rel for rel in mudam if not (raiz / rel).exists()]
    for rel in [r for r in mudam if r not in criados] + sairam:  # cópia do que vai mudar ou sair
        (copia / rel).parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(raiz / rel, copia / rel)

    def desfazer():
        for rel in criados:
            (raiz / rel).unlink(missing_ok=True)
        if copia.is_dir():
            for f in copia.rglob("*"):
                if f.is_file():
                    destino = raiz / f.relative_to(copia)
                    destino.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(f, destino)

    requisitos_mudaram = "degravaia/requirements.txt" in mudam
    try:
        for rel in mudam:
            destino = raiz / rel
            destino.parent.mkdir(parents=True, exist_ok=True)
            temporario = destino.with_name(destino.name + ".novo")
            temporario.write_bytes(novos[rel])
            temporario.replace(destino)  # troca de uma vez: nunca fica arquivo pela metade
        for rel in sairam:
            (raiz / rel).unlink(missing_ok=True)
            pasta = (raiz / rel).parent
            while pasta != raiz and pasta.is_dir() and _so_cache(pasta):  # pasta que ficou vazia sai junto
                shutil.rmtree(pasta, ignore_errors=True)
                pasta = pasta.parent
        if requisitos_mudaram and atualizar_bibliotecas:
            subprocess.run([sys.executable, "-m", "pip", "install", "--no-warn-script-location",
                            "--find-links", str(raiz / "degravaia" / "bibliotecas"),
                            "-r", str(raiz / "degravaia" / "requirements.txt")],
                           check=True, cwd=raiz)
    except BaseException:
        desfazer()
        raise
    return mudam + sairam


def instalar(nova, raiz=RAIZ_APP):
    """Baixa, confere e aplica a versão `nova` (resultado de verificar())."""
    dados_zip = _baixar(url_pacote(nova["versao"], nova["arquivo"]), timeout=120)
    if hashlib.sha256(dados_zip).hexdigest() != nova["sha256"]:
        raise AtualizacaoInvalida("O arquivo baixado não confere com o SHA-256 publicado. Nada foi alterado.")
    novos = ler_pacote(dados_zip)
    versao_pacote = re.search(r'^VERSAO = "([^"]+)"', novos["degravaia/config.py"].decode("utf-8"), re.M)
    if not versao_pacote or versao_pacote.group(1) != nova["versao"]:
        raise AtualizacaoInvalida("A versão dentro do pacote não é a anunciada. Nada foi alterado.")
    return aplicar(novos, raiz)


def restaurar(raiz=RAIZ_APP):
    """Volta para a versão guardada mais recente (linha de comando: restaurar-versao)."""
    pasta = Path(raiz) / "versoes-anteriores"
    versoes = sorted((p for p in pasta.iterdir() if p.is_dir()), key=lambda p: numeros(p.name)) if pasta.is_dir() else []
    if not versoes:
        print("Não há versão anterior guardada.")
        return 1
    anterior = versoes[-1]
    novos = {f.relative_to(anterior).as_posix(): f.read_bytes() for f in anterior.rglob("*") if f.is_file()}
    for rel, conteudo in novos.items():
        destino = Path(raiz) / rel
        destino.parent.mkdir(parents=True, exist_ok=True)
        destino.write_bytes(conteudo)
    print(f"Arquivos da versão {anterior.name} restaurados ({len(novos)}). Abra o Degrava IA de novo.")
    return 0
