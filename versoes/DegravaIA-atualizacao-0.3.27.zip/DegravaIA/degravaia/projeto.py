"""Projetos: cópia protegida do original, hash, salvamento automático e histórico.

Estrutura de uma pasta de projeto:
    original/<arquivo>     cópia somente-leitura do arquivo importado (item 2)
    trabalho/audio_16k.wav áudio extraído para os motores
    trabalho/audio_revisao.wav  áudio para ouvir na revisão (qualidade original)
    trabalho/audio_revisao_melhorado.wav, audio_melhorado_16k.wav  cópias melhoradas (item 6)
    projeto.json           estado atual (salvo a cada alteração, item 13)
    historico.jsonl        uma linha por alteração, nunca reescrito (item 14)
"""
import hashlib
import json
import os
import re
import shutil
import stat
import unicodedata
from datetime import datetime
from pathlib import Path

from .config import NOME_APP, VERSAO


def agora():
    return datetime.now().astimezone().isoformat(timespec="seconds")


def sha256(caminho, bloco=1024 * 1024):
    h = hashlib.sha256()
    with open(caminho, "rb") as f:
        while parte := f.read(bloco):
            h.update(parte)
    return h.hexdigest()


def _nome_pasta(nome_arquivo):
    base = unicodedata.normalize("NFKD", Path(nome_arquivo).stem).encode("ascii", "ignore").decode()
    base = re.sub(r"[^A-Za-z0-9]+", "-", base).strip("-").lower() or "arquivo"
    return f"{datetime.now():%Y%m%d-%H%M%S}-{base[:40]}"


class Projeto:
    def __init__(self, pasta):
        self.pasta = Path(pasta)
        self.dados = json.loads((self.pasta / "projeto.json").read_text(encoding="utf-8"))

    @classmethod
    def criar(cls, origem, raiz="projetos", idioma="pt", num_falantes=None, procedencia=None, melhoria=None,
              vocabulario=None):
        """`procedencia` substitui o caminho registrado quando o arquivo chega pela tela."""
        origem = Path(origem)
        if not origem.is_file():
            raise FileNotFoundError(f"Arquivo não encontrado: {origem}")
        hash_origem = sha256(origem)

        pasta = Path(raiz) / _nome_pasta(origem.name)
        (pasta / "original").mkdir(parents=True)
        (pasta / "trabalho").mkdir()
        copia = pasta / "original" / origem.name
        shutil.copy2(origem, copia)
        os.chmod(copia, stat.S_IREAD)

        hash_copia = sha256(copia)
        if hash_copia != hash_origem:
            raise RuntimeError("A cópia do arquivo não confere com o original (hash diferente).")

        dados = {
            "app": {"nome": NOME_APP, "versao": VERSAO},
            "original": {
                "nome": origem.name,
                "caminho_importado": procedencia or str(origem.resolve()),
                "copia": str(copia.relative_to(pasta)),
                "tamanho_bytes": copia.stat().st_size,
                "sha256": hash_origem,
                "importado_em": agora(),
            },
            "opcoes": {"idioma": idioma, "num_falantes": num_falantes, "melhoria": melhoria,
                       "vocabulario": vocabulario or []},
            "processamento": {},
            "interlocutores": {},
            "palavras": [],
            "falas": [],
            "segunda_escuta": [],
        }
        (pasta / "projeto.json").write_text(json.dumps(dados, ensure_ascii=False, indent=2), encoding="utf-8")
        projeto = cls(pasta)
        projeto.registrar("importacao", {"arquivo": origem.name, "sha256": hash_origem})
        return projeto

    @property
    def caminho_original(self):
        return self.pasta / self.dados["original"]["copia"]

    @property
    def caminho_audio(self):
        return self.pasta / "trabalho" / "audio_16k.wav"

    @property
    def caminho_audio_revisao(self):
        return self.pasta / "trabalho" / "audio_revisao.wav"

    @property
    def caminho_audio_melhorado(self):
        """Cópia melhorada para ouvir (item 6); só existe se a melhoria foi ligada."""
        return self.pasta / "trabalho" / "audio_revisao_melhorado.wav"

    def verificar_integridade(self):
        """Recalcula o hash da cópia guardada e compara com o registrado na importação."""
        atual = sha256(self.caminho_original)
        return atual == self.dados["original"]["sha256"], atual

    def salvar(self):
        # grava num temporário e troca: um desligamento no meio não corrompe o projeto
        tmp = self.pasta / "projeto.json.tmp"
        tmp.write_text(json.dumps(self.dados, ensure_ascii=False, indent=2), encoding="utf-8")
        os.replace(tmp, self.pasta / "projeto.json")

    def registrar(self, acao, detalhes, origem="sistema", id=None):
        """Acrescenta ao histórico. `origem` distingue 'ia', 'usuario' e 'sistema'."""
        linha = {"quando": agora(), "acao": acao, "origem": origem, "detalhes": detalhes}
        if id is not None:
            linha["id"] = id
        with open(self.pasta / "historico.jsonl", "a", encoding="utf-8") as f:
            f.write(json.dumps(linha, ensure_ascii=False) + "\n")
