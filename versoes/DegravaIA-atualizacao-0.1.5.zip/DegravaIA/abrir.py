"""DegravaIA — abre a tela de revisão no navegador. Dê dois cliques neste arquivo.

Funciona sem internet: liga o modo offline das bibliotecas (item 1 dos requisitos)
e põe no PATH as bibliotecas da NVIDIA para o Whisper usar a GPU. Mantenha esta
janela aberta enquanto usa; para encerrar, feche-a.
"""
import os
import subprocess
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from instalar import AQUI, ambiente_nvidia, python_do_app  # noqa: E402

if __name__ == "__main__":
    os.chdir(AQUI)
    app = python_do_app()
    if not app.exists() or subprocess.run([str(app), "-c", "import faster_whisper"], capture_output=True).returncode:
        print("O DegravaIA ainda não foi instalado. Dê dois cliques em instalar.bat (ou instalar.py) primeiro.")
        input("\nTecle Enter para fechar.")
        sys.exit(1)
    comando = sys.argv[1:] or ["revisar"]
    try:
        codigo = subprocess.run([str(app), "-m", "degravaia", *comando], env=ambiente_nvidia()).returncode
        while codigo == 3 and comando == ["revisar"]:  # atualização instalada: abre a versão nova
            codigo = subprocess.run([str(app), "-m", "degravaia", "revisar", "--nao-abrir"],
                                    env=ambiente_nvidia()).returncode
    except KeyboardInterrupt:
        codigo = 0
    if codigo or comando != ["revisar"]:
        input("\nTecle Enter para fechar.")
    sys.exit(codigo)
