# Degrava IA — Transcrição de áudios

Transcrição **literal** de áudios e vídeos para uso jurídico/policial, com
identificação de interlocutores. Roda **100% no seu computador**; nenhum
arquivo sai da máquina.

## Instalação no Windows
Baixe o pacote `DegravaIA.zip` (gerado por `python empacotar.py`) e descompacte
inteiro. Ele já traz o Python portátil oficial do python.org na pasta `python`:
**não precisa ter Python e nada é instalado no Windows**.

1. Dê dois cliques em **`instalar.bat`** (precisa de internet só desta vez). Ele
   instala as bibliotecas (versão para GPU se houver placa NVIDIA) e baixa os
   modelos, tudo dentro da pasta. Não pede conta nem token: o modelo de
   interlocutores já vem no pacote.
2. Para usar: dois cliques no atalho **Degrava IA** da Área de Trabalho (ou do
   Menu Iniciar), criado pelo instalador. Funciona sem internet.
   - O app abre numa **janela própria**, sem barra de endereço e sem a janela
     preta. Ela usa o WebView2, o componente do Edge que já vem no Windows 10 e
     11, pela biblioteca pywebview.
   - Fechar a janela encerra o Degrava IA.
   - O `abrir.bat` faz o mesmo e recria o atalho se ele tiver sido apagado.
   - Para abrir no navegador, como antes, use `abrir.py --navegador`. O app
     também cai para o navegador sozinho se o WebView2 faltar.
   - As mensagens do programa ficam em `registro.txt`.
3. Em caso de dúvida: **`diagnostico.bat`** mostra o que o app encontrou.

Quando houver versão nova, a página inicial avisa e só instala se você clicar em
**Atualizar agora**. Ela não instala com projeto aberto, não toca nos projetos nem
nos modelos e guarda a versão anterior. Para publicar uma versão, veja
`PUBLICAR-VERSAO.md`.

O Degrava IA é gratuito. O botão **Apoie o projeto**, na página inicial, leva à
doação pelo Mercado Pago (https://link.mercadopago.com.br/rladevapps). O link só
abre se você clicar nele, e doar não é necessário para usar nenhuma função.

Depois de instalada, a pasta é portátil: copiada para outro PC (por exemplo,
num pendrive), funciona sem internet e sem instalar nada.

Os `.bat` só chamam o Python da pasta; quem faz a instalação é o `instalar.py`.
Antivírus como o Norton bloqueavam o `.bat` antigo, que instalava programas por
conta própria ("proteção comportamental"). Sem a pasta `python` (cópia do
código-fonte), os `.py` rodam com qualquer Python instalado e usam um 3.10 a
3.14 (o 3.15 ainda não tem as bibliotecas de IA).

Roteiro para testar no seu PC: [`TESTE-NO-WINDOWS.md`](TESTE-NO-WINDOWS.md).

Testes automáticos das regras principais (literalidade, marcações, histórico,
hash, segurança da tela), sem precisar dos modelos:
`python -m unittest discover -s testes -v`

- Requisitos e decisões: [`REQUISITOS.md`](REQUISITOS.md)
- Teste que definiu os motores: [`teste-motores/RESULTADOS.md`](teste-motores/RESULTADOS.md)

## Etapa 1: importar, transcrever e separar interlocutores

```
python -m degravaia importar depoimento.mp4 [--falantes 2] [--idioma pt|auto|es…]
python -m degravaia mostrar projetos/<pasta-do-projeto>
python -m degravaia verificar projetos/<pasta-do-projeto>
```

Ordem do processamento: extrai o áudio → identifica os interlocutores
(pyannote) → transcreve cada turno de fala (Whisper large-v3) → segunda escuta
(wav2vec2). Transcrever por turno evita que o Whisper pule ou repita frases em
áudios longos (`teste-motores/RESULTADOS.md`, rodada 4).

Cada importação cria uma pasta em `projetos/` com a cópia protegida do
original, o hash SHA-256, a transcrição (`projeto.json`) e o histórico
(`historico.jsonl`).

Na primeira execução os modelos são baixados (cerca de 5 GB). O de
interlocutores vem dentro do `DegravaIA.zip`. Fora do pacote, o primeiro
download dele pede um token gratuito do Hugging Face na variável `HF_TOKEN`.

O modelo [pyannote/speaker-diarization-community-1](https://huggingface.co/pyannote/speaker-diarization-community-1),
de pyannote (Hervé Bredin e colaboradores), é redistribuído sem alterações sob a
licença [CC-BY-4.0](https://creativecommons.org/licenses/by/4.0/). Veja
`modelos/LICENCA-pyannote.txt` no pacote.

## Etapa 2: tela de revisão

```
python -m degravaia revisar [--porta 8765]
```

Abre o Chrome/Edge em `http://127.0.0.1:8765/`. A página só responde ao próprio
computador e não carrega nada da internet. Para encerrar, use Ctrl+C na janela
do terminal.

- **Ouvir:** clique numa palavra para levar o áudio ao ponto; o texto
  acompanha a reprodução. Velocidade 0,5x/0,75x sem mudar o tom; repetição da
  seleção ou da fala atual.
- **Corrigir:** duplo clique numa palavra (em branco apaga). Clique no nome do
  interlocutor para trocar a pessoa da fala ou do trecho selecionado
  (Shift+clique), ou criar um novo. Renomeie os interlocutores na lateral.
- **Destaques (só na tela):** baixa certeza, suspeita de trecho inventado,
  revisado por você, apagado por você e vozes sobrepostas.
- **Salvamento e histórico:** cada alteração é salva na hora, com o texto da IA
  e o seu, e a data/hora. O botão Desfazer (Ctrl+Z) reverte a última alteração
  sem apagar o histórico. Ao reabrir, o áudio volta à última posição.

| Atalho | Ação |
|---|---|
| Esc | tocar / pausar |
| Ctrl+← / Ctrl+→ | voltar / avançar 3 s |
| Alt+1 / Alt+2 / Alt+3 | velocidade 0,5x / 0,75x / 1x (Ctrl+1/2/3 o navegador usa para trocar de aba) |
| Alt+L | repetir a seleção ou a fala atual |
| Ctrl+Z | desfazer |

## Etapa 3: marcações forenses e sugestões

Na importação, o app marca automaticamente:

- **`[ininteligível 00:12:31]`** no lugar de palavras suspeitas, ou de certeza
  baixa que a segunda escuta não confirmou, e no lugar de fala que só a segunda
  escuta ouviu. O texto dos motores fica como **sugestão** e não vai ao
  documento (regra calibrada na rodada 5 do teste).
- **`[sobreposição de vozes]`** antes do trecho, mantendo as palavras.
- **"+ eh"**: hesitações e repetições que só a segunda escuta ouviu.

Na revisão, clique na etiqueta para ouvir em repetição e decidir: aceitar uma
sugestão (o app pergunta se entra como `carro (?)`, como `carro` ou como texto
digitado por você) ou manter a marcação. "Próxima pendência" (Alt+N) percorre
o que falta decidir. O botão **Marcar ▾** (Alt+M) põe `[inaudível]`,
`[ininteligível]`, `[risos]`, `[choro]` ou `[sobreposição de vozes]` no trecho
selecionado, ou insere texto antes da palavra clicada. Tudo entra no histórico
e pode ser desfeito.

## Etapa 4: exportação

Na tela de revisão, **Exportar…** abre a escolha de formatos (DOCX, PDF, SRT,
TXT e XLSX) e todos os campos do cabeçalho e do rodapé, para você revisar,
alterar, desmarcar ou acrescentar antes de gerar. O hash do original só pode ser
incluído ou removido. Os nomes e o cargo do responsável ficam lembrados para os
próximos projetos (só neste computador).

Os arquivos ficam em `projetos/<projeto>/exportacoes/` e também podem ser
baixados pela tela. Cada exportação entra no histórico com o SHA-256 de cada
arquivo gerado. Marcações ainda sem decisão vão ao documento como marcação, e o
app avisa quantas são antes de gerar.

Para o PDF, o app usa a fonte Arial do Windows (no Linux, DejaVu ou Liberation).

## Etapa 5: ajuda por trecho, melhoria de áudio e importação pela tela

- **Importar arquivo…** (página inicial): escolha do arquivo, idioma, número de
  pessoas e melhoria de áudio, com acompanhamento do progresso. O arquivo não
  sai do computador.
- **Melhoria de áudio** (opcional, desligada por padrão): cópia com redução de
  ruído e normalização de volume (leve, médio ou forte). Serve para **ouvir** na
  revisão, com a chave "Áudio: original | melhorado"; a transcrição usa o
  original (rodada 6 do teste). O cabeçalho registra a melhoria aplicada.
- **Trecho ▾** (Alt+T), com um trecho selecionado: versão limpa só para leitura,
  reanalisar (mais tentativas), reanalisar com áudio melhorado só daquele trecho
  e ouvir isolado. O resultado é sugestão: só entra no documento se você aceitar.
- **Motores discordam:** destaque discreto, com liga/desliga na legenda, para as
  palavras que a segunda escuta não confirmou.
