@echo off
chcp 65001 >nul
rem Degrava IA - na primeira vez baixa e instala o que falta (precisa de internet so entao); depois, abre o app.
rem Tudo fica nesta pasta: o Python portatil oficial (python.org) vai para "python"; nada e instalado no Windows.
rem Opcoes: "Degrava IA.bat" instalar | diagnostico | --navegador
cd /d "%~dp0"
if exist "python\python.exe" if exist "degravaia\config.py" goto rodar
rem arquivo em UTF-8 sem BOM (por isso o chcp 65001): acentos so nas mensagens, comandos e rotulos sem acento
title Degrava IA - Instalação
if defined DEGRAVAIA_MOVIDO goto sem_cabecalho
echo.
echo  Degrava IA - Transcrição de áudios e vídeos diretamente no seu computador
echo.
echo  A internet é usada só durante a instalação, para baixar o Python e os modelos de IA.
echo  Depois de instalado, o Degrava IA funciona sem internet.
echo.
:sem_cabecalho
rem o instalador do app (degravaia\instalar.py) nao repete este cabecalho
set "DEGRAVAIA_CABECALHO=1"
set "DEGRAVAIA_PASTA=%~dp0"
set "DEGRAVAIA_BAT=%~f0"
powershell -NoProfile -ExecutionPolicy Bypass -Command "$s = [IO.File]::ReadAllText($env:DEGRAVAIA_BAT); iex $s.Substring($s.IndexOf('#' + 'POWERSHELL'))"
if errorlevel 3 goto mudou
if errorlevel 1 goto erro
if not exist "python\python.exe" goto erro
if not exist "degravaia\config.py" goto erro
:rodar
rem num bloco: o cmd le a linha inteira antes de rodar, e uma atualizacao que troque este arquivo nao o atrapalha
("python\python.exe" -m degravaia.abrir %* & exit /b)
:mudou
rem o PowerShell copiou este arquivo para a subpasta "Degrava IA": a instalacao continua de la
set "DEGRAVAIA_MOVIDO=1"
("%~dp0Degrava IA\Degrava IA.bat" %* & exit /b)
:erro
rem a mensagem (com acentos) ja foi mostrada pelo PowerShell
echo.
pause
exit /b 1

#POWERSHELL - daqui para baixo o .bat entrega ao PowerShell (o cmd nunca chega aqui; por isso pode ter acentos:
# o arquivo e UTF-8, e o PowerShell o le assim)
# 1. Python portatil oficial (python.org), conferido pelo SHA-256 abaixo (o do arquivo publicado).
# 2. O codigo do Degrava IA: a versao mais nova publicada, pelo mesmo caminho conferido das atualizacoes
#    (atualizacao.json -> pacote com SHA-256 -> versao escrita dentro do pacote).
# Cada download vai para um arquivo .novo e so entra no lugar depois de conferido.
$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
[Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12
$pasta = $env:DEGRAVAIA_PASTA
$repo = 'https://raw.githubusercontent.com/rla-devv/degravaia-versoes/main/'
$pythonUrl = 'https://www.python.org/ftp/python/3.14.8/python-3.14.8-embed-amd64.zip'
$pythonSha = 'a93abe456ab01bd96d7a085b3cdb6566b3063f4241360d114142fbdb07f0a310'
$cabecalho = @{ 'User-Agent' = 'DegravaIA-instalador' }

function Etapa($texto) { Write-Host " • $texto... " -NoNewline }
function Concluida($texto = 'concluído') { Write-Host $texto -ForegroundColor Green }

function Baixar($url, $destino, $sha) {
    $novo = "$destino.novo"
    Invoke-WebRequest -UseBasicParsing -Uri $url -OutFile $novo -Headers $cabecalho
    if ((Get-FileHash -Algorithm SHA256 -LiteralPath $novo).Hash.ToLower() -ne $sha) {
        Remove-Item -LiteralPath $novo
        throw "o arquivo baixado não confere com o SHA-256 esperado ($url)"
    }
    Move-Item -Force -LiteralPath $novo -Destination $destino
}

# O .bat solto numa pasta com outras coisas (ex.: extraído direto em Downloads): instala numa subpasta
# "Degrava IA", para não espalhar o app entre os arquivos da pessoa. Código 3: o cmd continua de lá.
$doApp = @([IO.Path]::GetFileName($env:DEGRAVAIA_BAT), 'Degrava IA.bat', 'python', 'degravaia', 'modelos', 'projetos',
    'LEIA-ME.txt', 'arquivos-do-app.txt', 'versoes-anteriores', 'dados-janela', 'registro.txt', 'registro.anterior.txt',
    'Abrir Degrava IA.lnk', 'Abrir o Degrava IA.lnk', 'python-portatil.zip', 'python-portatil.zip.novo',
    'degravaia-codigo.zip', 'degravaia-codigo.zip.novo', '.instalacao', 'desktop.ini', 'Thumbs.db')
$outros = @(Get-ChildItem -LiteralPath $pasta -Force | Where-Object { $doApp -notcontains $_.Name })
if ($outros.Count -gt 0 -and -not (Test-Path -LiteralPath (Join-Path $pasta 'degravaia\config.py'))) {
    $nova = Join-Path $pasta 'Degrava IA'
    New-Item -ItemType Directory -Force -Path $nova | Out-Null
    Copy-Item -Force -LiteralPath $env:DEGRAVAIA_BAT -Destination (Join-Path $nova 'Degrava IA.bat')
    Write-Host ' Esta pasta tem outros arquivos: o Degrava IA vai ser instalado na pasta nova'
    Write-Host " $nova"
    Write-Host ' (o "Degrava IA.bat" que ficou fora dela pode ser apagado).'
    Write-Host ''
    exit 3
}

# antes de baixar: a internet funciona?
try {
    Invoke-WebRequest -UseBasicParsing -Method Head -Uri "${repo}atualizacao.json" -Headers $cabecalho -TimeoutSec 20 | Out-Null
} catch {
    Write-Host ' Sem conexão com a internet. A instalação precisa de internet para baixar os componentes do programa' -ForegroundColor Red
    Write-Host ' (só desta vez). Conecte o computador à internet e rode este arquivo de novo.' -ForegroundColor Red
    exit 1
}

try {
    if (-not (Test-Path -LiteralPath (Join-Path $pasta 'python\python.exe'))) {
        Etapa 'Baixando o Python portátil oficial (python.org, 11 MB)'
        $zip = Join-Path $pasta 'python-portatil.zip'
        Baixar $pythonUrl $zip $pythonSha
        Expand-Archive -Force -LiteralPath $zip -DestinationPath (Join-Path $pasta 'python')
        Remove-Item -LiteralPath $zip
        # liga o pip (import site) e deixa o Python enxergar o codigo do Degrava IA (..)
        Get-ChildItem -LiteralPath (Join-Path $pasta 'python') -Filter '*._pth' | ForEach-Object {
            [IO.File]::WriteAllText($_.FullName, "python314.zip`r`n.`r`nLib\site-packages`r`n..`r`nimport site`r`n")
        }
        Concluida
    }
    if (-not (Test-Path -LiteralPath (Join-Path $pasta 'degravaia\config.py'))) {
        Etapa 'Baixando o Degrava IA (versão mais recente)'
        $agora = [DateTimeOffset]::UtcNow.ToUnixTimeSeconds()
        $m = (Invoke-WebRequest -UseBasicParsing -Uri "${repo}atualizacao.json?t=$agora" -Headers $cabecalho).Content | ConvertFrom-Json
        if ($m.versao -notmatch '^\d+\.\d+\.\d+$' -or $m.arquivo -notmatch '^[A-Za-z0-9._-]+\.zip$' -or $m.sha256 -notmatch '^[0-9a-f]{64}$') {
            throw 'o atualizacao.json publicado não está no formato esperado'
        }
        $zip = Join-Path $pasta 'degravaia-codigo.zip'
        Baixar "${repo}versoes/$($m.arquivo)" $zip $m.sha256
        $tmp = Join-Path $pasta '.instalacao'
        if (Test-Path -LiteralPath $tmp) { Remove-Item -Recurse -Force -LiteralPath $tmp }
        Expand-Archive -LiteralPath $zip -DestinationPath $tmp
        $origem = Join-Path $tmp 'DegravaIA'
        $config = [IO.File]::ReadAllText((Join-Path $origem 'degravaia\config.py'))
        if ($config -notmatch ('(?m)^VERSAO = "' + [regex]::Escape($m.versao) + '"')) {
            throw 'a versão dentro do pacote não é a anunciada'
        }
        # arquivo por arquivo (o proprio .bat fica: e este que esta rodando)
        Get-ChildItem -LiteralPath $origem -Recurse -File -Force | ForEach-Object {
            $rel = $_.FullName.Substring($origem.Length).TrimStart('\', '/')
            if ($rel -ne 'Degrava IA.bat') {
                $destino = Join-Path $pasta $rel
                New-Item -ItemType Directory -Force -Path (Split-Path -Parent $destino) | Out-Null
                Copy-Item -Force -LiteralPath $_.FullName -Destination $destino
            }
        }
        Remove-Item -Recurse -Force -LiteralPath $tmp
        Remove-Item -LiteralPath $zip
        Concluida "versão $($m.versao)"
    }
} catch {
    Write-Host 'falhou' -ForegroundColor Red
    Write-Host ''
    Write-Host " Não foi possível baixar: $($_.Exception.Message)" -ForegroundColor Red
    Write-Host ' Confira a conexão com a internet e abra o "Degrava IA.bat" de novo.'
    Write-Host ' Se o problema continuar, envie um print desta janela para o suporte.'
    exit 1
}
