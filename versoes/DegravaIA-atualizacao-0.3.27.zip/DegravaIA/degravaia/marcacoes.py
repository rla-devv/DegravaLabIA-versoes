"""Marcações forenses e sugestões (item 3).

Regra: no trecho marcado, o documento mostra só a marcação. As palavras dos
motores viram sugestões e só entram no texto quando o usuário decide.

Marcação (lista `marcacoes` do projeto):
    {"id", "tipo", "inicio", "fim", "palavras": [ids], "antes_de": id | None,
     "origem": "ia" | "usuario", "sugestoes": [{"origem", "texto"}], "decisao": None | {...}}
  - tipos que SUBSTITUEM as palavras: ininteligivel, inaudivel, risos, choro;
  - tipo que só ANOTA (as palavras continuam): sobreposicao;
  - sem palavras, a marcação fica antes da palavra `antes_de` (None = no fim).
  decisao: {"modo": "duvida" | "normal" | "digitado" | "marcacao" | "sem_palavra", "texto"}.

Inserção (lista `insercoes`): texto antes (`antes_de`) ou depois (`depois_de`) de uma
palavra, vindo da segunda escuta (hesitação/repetição que o Whisper pulou) ou
digitado pelo usuário.
    {"id", "antes_de" | "depois_de", "inicio", "texto", "origem", "decisao": None | {...}}
"""
import difflib
import re

from .config import CONFIANCA_INTELIGIVEL, CONFIANCA_INTELIGIVEL_SEM_SEGUNDA
from .montagem import fora_das_regioes, tempo

TIPOS = {
    "ininteligivel": {"rotulo": "ininteligível", "substitui": True, "tempo": True},
    "inaudivel": {"rotulo": "inaudível", "substitui": True, "tempo": True},
    "sobreposicao": {"rotulo": "sobreposição de vozes", "substitui": False, "tempo": False},
    "risos": {"rotulo": "risos", "substitui": True, "tempo": False},
    "choro": {"rotulo": "choro", "substitui": True, "tempo": False},
    # item 11: resultado de reanálise aceito pelo usuário (sempre com decisão)
    "reanalise": {"rotulo": "trecho reanalisado", "substitui": True, "tempo": True},
}
# sem_palavra: o usuário ouviu e não há palavra ali (ruído, respiração); a marcação sai e nada entra
MODOS = ("duvida", "normal", "digitado", "marcacao", "sem_palavra")

# segunda escuta: só estas palavras viram sugestão de inserção (rodada 2: 7 de 7 corretas)
HESITACOES = {"eh", "ah", "hum", "ahn", "hã", "ãh", "uhum", "hmm", "uh", "éh", "an"}
MULETAS = {"né"}


# Formas que os motores escrevem diferente para o mesmo som (rodada 5)
EQUIVALENTES = {"quê": "que", "pra": "para", "pro": "para", "tava": "estava", "tavam": "estavam", "tá": "está",
                "tô": "estou", "cê": "você", "ocê": "você", "cês": "vocês", "stava": "estava"}


def _norm(texto):
    texto = re.sub(r"[^\wà-ü\s]", " ", texto.lower())
    return texto.split()


def canonico(token):
    """Forma usada só para comparar os dois motores; o texto exibido nunca muda."""
    # variantes de grafia ("eeh", "ahn", "hmm"); "a" e "e" sozinhos são palavras, não hesitação
    if token in HESITACOES or re.fullmatch(r"(e{2,}h*|e+h+|a{2,}h*n*|a+h+n*|ã+h*|h+u+m+|h+m+|u+h+m*)", token):
        return "<hesitação>"
    return EQUIVALENTES.get(token, token)


def colados(a, b):
    """Posições de `a` (Whisper) que o wav2vec2 escreveu grudadas numa palavra só:
    2 ou 3 palavras seguidas, juntas, formam exatamente uma palavra de `b` ("e dez" = "edez")."""
    grudadas, alvo = set(), set(b)
    for n in (2, 3):
        for i in range(len(a) - n + 1):
            if "".join(a[i:i + n]) in alvo:
                grudadas.update(range(i, i + n))
    return grudadas


def rotulo(m):
    t = TIPOS[m["tipo"]]
    return f"[{t['rotulo']} {tempo(m['inicio'])}]" if t["tempo"] else f"[{t['rotulo']}]"


def texto_decidido(m):
    """O que entra no documento no lugar da marcação; None = a própria marcação."""
    d = m.get("decisao")
    if not d or d["modo"] == "marcacao" or not TIPOS[m["tipo"]]["substitui"]:
        return None
    if d["modo"] == "sem_palavra":
        return ""  # decidida, mas nada vai ao documento
    return f"{d['texto']} (?)" if d["modo"] == "duvida" else d["texto"]


def texto_insercao(ins):
    d = ins.get("decisao")
    if not d or d["modo"] == "marcacao":
        return None
    return f"{d['texto']} (?)" if d["modo"] == "duvida" else d["texto"]


# ---------- geração automática (na importação) ----------
def _w2v_entre(w2v, ini, fim):
    return " ".join(p["texto"] for p in w2v if p["fim"] > ini and p["inicio"] < fim).strip()


def _sugestoes(palavras_ids, palavras, w2v, ini, fim):
    s = []
    texto_w = " ".join(palavras[i]["texto"] for i in palavras_ids).strip()
    if texto_w:
        s.append({"origem": "whisper", "texto": texto_w})
    texto_2 = _w2v_entre(w2v, ini, fim)
    if texto_2:
        s.append({"origem": "wav2vec2", "texto": texto_2})
    return s


def _alinhar(palavras, ids, w2v, fala):
    """Alinha as palavras do Whisper de uma fala com o que o wav2vec2 ouviu no mesmo intervalo.

    Devolve os tokens do Whisper (`a`), a palavra de cada token (`dono`), os tokens e
    palavras do wav2vec2 (`b`, `trecho`) e os blocos do alinhamento.
    """
    a, dono = [], []
    for i in ids:
        for t in _norm(palavras[i]["texto"]):
            a.append(t)
            dono.append(i)
    ini, fim = fala["inicio"] - 0.3, fala["fim"] + 0.3
    trecho = [p for p in w2v if p["fim"] > ini and p["inicio"] < fim]  # o que tocar a fala
    b = [_norm(p["texto"])[0] if _norm(p["texto"]) else "" for p in trecho]
    blocos = difflib.SequenceMatcher(a=[canonico(t) for t in a], b=[canonico(t) for t in b],
                                     autojunk=False).get_opcodes()
    return a, dono, b, trecho, blocos


def concordancia(palavras, falas, w2v):
    """Palavras do Whisper que a segunda escuta também ouviu (rodada 5: só 5,4% erradas)."""
    iguais = set()
    for fala in falas:
        ids = [x["palavra"] for x in fala["itens"] if "palavra" in x]
        a, dono, b, _, blocos = _alinhar(palavras, ids, w2v, fala)
        certos = {k for op, i1, i2, _, _ in blocos if op == "equal" for k in range(i1, i2)}
        certos |= colados(a, b)
        for i in ids:
            ks = [k for k in range(len(a)) if dono[k] == i]
            if ks and all(k in certos for k in ks):
                iguais.add(i)
    return iguais


def marcar_discordancia(dados):
    """Item 16: marca as palavras que a segunda escuta não confirmou e guarda o que ela ouviu
    no mesmo instante (só para a tela). Rodada 5: com certeza >= 0,5, erram 34% contra 4%."""
    palavras, w2v = dados["palavras"], dados.get("segunda_escuta") or []
    if not w2v:
        return set()
    iguais = concordancia(palavras, dados["falas"], w2v)
    for i, p in enumerate(palavras):
        p["discorda"] = i not in iguais
        if p["discorda"]:
            p["ouvido_segunda"] = _w2v_entre(w2v, p["inicio"] - 0.1, p["fim"] + 0.1)
        else:
            p.pop("ouvido_segunda", None)
    return iguais


def _inteligiveis(palavras, falas, w2v, iguais):
    """Sequências de palavras suspeitas ou de certeza baixa sem confirmação da segunda escuta."""

    def ruim(i):
        p = palavras[i]
        if p.get("suspeita_alucinacao"):
            return True
        if not w2v:
            return p["prob"] < CONFIANCA_INTELIGIVEL_SEM_SEGUNDA
        return p["prob"] < CONFIANCA_INTELIGIVEL and i not in iguais

    marcas = []
    for fala in falas:
        ids = [x["palavra"] for x in fala["itens"] if "palavra" in x]
        grupo = []
        for i in ids + [None]:
            if i is not None and ruim(i):
                grupo.append(i)
                continue
            if grupo:
                ini, fim = palavras[grupo[0]]["inicio"], palavras[grupo[-1]]["fim"]
                marcas.append({"tipo": "ininteligivel", "inicio": ini, "fim": fim, "palavras": grupo,
                               "antes_de": None, "sugestoes": _sugestoes(grupo, palavras, w2v, ini, fim)})
                grupo = []
    return marcas


def _proxima_palavra(palavras, t):
    for i, p in enumerate(palavras):
        if p["inicio"] >= t:
            return i
    return None


def _fora_dos_turnos(palavras, fora):
    """Fala que só a segunda escuta ouviu (o Whisper não recebeu o trecho)."""
    grupos = []
    for p in sorted(fora, key=lambda x: x["inicio"]):
        if grupos and p["inicio"] - grupos[-1][-1]["fim"] < 1.0:
            grupos[-1].append(p)
        else:
            grupos.append([p])
    return [{"tipo": "ininteligivel", "inicio": g[0]["inicio"], "fim": g[-1]["fim"], "palavras": [],
             "antes_de": _proxima_palavra(palavras, g[0]["inicio"]),
             "sugestoes": [{"origem": "wav2vec2", "texto": " ".join(p["texto"] for p in g)}]} for g in grupos]


def _sobreposicoes(palavras, sobreposicoes):
    marcas = []
    for s in sobreposicoes:
        ids = [i for i, p in enumerate(palavras) if p["fim"] > s["inicio"] and p["inicio"] < s["fim"]]
        if ids:
            marcas.append({"tipo": "sobreposicao", "inicio": s["inicio"], "fim": s["fim"], "palavras": ids,
                           "antes_de": None, "sugestoes": []})
    return marcas


def sugestoes_insercao(palavras, falas, w2v):
    """Hesitações, 'né' e repetições que só o wav2vec2 ouviu (lógica da rodada 2)."""
    saida = []
    for fala in falas:
        ids = [x["palavra"] for x in fala["itens"] if "palavra" in x]
        if not ids:
            continue
        a, dono, b, trecho, blocos = _alinhar(palavras, ids, w2v, fala)
        for op, i1, i2, j1, j2 in blocos:
            if op not in ("insert", "replace"):
                continue
            anterior = a[i1 - 1] if i1 > 0 else None
            for k in range(j1, j2):
                t = b[k]
                if t in HESITACOES or t in MULETAS or (t and t == anterior):
                    lugar = {"antes_de": dono[i1]} if i1 < len(dono) else {"depois_de": ids[-1]}
                    sug = lugar | {"inicio": trecho[k]["inicio"], "texto": t}
                    if not any(x["inicio"] == sug["inicio"] and x["texto"] == t for x in saida):  # borda de duas falas
                        saida.append(sug)
                anterior = t
    return saida


def gerar(dados):
    """Cria as marcações e sugestões automáticas de um projeto já transcrito."""
    palavras, falas = dados["palavras"], dados["falas"]
    w2v = dados.get("segunda_escuta") or []
    proc = dados.get("processamento", {})
    regioes = proc.get("transcricao", {}).get("regioes")
    fora = fora_das_regioes(w2v, regioes) if regioes else []
    sobre = proc.get("interlocutores", {}).get("sobreposicoes", [])

    iguais = marcar_discordancia(dados)
    marcas = _inteligiveis(palavras, falas, w2v, iguais) + _fora_dos_turnos(palavras, fora) + _sobreposicoes(palavras, sobre)
    marcas.sort(key=lambda m: m["inicio"])
    dados["marcacoes"] = [m | {"id": n, "origem": "ia", "decisao": None} for n, m in enumerate(marcas, 1)]
    dados["insercoes"] = [s | {"id": n, "origem": "ia", "decisao": None}
                          for n, s in enumerate(sugestoes_insercao(palavras, falas, w2v), 1)]
    return dados


# ---------- texto do documento ----------
def partes_da_fala(fala, dados, final=False):
    """Sequência do que vai ao documento numa fala: palavras, marcações, inserções e pausas.

    Cada item: {"tipo": "palavra"|"marcacao"|"insercao"|"pausa", "texto", ...}.
    `sugestao=True` indica algo que está na tela mas NÃO vai ao documento.
    """
    palavras = dados["palavras"]
    marcas = dados.get("marcacoes", [])
    cobre, junto = {}, {}
    for m in marcas:
        for i in m["palavras"]:
            cobre.setdefault(i, []).append(m)
        if not m["palavras"]:
            junto.setdefault(("antes", m["antes_de"]), []).append(("marcacao", m))
    for ins in dados.get("insercoes", []):
        chave = ("depois", ins["depois_de"]) if "depois_de" in ins else ("antes", ins.get("antes_de"))
        junto.setdefault(chave, []).append(("insercao", ins))

    saida, abertas = [], set()

    def anexar(chave):
        for tipo, obj in sorted(junto.get(chave, []), key=lambda x: (x[1].get("inicio", 0), x[1]["id"])):
            if tipo == "marcacao":
                txt = texto_decidido(obj)
                saida.append({"tipo": "marcacao", "marcacao": obj, "texto": rotulo(obj) if txt is None else txt,
                              "decidida": txt is not None})
            else:
                txt = texto_insercao(obj)
                saida.append({"tipo": "insercao", "insercao": obj, "texto": txt or obj["texto"],
                              "sugestao": txt is None})

    for item in fala["itens"]:
        if "palavra" not in item:
            saida.append({"tipo": "pausa", "texto": f"[pausa {item['segundos']}s]"})
            continue
        i = item["palavra"]
        anexar(("antes", i))
        oculta = False
        for m in cobre.get(i, []):
            if m["id"] not in abertas:
                abertas.add(m["id"])
                txt = texto_decidido(m)
                saida.append({"tipo": "marcacao", "marcacao": m, "texto": rotulo(m) if txt is None else txt,
                              "decidida": txt is not None})
            oculta = oculta or TIPOS[m["tipo"]]["substitui"]
        saida.append({"tipo": "palavra", "palavra": i, "texto": palavras[i]["texto"], "sugestao": oculta})
        anexar(("depois", i))
    if final:
        anexar(("antes", None))
    return saida


def texto_da_fala(fala, dados, final=False):
    textos = [p["texto"] for p in partes_da_fala(fala, dados, final) if not p.get("sugestao") and p["texto"]]
    return " ".join(textos)
