"""Os três motores: transcrição (Whisper), segunda escuta (wav2vec2) e interlocutores (pyannote).

Cada função carrega o modelo, processa e libera a memória antes do próximo,
para caber nos 4 GB da GTX 1650.
"""
import os

from . import hardware
from .config import (ALUCINACOES_CONHECIDAS, MODELO_DIARIZACAO, MODELO_SEGUNDA_ESCUTA, MODELO_WHISPER,
                     PROMPT_HESITACOES, TAXA_AMOSTRAGEM, VOCABULARIO_MAX_CARACTERES, VOCABULARIO_MAX_TERMOS)


def limpar_vocabulario(texto):
    """Nomes e termos informados na importação: separados por vírgula, ponto e vírgula ou linha."""
    import re

    termos = []
    for t in re.split(r"[,;\n]+", str(texto or "")):
        t = re.sub(r"[\x00-\x1f]", "", t).strip()[:60]
        if t and t.lower() not in (x.lower() for x in termos):
            termos.append(t)
    saida, tamanho = [], 0
    for t in termos[:VOCABULARIO_MAX_TERMOS]:
        if tamanho + len(t) > VOCABULARIO_MAX_CARACTERES:
            break
        saida.append(t)
        tamanho += len(t) + 2
    return saida


def dicas(vocabulario=None):
    """O que vai ao Whisper como `hotwords`: o vocabulário e, por último, o modelo de fala literal.

    Teste de 18/10/2026 (60 s do CORAA, lista de nomes que não aparecem no áudio): nenhum nome
    da lista foi inventado, mas ela tira um pouco do efeito das hesitações. Com a lista depois
    do modelo, 3 de 5 hesitações ficaram; com a lista antes, 4 de 5. Por isso ela vem antes, e
    o campo é opcional (só para quando houver nomes e termos no áudio)."""
    return (", ".join(vocabulario) + ". " if vocabulario else "") + PROMPT_HESITACOES


def transcrever(caminho_wav, idioma="pt", regioes=None, progresso=None, log=print, vocabulario=None):
    """Transcrição literal com tempo e probabilidade por palavra.

    `regioes` ([(inicio, fim), …]) limita o Whisper aos turnos de fala. Sem isso,
    no áudio inteiro ele chegou a pular frases e repetir outras (rodada 4).
    """
    return hardware.com_recuo_para_cpu(
        lambda disp: _transcrever(disp, caminho_wav, idioma, regioes, progresso, vocabulario), log=log)


def _transcrever(disp, caminho_wav, idioma, regioes, progresso, vocabulario=None):
    from faster_whisper import WhisperModel

    modelo = WhisperModel(MODELO_WHISPER, device=disp, compute_type=hardware.tipo_computacao(disp))
    segmentos, info = modelo.transcribe(
        str(caminho_wav),
        language=None if idioma == "auto" else idioma,
        hotwords=dicas(vocabulario),
        beam_size=5,
        word_timestamps=True,
        condition_on_previous_text=False,
        # sem VAD: cortar trechos "sem fala" pode descartar fala baixa
        vad_filter=False,
        clip_timestamps=[t for r in regioes for t in r] if regioes else "0",
    )
    palavras = []
    for seg in segmentos:
        texto_seg = seg.text.strip().lower()
        suspeito = (any(frase in texto_seg for frase in ALUCINACOES_CONHECIDAS)
                    or (seg.no_speech_prob > 0.6 and seg.avg_logprob < -1.0))
        for p in seg.words or []:
            palavras.append({
                "inicio": round(float(p.start), 3),
                "fim": round(float(p.end), 3),
                "texto": p.word.strip(),
                "prob": round(float(p.probability), 3),
                "segmento": seg.id,
                "suspeita_alucinacao": bool(suspeito),
            })
        if progresso:
            progresso(seg.end, info.duration)
    marcar_empilhadas(palavras)
    del modelo
    hardware.liberar_gpu()
    return palavras, {
        "modelo": MODELO_WHISPER,
        "dispositivo": disp,
        "idioma_detectado": info.language,
        "prob_idioma": round(info.language_probability, 3),
        "duracao_s": round(info.duration, 3),
    }


def transcrever_trecho(amostras, idioma="pt", vocabulario=None):
    """Item 11, "reanalisar": o mesmo Whisper com mais tentativas (busca mais ampla e
    temperaturas de recuo) num trecho curto já recortado. Devolve palavras com tempo."""
    return hardware.com_recuo_para_cpu(lambda disp: _transcrever_trecho(disp, amostras, idioma, vocabulario))


def _transcrever_trecho(disp, amostras, idioma, vocabulario=None):
    from faster_whisper import WhisperModel

    modelo = WhisperModel(MODELO_WHISPER, device=disp, compute_type=hardware.tipo_computacao(disp))
    segmentos, _ = modelo.transcribe(
        amostras, language=None if idioma == "auto" else idioma, hotwords=dicas(vocabulario),
        beam_size=10, best_of=5, patience=2.0, temperature=(0.0, 0.2, 0.4, 0.6),
        word_timestamps=True, condition_on_previous_text=False, vad_filter=False)
    palavras = [{"inicio": round(float(p.start), 3), "fim": round(float(p.end), 3), "texto": p.word.strip(),
                 "prob": round(float(p.probability), 3)} for seg in segmentos for p in (seg.words or [])]
    del modelo
    hardware.liberar_gpu()
    return palavras


def marcar_empilhadas(palavras, minimo=3):
    """Palavras seguidas sem duração ("empilhadas" no mesmo instante) são o sinal de
    frase repetida pelo Whisper sem ter sido dita (rodada 4). Só marca, nunca remove."""
    def vazia(p):
        return p["fim"] - p["inicio"] < 0.01

    i = 0
    while i < len(palavras):
        j = i
        while j < len(palavras) and vazia(palavras[j]):
            j += 1
        if j - i >= minimo:
            for p in palavras[i:j]:
                p["suspeita_alucinacao"] = True
        i = max(j, i + 1)
    return palavras


def segunda_escuta(caminho_wav, log=print, progresso=None):
    """wav2vec2-CORAA: palavras com tempo, usadas só para gerar sugestões (item 16)."""
    from . import audio

    return segunda_escuta_amostras(audio.carregar(caminho_wav), log=log, progresso=progresso)


def segunda_escuta_amostras(amostras, log=print, progresso=None):
    return hardware.com_recuo_para_cpu(lambda disp: _segunda_escuta(disp, amostras, progresso), log=log,
                                       disp=hardware.dispositivo_torch())


def _segunda_escuta(disp, amostras, progresso=None):
    import math

    from transformers import pipeline

    asr = pipeline("automatic-speech-recognition", model=MODELO_SEGUNDA_ESCUTA, device=0 if disp == "cuda" else -1)
    if progresso:  # o pipeline não informa andamento: conta os blocos de 30 s (passo de 20 s) já ouvidos
        total = max(1, math.ceil(max(0, len(amostras) / TAXA_AMOSTRAGEM - 30) / 20) + 1)
        feitos, forward = [0], asr._forward

        def contar(*args, **kwargs):
            saida = forward(*args, **kwargs)
            feitos[0] += 1
            progresso(min(feitos[0], total), total)
            return saida

        asr._forward = contar
    # passa as amostras já decodificadas: evita depender de decodificador extra
    entrada = {"raw": amostras, "sampling_rate": TAXA_AMOSTRAGEM}
    saida = asr(entrada, chunk_length_s=30, stride_length_s=5, return_timestamps="word")
    palavras = [{"inicio": round(float(c["timestamp"][0]), 3), "fim": round(float(c["timestamp"][1]), 3),
                 "texto": c["text"]} for c in saida.get("chunks", [])]
    del asr
    hardware.liberar_gpu()
    return palavras, {"modelo": MODELO_SEGUNDA_ESCUTA}


class DiarizacaoIndisponivel(RuntimeError):
    pass


def interlocutores(caminho_wav, num_falantes=None, log=print, progresso=None):
    """Turnos de fala por interlocutor e trechos com vozes sobrepostas."""
    return hardware.com_recuo_para_cpu(lambda disp: _interlocutores(disp, caminho_wav, num_falantes, progresso),
                                       log=log, disp=hardware.dispositivo_torch())


# peso de cada passo do pyannote no tempo total da etapa (medido na CPU: as "embeddings" dominam)
PASSOS_PYANNOTE = {"segmentation": (0.0, 0.15), "embeddings": (0.15, 0.97)}


def _interlocutores(disp, caminho_wav, num_falantes, progresso=None):
    import torch

    from . import audio

    try:
        from pyannote.audio import Pipeline

        pipe = Pipeline.from_pretrained(MODELO_DIARIZACAO, token=os.environ.get("HF_TOKEN"))
    except Exception as erro:
        raise DiarizacaoIndisponivel(
            "Modelo de interlocutores não disponível. Ele é baixado na instalação: "
            "rode \"Degrava IA.bat\" instalar, com internet. "
            f"Detalhe: {erro}") from erro
    if pipe is None:
        raise DiarizacaoIndisponivel("Termos do modelo de interlocutores não aceitos no Hugging Face.")
    if disp == "cuda":
        pipe.to(torch.device("cuda"))

    onda = torch.from_numpy(audio.carregar(caminho_wav)).unsqueeze(0)
    entrada = {"waveform": onda, "sample_rate": TAXA_AMOSTRAGEM}

    def gancho(passo, _artefato, file=None, total=None, completed=None):
        if progresso and passo in PASSOS_PYANNOTE and total:
            ini, fim = PASSOS_PYANNOTE[passo]
            progresso(ini + (fim - ini) * min(completed or 0, total) / total, 1)

    saida = pipe(entrada, num_speakers=num_falantes, hook=gancho) if num_falantes else pipe(entrada, hook=gancho)

    def turnos(anotacao):
        return [{"inicio": round(t.start, 3), "fim": round(t.end, 3), "falante": f}
                for t, _, f in anotacao.itertracks(yield_label=True)]

    completo = turnos(saida.speaker_diarization)
    exclusivo = turnos(saida.exclusive_speaker_diarization)
    sobreposicoes = [{"inicio": round(s.start, 3), "fim": round(s.end, 3)}
                     for s in saida.speaker_diarization.get_overlap()]
    del pipe
    hardware.liberar_gpu()
    return {"turnos": exclusivo, "turnos_completos": completo, "sobreposicoes": sobreposicoes,
            "modelo": MODELO_DIARIZACAO}
