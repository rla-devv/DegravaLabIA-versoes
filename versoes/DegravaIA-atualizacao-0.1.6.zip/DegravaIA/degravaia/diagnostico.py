"""Instalação e conferência no PC do usuário.

    python -m degravaia baixar-modelos   baixa uma vez os modelos que faltam (sem token)
    python -m degravaia diagnostico      mostra o que o app encontrou: GPU, ffmpeg, modelos, fonte do PDF

Depois de baixados, os modelos ficam no computador e o app roda sem internet
(o abrir.py liga o modo offline das bibliotecas).
"""
import os
import platform
import shutil
import sys
from pathlib import Path

from .config import MODELO_DIARIZACAO, MODELO_SEGUNDA_ESCUTA, MODELO_WHISPER, NOME_APP, VERSAO


def _linha(rotulo, ok, detalhe=""):
    print(f"  [{'OK' if ok else '!!'}] {rotulo}{': ' + detalhe if detalhe else ''}")
    return ok


def diagnostico():
    print(f"{NOME_APP} {VERSAO} — diagnóstico")
    tudo = True
    tudo &= _linha("Python", sys.version_info >= (3, 10), f"{platform.python_version()} ({platform.system()})")

    try:
        import ctranslate2

        n = ctranslate2.get_cuda_device_count()
        tudo &= _linha("Whisper (ctranslate2)", True, f"GPU NVIDIA: {'sim, ' + str(n) if n else 'não, usa a CPU'}")
    except Exception as e:
        tudo &= _linha("Whisper (ctranslate2)", False, str(e))

    try:
        import torch

        if torch.cuda.is_available():
            p = torch.cuda.get_device_properties(0)
            det = f"GPU {p.name}, {p.total_memory / 2**30:.1f} GB"
        else:
            det = "sem GPU, usa a CPU"
        tudo &= _linha("wav2vec2 e pyannote (torch)", True, f"{torch.__version__}; {det}")
    except Exception as e:
        tudo &= _linha("wav2vec2 e pyannote (torch)", False, str(e))

    try:
        from .audio import ffmpeg

        tudo &= _linha("ffmpeg", True, ffmpeg())
    except Exception as e:
        tudo &= _linha("ffmpeg", False, str(e))

    try:
        from .exportacao import _fontes_pdf

        tudo &= _linha("Fonte do PDF", True, _fontes_pdf()[0])
    except Exception as e:
        tudo &= _linha("Fonte do PDF", False, str(e))

    for modelo in (MODELO_WHISPER, MODELO_SEGUNDA_ESCUTA, MODELO_DIARIZACAO):
        tudo &= _linha(f"Modelo {modelo}", _no_computador(modelo),
                       "no computador" if _no_computador(modelo) else "falta baixar (instalar.py)")

    offline = os.environ.get("HF_HUB_OFFLINE") == "1"
    _linha("Modo offline das bibliotecas", offline, "ligado" if offline else "desligado (o abrir.py liga)")
    print("Tudo certo." if tudo else "Há itens marcados com !! acima.")
    return 0 if tudo else 1


def _no_computador(modelo):
    try:
        if modelo == MODELO_WHISPER:  # o faster-whisper baixa só os arquivos que usa
            from faster_whisper.utils import download_model

            download_model(modelo, local_files_only=True)
        else:
            from huggingface_hub import snapshot_download

            snapshot_download(modelo, local_files_only=True)
        return True
    except Exception:
        return False


def _pastas_com_modelos():
    """Outros lugares deste PC onde os modelos podem já ter sido baixados."""
    from huggingface_hub.constants import HF_HUB_CACHE

    destino = Path(HF_HUB_CACHE).resolve()
    candidatos = [Path.home() / ".cache" / "huggingface" / "hub"]  # pasta padrão do Hugging Face
    raiz = destino.parent.parent  # .../DegravaIA (quando os modelos ficam em DegravaIA/modelos)
    for base in (raiz.parent, raiz.parent.parent):  # outras cópias do DegravaIA ao lado desta
        candidatos += list(base.glob("*/modelos/hub")) + list(base.glob("*/*/modelos/hub"))
    vistos = []
    for c in candidatos:
        try:
            c = c.resolve()
        except OSError:
            continue
        if c.is_dir() and c != destino and c not in vistos:
            vistos.append(c)
    return destino, vistos


def _copiar(origem, destino):
    """Copia um modelo já baixado. Segue os atalhos (links simbólicos) da pasta do Hugging Face
    e leva só refs/ e snapshots/ com os arquivos de verdade, o mesmo formato que ele usa no
    Windows sem atalhos. No mesmo disco usa links físicos (não ocupa espaço de novo)."""
    def ligar(a, b):
        real = os.path.realpath(a)  # o arquivo de verdade por trás do atalho
        try:
            os.link(real, b)
        except OSError:
            shutil.copy2(real, b)

    if destino.exists():  # cópia anterior incompleta: refaz do zero (é a pasta do próprio app)
        shutil.rmtree(destino)
    for parte in ("refs", "snapshots"):
        if (origem / parte).is_dir():
            shutil.copytree(origem / parte, destino / parte, symlinks=False, copy_function=ligar)


def reaproveitar_modelos():
    """Antes de baixar, procura os modelos já baixados em outro lugar do PC e copia de lá."""
    destino, origens = _pastas_com_modelos()
    for modelo in (MODELO_WHISPER, MODELO_SEGUNDA_ESCUTA, MODELO_DIARIZACAO):
        if _no_computador(modelo):
            continue
        nome = "models--" + modelo.replace("/", "--")
        for origem in origens:
            if (origem / nome).is_dir():
                print(f"Reaproveitando {modelo} já baixado em {origem} …", flush=True)
                _copiar(origem / nome, destino / nome)
                if _no_computador(modelo):
                    break


def baixar_modelos():
    """Baixa os modelos que faltam (ou reaproveita os já baixados). Nenhum pede token:
    o pyannote vem dentro do pacote."""
    from huggingface_hub import snapshot_download

    reaproveitar_modelos()
    if all(_no_computador(m) for m in (MODELO_WHISPER, MODELO_SEGUNDA_ESCUTA, MODELO_DIARIZACAO)):
        print("Os três modelos já estão no computador: nada a baixar.")
        return 0
    from faster_whisper.utils import download_model

    # primeiro os dois modelos livres, que não precisam de token
    if not _no_computador(MODELO_WHISPER):
        print(f"Baixando {MODELO_WHISPER} (cerca de 3 GB) …", flush=True)
        download_model(MODELO_WHISPER)
    if not _no_computador(MODELO_SEGUNDA_ESCUTA):
        print(f"Baixando {MODELO_SEGUNDA_ESCUTA} (cerca de 1,3 GB) …", flush=True)
        snapshot_download(MODELO_SEGUNDA_ESCUTA)
    if not _no_computador(MODELO_DIARIZACAO):
        # o pacote do DegravaIA já traz este modelo (modelos/hub); só a cópia do código-fonte
        # precisa baixá-lo, e os autores exigem um token do Hugging Face para isso
        if not os.environ.get("HF_TOKEN"):
            print(f"Falta o modelo {MODELO_DIARIZACAO}, que vem dentro do DegravaIA.zip.")
            print("Baixe o pacote completo de novo e descompacte-o inteiro.")
            return 1
        print(f"Baixando {MODELO_DIARIZACAO} …", flush=True)
        snapshot_download(MODELO_DIARIZACAO, token=os.environ["HF_TOKEN"])
    print("Modelos no computador. Daqui em diante o app funciona sem internet.")
    return 0
