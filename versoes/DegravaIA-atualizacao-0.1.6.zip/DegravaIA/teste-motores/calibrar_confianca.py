"""Rodada 5: a partir de qual certeza uma palavra vira [ininteligível] (item 3).

Transcreve trechos do CORAA-MuPe com a configuração do app (Whisper large-v3 +
hotwords, por trecho), alinha cada palavra com a referência humana e mede, para
cada limite de certeza, quantas palavras abaixo dele estão erradas e quantas
certas seriam escondidas.

    python calibrar_confianca.py transcrever --por-qualidade 70
    python calibrar_confianca.py segunda      # acrescenta o wav2vec2 aos mesmos trechos
    python calibrar_confianca.py analisar
"""
import argparse
import io
import json
import random
import re
import sys
from pathlib import Path

import numpy as np
import pyarrow.parquet as pq
import soundfile as sf

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
sys.path.insert(0, str(Path(__file__).resolve().parent))
from comparar import normalizar  # noqa: E402

SAIDA = Path(__file__).parent / "resultados_confianca.json"

# o corpus padroniza a fala; o motor escreve o que foi dito. Igualar antes de comparar.
COLOQUIAL = {"tava": "estava", "tavam": "estavam", "tô": "estou", "tá": "está",
             "pra": "para", "pro": "para o", "pros": "para os", "pras": "para as", "cê": "você",
             "cês": "vocês", "ocê": "você", "tamo": "estamos",
             "taí": "está aí", "dum": "de um", "duma": "de uma"}


def _amostras(pasta, por_qualidade, semente):
    """Sorteia os trechos pelos metadados e só então lê o áudio dos escolhidos (memória)."""
    colunas = ["speaker_code", "speaker_type", "audio_quality", "duration", "original_text"]
    linhas = {"high": [], "low": []}
    for arq in sorted(Path(pasta).glob("*.parquet")):
        for n, l in enumerate(pq.read_table(arq, columns=colunas).to_pylist()):
            if l["speaker_type"] == "R" and 2 <= l["duration"] <= 12 and l["audio_quality"] in linhas:
                linhas[l["audio_quality"]].append(l | {"_arq": arq, "_linha": n})
    rnd = random.Random(semente)
    escolha = []
    for q, lista in linhas.items():
        # no máximo 15 trechos por pessoa, para não depender de uma voz só
        por_voz = {}
        rnd.shuffle(lista)
        for l in lista:
            if len(por_voz.setdefault(l["speaker_code"], [])) < 15:
                por_voz[l["speaker_code"]].append(l)
        todas = [l for v in por_voz.values() for l in v]
        rnd.shuffle(todas)
        escolha += todas[:por_qualidade]
    for arq in {l["_arq"] for l in escolha}:
        tabela = pq.read_table(arq, columns=["audio"])
        for l in escolha:
            if l["_arq"] == arq:
                l["audio"] = tabela.slice(l["_linha"], 1).to_pylist()[0]["audio"]
    return escolha


def transcrever(args):
    from faster_whisper import WhisperModel

    from degravaia.config import MODELO_WHISPER, PROMPT_HESITACOES

    modelo = WhisperModel(MODELO_WHISPER, device="cpu", compute_type="int8")
    resultados = []
    amostras = _amostras(args.dados, args.por_qualidade, args.semente)
    for n, l in enumerate(amostras, 1):
        onda, taxa = sf.read(io.BytesIO(l["audio"]["bytes"]), dtype="float32")
        if onda.ndim > 1:
            onda = onda.mean(axis=1)
        if taxa != 16000:
            x = np.arange(0, len(onda), taxa / 16000)
            onda = np.interp(x, np.arange(len(onda)), onda).astype("float32")
        segs, _ = modelo.transcribe(onda, language="pt", hotwords=PROMPT_HESITACOES, beam_size=5,
                                    word_timestamps=True, condition_on_previous_text=False,
                                    vad_filter=False)
        palavras = [{"texto": w.word.strip(), "prob": round(w.probability, 3),
                     "dur": round(w.end - w.start, 3)} for s in segs for w in (s.words or [])]
        resultados.append({"voz": l["speaker_code"], "qualidade": l["audio_quality"],
                           "referencia": l["original_text"], "palavras": palavras})
        print(f"{n}/{len(amostras)} {l['audio_quality']} {' '.join(p['texto'] for p in palavras)[:70]}",
              flush=True)
        SAIDA.write_text(json.dumps(resultados, ensure_ascii=False, indent=1), encoding="utf-8")


def segunda(args):
    import torch
    from transformers import pipeline

    from degravaia.config import MODELO_SEGUNDA_ESCUTA

    resultados = json.loads(SAIDA.read_text(encoding="utf-8"))
    amostras = _amostras(args.dados, args.por_qualidade, args.semente)[:len(resultados)]
    asr = pipeline("automatic-speech-recognition", model=MODELO_SEGUNDA_ESCUTA, device=-1)
    for item, l in zip(resultados, amostras):
        assert item["referencia"] == l["original_text"]
        onda, taxa = sf.read(io.BytesIO(l["audio"]["bytes"]), dtype="float32")
        if onda.ndim > 1:
            onda = onda.mean(axis=1)
        if taxa != 16000:
            x = np.arange(0, len(onda), taxa / 16000)
            onda = np.interp(x, np.arange(len(onda)), onda).astype("float32")
        with torch.inference_mode():
            item["wav2vec2"] = asr({"raw": onda, "sampling_rate": 16000})["text"]
    SAIDA.write_text(json.dumps(resultados, ensure_ascii=False, indent=1), encoding="utf-8")
    print(f"{len(resultados)} trechos com segunda escuta")


def _concorda(item):
    """Para cada palavra do Whisper: o wav2vec2 ouviu a mesma palavra no mesmo ponto?"""
    import difflib

    a, dono = [], []
    for i, p in enumerate(item["palavras"]):
        for w in normalizar(p["texto"]).split():
            a.append(w)
            dono.append(i)
    from degravaia.marcacoes import canonico, colados

    b = normalizar(item.get("wav2vec2", "")).split()
    igual = colados(a, b)
    blocos = difflib.SequenceMatcher(a=[canonico(t) for t in a], b=[canonico(t) for t in b], autojunk=False)
    for op, i1, i2, _, _ in blocos.get_opcodes():
        if op == "equal":
            igual.update(range(i1, i2))
    return [bool(ks) and all(k in igual for k in ks)
            for ks in ([k for k in range(len(a)) if dono[k] == i] for i in range(len(item["palavras"])))]


def _forma(palavra):
    t = normalizar(palavra)
    return COLOQUIAL.get(t, t).split() if t else []


def _rotular(item):
    """Para cada palavra do motor: 'certa', 'errada' ou None (número, sem comparação)."""
    import jiwer

    ref = []
    for w in normalizar(item["referencia"]).split():
        ref += COLOQUIAL.get(w, w).split()
    hip, dono = [], []
    for i, p in enumerate(item["palavras"]):
        for w in _forma(p["texto"]):
            hip.append(w)
            dono.append(i)
    rotulos = [None] * len(item["palavras"])
    if not ref or not hip:
        return rotulos
    certo = [False] * len(hip)
    for bloco in jiwer.process_words(" ".join(ref), " ".join(hip)).alignments[0]:
        if bloco.type == "equal":
            for k in range(bloco.hyp_start_idx, bloco.hyp_end_idx):
                certo[k] = True
    for i in range(len(item["palavras"])):
        partes = [certo[k] for k in range(len(hip)) if dono[k] == i]
        if partes:
            rotulos[i] = "certa" if all(partes) else "errada"
    for i, p in enumerate(item["palavras"]):
        if re.search(r"\d", p["texto"]):
            rotulos[i] = None  # "1990" contra "mil novecentos e noventa"
    return rotulos


def analisar(args):
    itens = json.loads(SAIDA.read_text(encoding="utf-8"))
    pares, concord = [], []
    com_segunda = all("wav2vec2" in i for i in itens)
    for item in itens:
        conc = _concorda(item) if com_segunda else [False] * len(item["palavras"])
        for p, r, c in zip(item["palavras"], _rotular(item), conc):
            if r:
                pares.append((p["prob"], r == "errada", item["qualidade"]))
                concord.append(c)
    total = len(pares)
    erradas = sum(e for _, e, _ in pares)
    print(f"{len(itens)} trechos, {total} palavras comparadas, {erradas} erradas ({100 * erradas / total:.1f}%)")
    for q in ("high", "low"):
        sub = [x for x in pares if x[2] == q]
        if sub:
            print(f"  áudio {q}: {len(sub)} palavras, {100 * sum(e for _, e, _ in sub) / len(sub):.1f}% erradas")
    regras = [("só certeza", False)] + ([("certeza e motores discordam", True)] if com_segunda else [])
    if com_segunda:
        conc_err = sum(1 for (_, e, _), c in zip(pares, concord) if c and e)
        conc_tot = sum(concord)
        print(f"Palavras em que os dois motores concordam: {conc_tot}, delas erradas: {conc_err} "
              f"({100 * conc_err / max(conc_tot, 1):.1f}%)")
    for nome, usa in regras:
        print()
        print(f"Regra: {nome}")
        print("| Limite | Viram [ininteligível] | Delas, erradas (precisão) | Erros pegos | Palavras certas escondidas |")
        print("|---|---|---|---|---|")
        for lim in (0.05, 0.1, 0.15, 0.2, 0.25, 0.3, 0.4, 0.5):
            abaixo = [e for (p, e, _), c in zip(pares, concord) if p < lim and not (usa and c)]
            if not abaixo:
                continue
            err = sum(abaixo)
            certas = len(abaixo) - err
            print(f"| < {lim:.2f} | {len(abaixo)} ({100 * len(abaixo) / total:.1f}%) | {100 * err / len(abaixo):.0f}% "
                  f"| {100 * err / erradas:.1f}% | {certas} ({100 * certas / (total - erradas):.1f}%) |")


def main():
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)
    t = sub.add_parser("transcrever")
    t.add_argument("--dados", default=str(Path(__file__).parent / "dados/data"))
    t.add_argument("--por-qualidade", type=int, default=70)
    t.add_argument("--semente", type=int, default=5)
    g = sub.add_parser("segunda")
    g.add_argument("--dados", default=str(Path(__file__).parent / "dados/data"))
    g.add_argument("--por-qualidade", type=int, default=70)
    g.add_argument("--semente", type=int, default=5)
    sub.add_parser("analisar")
    args = ap.parse_args()
    {"transcrever": transcrever, "segunda": segunda, "analisar": analisar}[args.cmd](args)


if __name__ == "__main__":
    main()
