"""Etapa 1 completa: importar → extrair áudio → interlocutores → transcrever → segunda escuta."""
from pathlib import Path

from . import audio, marcacoes, montagem, motores
from .config import MELHORIA_USO, TAXA_AMOSTRAGEM
from .projeto import Projeto, agora


def processar(origem, raiz="projetos", idioma="pt", num_falantes=None, com_interlocutores=True, log=print,
              procedencia=None, melhoria=None, andamento=None, vocabulario=None):
    """`andamento(aviso)` recebe {"etapa", "frac"} ao longo do caminho (barra da tela, andamento.py)."""
    avisar = _avisador(andamento)
    avisar({"etapa": "preparar", "frac": 0})
    log(f"Importando {Path(origem).name} …")
    vocabulario = motores.limpar_vocabulario(", ".join(vocabulario or []))
    proj = Projeto.criar(origem, raiz=raiz, idioma=idioma, num_falantes=num_falantes, procedencia=procedencia,
                         melhoria=melhoria, vocabulario=vocabulario)
    log(f"  SHA-256: {proj.dados['original']['sha256']}")

    log("Extraindo áudio (cópia de trabalho, sem filtros) …")
    audio.extrair_audio(proj.caminho_original, proj.caminho_audio)
    dur = audio.duracao(proj.caminho_audio)
    log(f"  Duração: {montagem.tempo(dur)}")
    from .hardware import dispositivo

    etapas = ["preparar"] + (["interlocutores"] if com_interlocutores else []) + \
        ["transcricao"] + (["segunda_escuta"] if idioma in ("pt", "auto") else []) + ["montagem"]
    avisar({"etapa": "preparar", "frac": 0.5, "duracao": dur, "disp": dispositivo(), "etapas": etapas})

    audio_motores = proj.caminho_audio
    if melhoria:  # item 6: sempre em cópia; o original e o áudio de trabalho ficam intactos
        info = audio.MELHORIAS[melhoria]
        log(f"Melhorando o áudio (cópia: {info['descricao']}) …")
        audio.melhorar(proj.caminho_original, proj.caminho_audio_melhorado, melhoria)
        if "motores" in MELHORIA_USO:
            audio_motores = proj.pasta / "trabalho" / "audio_melhorado_16k.wav"
            audio.melhorar(proj.caminho_original, audio_motores, melhoria, taxa=TAXA_AMOSTRAGEM)
        proj.dados["processamento"]["melhoria"] = {"nivel": melhoria, "descricao": info["descricao"],
                                                   "filtro": info["filtro"], "uso": list(MELHORIA_USO),
                                                   "quando": agora()}
        proj.salvar()

    # Interlocutores primeiro: os turnos dizem ao Whisper onde há fala (rodada 4)
    turnos, sobreposicoes, regioes = [], [], None
    if com_interlocutores:
        log("Identificando interlocutores (pyannote) …")
        avisar({"etapa": "interlocutores", "frac": 0})
        d = motores.interlocutores(audio_motores, num_falantes=num_falantes, log=log,
                                   progresso=lambda f, t: avisar({"etapa": "interlocutores", "frac": f / t}))
        turnos, sobreposicoes = d["turnos"], d["sobreposicoes"]
        regioes = montagem.regioes_por_turno(turnos)
        proj.dados["processamento"]["interlocutores"] = {
            "modelo": d["modelo"], "quando": agora(), "num_falantes_informado": num_falantes,
            "turnos": turnos, "sobreposicoes": sobreposicoes}
        log(f"  {len({t['falante'] for t in turnos})} vozes, {len(regioes)} trechos de fala")

    log("Transcrevendo (Whisper large-v3, modo literal) …")
    avisar({"etapa": "transcricao", "frac": 0})
    ultimo = [-1]

    def progresso(feito, total):
        pct = int(100 * feito / total) if total else 100
        avisar({"etapa": "transcricao", "frac": feito / total if total else 1})
        if pct // 10 > ultimo[0]:
            ultimo[0] = pct // 10
            log(f"  {pct}%")

    if vocabulario:
        log(f"  Vocabulário informado: {', '.join(vocabulario)}")
    palavras, info_t = motores.transcrever(audio_motores, idioma=idioma, regioes=regioes, log=log,
                                           progresso=progresso, vocabulario=vocabulario)
    info_t["vocabulario"] = vocabulario
    info_t["por_turno"] = regioes is not None
    proj.dados["processamento"]["transcricao"] = info_t | {"quando": agora(), "regioes": regioes}
    proj.registrar("transcricao", {"palavras": len(palavras), **info_t}, origem="ia")

    log("Segunda escuta (wav2vec2-CORAA) …")
    if (info_t["idioma_detectado"] or idioma) == "pt":
        avisar({"etapa": "segunda_escuta", "frac": 0})
        w2v, info_w = motores.segunda_escuta(
            audio_motores, log=log, progresso=lambda f, t: avisar({"etapa": "segunda_escuta", "frac": f / t}))
        proj.dados["segunda_escuta"] = w2v
        proj.dados["processamento"]["segunda_escuta"] = info_w | {"quando": agora()}
        if regioes:
            # fala que o pyannote não viu nunca chegou ao Whisper: avisar, nunca descartar
            fora = montagem.fora_das_regioes(w2v, regioes)
            proj.dados["processamento"]["segunda_escuta"]["fora_dos_turnos"] = fora
            if fora:
                log(f"  ATENÇÃO: {len(fora)} palavra(s) ouvidas fora dos turnos de fala; conferir na revisão")
    else:
        log("  ignorada: o modelo de segunda escuta é só para português")

    avisar({"etapa": "montagem", "frac": 0})
    montagem.atribuir_falantes(palavras, turnos)
    montagem.marcar_sobreposicoes(palavras, sobreposicoes)
    proj.dados["palavras"] = palavras
    proj.dados["interlocutores"] = montagem.rotular_interlocutores(palavras)
    proj.dados["falas"] = montagem.montar_falas(palavras)
    marcacoes.gerar(proj.dados)
    proj.salvar()
    proj.registrar("montagem", {"falas": len(proj.dados["falas"]),
                                "interlocutores": len(proj.dados["interlocutores"]),
                                "marcacoes": len(proj.dados["marcacoes"]),
                                "sugestoes_insercao": len(proj.dados["insercoes"])}, origem="ia")
    avisar({"etapa": "montagem", "frac": 1})
    log(f"Projeto salvo em {proj.pasta}")
    return proj


def _avisador(andamento):
    """Repassa os avisos sem inundar a tela: mudança de etapa sempre; dentro dela, a cada 1%
    ou a cada 2 s."""
    import time

    ultimo = {"etapa": None, "frac": -1.0, "t": 0.0}

    def avisar(aviso):
        if andamento is None:
            return
        agora = time.monotonic()
        nova = aviso["etapa"] != ultimo["etapa"]
        if nova or "duracao" in aviso or aviso["frac"] - ultimo["frac"] >= 0.01 or agora - ultimo["t"] >= 2:
            ultimo.update(etapa=aviso["etapa"], frac=aviso["frac"], t=agora)
            andamento(aviso)

    return avisar
