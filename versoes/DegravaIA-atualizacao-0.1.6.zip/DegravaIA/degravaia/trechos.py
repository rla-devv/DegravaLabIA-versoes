"""Ajuda por trecho (item 11): versão limpa só para leitura e reanálise do trecho.

Nada aqui altera o projeto. Os resultados voltam para a tela como sugestões; só
entram no documento quando o usuário aceita (mesma regra do item 3), pela
alteração "aceitar_reanalise" do módulo revisao.
"""
import difflib
import tempfile
from pathlib import Path

from . import audio, marcacoes, motores
from .config import TAXA_AMOSTRAGEM

FOLGA_S = 0.5  # o trecho é recortado com folga para o motor ouvir o começo e o fim inteiros


def limpar(texto):
    """Versão limpa para LEITURA: sem hesitações, sem "né" e sem repetições imediatas.

    Regra fixa, sem modelo de linguagem (item 11). Falsos começos não são detectados.
    """
    saida = []
    for palavra in texto.split():
        tokens = marcacoes._norm(palavra)
        if not tokens:
            saida.append(palavra)
            continue
        if all(marcacoes.canonico(t) == "<hesitação>" or t in marcacoes.MULETAS for t in tokens):
            continue
        if saida and marcacoes._norm(saida[-1]) == tokens:
            continue  # "eu eu" → "eu"
        saida.append(palavra)
    # repetição de duas palavras: "a gente a gente" → "a gente"
    k = 0
    while k + 3 < len(saida):
        if [marcacoes._norm(w) for w in saida[k:k + 2]] == [marcacoes._norm(w) for w in saida[k + 2:k + 4]]:
            del saida[k + 2:k + 4]
        else:
            k += 1
    texto = " ".join(saida).strip(" ,")
    return texto[:1].upper() + texto[1:] if texto else texto


def _intervalo(dados, ids):
    ps = dados["palavras"]
    return ps[ids[0]]["inicio"], ps[ids[-1]]["fim"]


def _so_a_selecao(novas, antes, sel, depois):
    """Do que o motor ouviu no recorte (com folga), fica só o que corresponde à seleção.

    Alinha com as palavras atuais (vizinhas antes + seleção + vizinhas depois): o tempo das
    palavras num recorte curto é impreciso demais para separar pela hora.
    """
    def chave(t):
        tokens = marcacoes._norm(t)
        return " ".join(marcacoes.canonico(x) for x in tokens)

    a = [chave(t) for t in antes + sel + depois]
    b = [chave(t) for t in novas]
    s0, s1 = len(antes), len(antes) + len(sel)
    fica = []
    for op, i1, i2, j1, j2 in difflib.SequenceMatcher(a=a, b=b, autojunk=False).get_opcodes():
        if op == "equal":
            fica += [j1 + k for k in range(i2 - i1) if s0 <= i1 + k < s1]
        elif (i1 < s1 and i2 > s0) or (i1 == i2 and s0 <= i1 <= s1):
            fica += range(j1, j2)  # trocado, inserido ou apagado dentro da seleção
    return " ".join(novas[j] for j in sorted(set(fica))).strip()


def reanalisar(proj, ids, nivel=None):
    """Reanalisa o trecho (opcionalmente numa cópia melhorada só dele). Devolve sugestões."""
    dados = proj.dados
    ini, fim = _intervalo(dados, ids)
    corte_ini = max(0.0, ini - FOLGA_S)
    with tempfile.TemporaryDirectory() as tmp:
        destino = Path(tmp) / "trecho.wav"
        if nivel:
            audio.melhorar(proj.caminho_original, destino, nivel, corte_ini, fim + FOLGA_S, taxa=TAXA_AMOSTRAGEM)
        else:
            audio.recortar(proj.caminho_audio, destino, corte_ini, fim + FOLGA_S)
        amostras = audio.carregar(destino)
    idioma = dados.get("processamento", {}).get("transcricao", {}).get("idioma_detectado") or "pt"
    ps = dados["palavras"]
    vizinhas = [i for i, p in enumerate(ps) if p["fim"] > corte_ini and p["inicio"] < fim + FOLGA_S and p["texto"]]
    antes = [ps[i]["texto"] for i in vizinhas if i < ids[0]]
    depois = [ps[i]["texto"] for i in vizinhas if i > ids[-1]]
    sel = [ps[i]["texto"] for i in ids if ps[i]["texto"]]
    sugestoes = []
    w = motores.transcrever_trecho(amostras, idioma=idioma)
    texto_w = _so_a_selecao([p["texto"] for p in w], antes, sel, depois)
    rotulo = f"Whisper, mais tentativas{', áudio melhorado (' + audio.MELHORIAS[nivel]['descricao'] + ')' if nivel else ''}"
    if texto_w.strip():
        sugestoes.append({"origem": rotulo, "texto": texto_w.strip()})
    if idioma == "pt":
        w2v, _ = motores.segunda_escuta_amostras(amostras)
        texto_2 = _so_a_selecao([p["texto"] for p in w2v], antes, sel, depois)
        if texto_2.strip():
            sugestoes.append({"origem": "wav2vec2" + (", áudio melhorado" if nivel else ""), "texto": texto_2.strip()})
    atual = " ".join(dados["palavras"][i]["texto"] for i in ids)
    return {"inicio": ini, "fim": fim, "atual": atual, "sugestoes": sugestoes, "nivel": nivel}
