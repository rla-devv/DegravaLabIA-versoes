@echo off
chcp 65001 >nul
rem Degrava Lab IA - na primeira vez baixa e instala o que falta (precisa de internet so entao); depois, abre o app.
rem Tudo fica nesta pasta: o Python portatil oficial (python.org) vai para "python"; nada e instalado no Windows.
rem Opcoes: "Instalar Degrava Lab IA.bat" instalar | diagnostico | --navegador
rem --na-pasta: uso interno; o proprio .bat se copiou para a pasta "Degrava Lab IA" e roda de la (uma vez so)
set "DEGRAVAIA_NA_PASTA="
if /i "%~1"=="--na-pasta" set "DEGRAVAIA_NA_PASTA=1"
cd /d "%~dp0"
if exist "python\python.exe" if exist "degravaia\config.py" goto rodar
rem arquivo em UTF-8 sem BOM (por isso o chcp 65001): acentos so nas mensagens, comandos e rotulos sem acento
title Degrava Lab IA - Instalação
if defined DEGRAVAIA_NA_PASTA goto sem_cabecalho
echo.
echo  Degrava Lab IA - Transcrição de áudios e vídeos diretamente no seu computador
echo.
echo  A internet é usada só durante a instalação, para baixar o Python e os modelos de IA.
echo  Depois de instalado, o Degrava Lab IA funciona sem internet.
echo.
:sem_cabecalho
rem o instalador do app (degravaia\instalar.py) nao repete este cabecalho
set "DEGRAVAIA_CABECALHO=1"
set "DEGRAVAIA_PASTA=%~dp0"
set "DEGRAVAIA_BAT=%~f0"
powershell -NoProfile -ExecutionPolicy Bypass -Command "$s = [IO.File]::ReadAllText($env:DEGRAVAIA_BAT); iex $s.Substring($s.IndexOf('#' + 'POWERSHELL'))"
rem codigo 3: a instalacao continuou (e terminou) pela copia deste arquivo na pasta "Degrava Lab IA"
if errorlevel 3 exit /b 0
if errorlevel 1 goto erro
if not exist "python\python.exe" goto erro
if not exist "degravaia\config.py" goto erro
:rodar
rem num bloco: o cmd le a linha inteira antes de rodar, e uma atualizacao que troque este arquivo nao o atrapalha
if defined DEGRAVAIA_NA_PASTA ("python\python.exe" -m degravaia.abrir & exit /b)
("python\python.exe" -m degravaia.abrir %* & exit /b)
:erro
rem a mensagem (com acentos) ja foi mostrada pelo PowerShell
echo.
pause
exit /b 1

#POWERSHELL - daqui para baixo o .bat entrega ao PowerShell (o cmd nunca chega aqui; por isso pode ter acentos:
# o arquivo e UTF-8, e o PowerShell o le assim)
# 1. Python portatil oficial (python.org), conferido pelo SHA-256 abaixo (o do arquivo publicado).
# 2. O codigo do Degrava Lab IA: a versao mais nova publicada, pelo mesmo caminho conferido das atualizacoes
#    (atualizacao.json -> pacote com SHA-256 -> versao escrita dentro do pacote).
# Cada download vai para um arquivo .novo e so entra no lugar depois de conferido.
$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
[Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12
$pasta = $env:DEGRAVAIA_PASTA
$repo = 'https://raw.githubusercontent.com/rla-devv/degravaia-versoes/main/'
$pythonUrl = 'https://www.python.org/ftp/python/3.14.8/python-3.14.8-embed-amd64.zip'
$pythonSha = 'a93abe456ab01bd96d7a085b3cdb6566b3063f4241360d114142fbdb07f0a310'
$cabecalho = @{ 'User-Agent' = 'DegravaIA-instalador' }

function Etapa($texto) { Write-Host " • $texto... " -NoNewline }
function Concluida($texto = 'concluído') { Write-Host $texto -ForegroundColor Green }

function Baixar($url, $destino, $sha) {
    $novo = "$destino.novo"
    Invoke-WebRequest -UseBasicParsing -Uri $url -OutFile $novo -Headers $cabecalho -TimeoutSec 900
    if ((Get-FileHash -Algorithm SHA256 -LiteralPath $novo).Hash.ToLower() -ne $sha) {
        Remove-Item -LiteralPath $novo
        throw "o arquivo baixado não confere com o SHA-256 esperado ($url)"
    }
    Move-Item -Force -LiteralPath $novo -Destination $destino
}

# Onde instalar: sempre numa pasta "Degrava Lab IA", sem a pessoa precisar saber extrair.
#  - "Extrair tudo": a pasta do zip só tem este .bat; instala nela.
#  - Solto numa pasta com outros arquivos ("Extrair aqui" nos Downloads): instala numa pasta "Degrava Lab IA" ao lado.
#  - Aberto de dentro do zip (o Windows o roda em %TEMP%\TempN_<zip>): instala numa pasta "Degrava Lab IA" ao
#    lado do zip (achado pela janela do Explorador que mostra o zip, ou em Downloads, Área de Trabalho e
#    Documentos); se não der, em %LOCALAPPDATA%\Programs\Degrava Lab IA (sem administrador).
# Nos dois últimos casos ele se copia para a pasta escolhida, roda a cópia com --na-pasta (nesta mesma janela)
# e sai com o código 3.
$nomeApp = 'Degrava Lab IA'
$doApp = @([IO.Path]::GetFileName($env:DEGRAVAIA_BAT), 'Instalar Degrava Lab IA.bat', 'Degrava Lab IA.bat', 'Degrava Lab.bat', 'Degrava IA.bat', 'python', 'degravaia', 'modelos', 'projetos',
    'LEIA-ME.txt', 'arquivos-do-app.txt', 'versoes-anteriores', 'dados-janela', 'registro.txt', 'registro.anterior.txt',
    'Abrir Degrava Lab IA.lnk', 'Abrir Degrava Lab.lnk', 'Abrir Degrava IA.lnk', 'Abrir o Degrava IA.lnk',
    'python-portatil.zip', 'python-portatil.zip.novo',
    'degravaia-codigo.zip', 'degravaia-codigo.zip.novo', '.instalacao', 'desktop.ini', 'Thumbs.db')

function Gravavel($dir) {
    try {
        New-Item -ItemType Directory -Force -Path $dir | Out-Null
        $teste = Join-Path $dir '.teste-de-gravacao'
        [IO.File]::WriteAllText($teste, '')
        Remove-Item -Force -LiteralPath $teste
        return $true
    } catch { return $false }
}

function SeguirEm($dir) {
    $novo = Join-Path $dir 'Instalar Degrava Lab IA.bat'
    Copy-Item -Force -LiteralPath $env:DEGRAVAIA_BAT -Destination $novo
    Write-Host ' O Degrava Lab IA vai ser instalado na pasta:'
    Write-Host " $dir" -ForegroundColor Cyan
    Write-Host ''
    # a cópia roda nesta mesma janela; quando ela terminar, este .bat sai sem fazer mais nada
    Start-Process -FilePath $env:ComSpec -ArgumentList "/c `"`"$novo`" --na-pasta`"" -NoNewWindow -Wait
    exit 3
}

function NaoDeu {
    Write-Host ' Não foi possível criar a pasta do Degrava Lab IA.' -ForegroundColor Red
    Write-Host ' Extraia o zip (botão direito nele > Extrair tudo) e abra o "Instalar Degrava Lab IA.bat"'
    Write-Host ' de dentro da pasta que aparecer.'
    exit 1
}

if ($env:DEGRAVAIA_NA_PASTA -ne '1') {
    $folha = Split-Path -Leaf ($pasta.TrimEnd('\', '/'))
    if ($folha -match '^Temp\d+_(.+\.zip)$') {  # aberto de dentro do zip, sem extrair
        $zipNome = $Matches[1]
        $base = $null
        try {  # 1) a janela do Explorador que mostra o conteúdo do zip
            foreach ($j in (New-Object -ComObject Shell.Application).Windows()) {
                try { $caminho = [string]$j.Document.Folder.Self.Path } catch { continue }
                $i = $caminho.ToLower().IndexOf('.zip')
                if ($i -lt 0) { continue }
                $zip = $caminho.Substring(0, $i + 4)
                if ((Split-Path -Leaf $zip) -eq $zipNome -and (Test-Path -LiteralPath $zip)) { $base = Split-Path -Parent $zip; break }
            }
        } catch { }
        if (-not $base) {  # 2) o zip com esse nome em Downloads, Área de Trabalho e Documentos
            $downloads = Join-Path $env:USERPROFILE 'Downloads'
            try { $downloads = (New-Object -ComObject Shell.Application).Namespace('shell:Downloads').Self.Path } catch { }
            foreach ($d in @($downloads, [Environment]::GetFolderPath('Desktop'), [Environment]::GetFolderPath('MyDocuments'))) {
                if ($d -and (Test-Path -LiteralPath (Join-Path $d $zipNome))) { $base = $d; break }
            }
        }
        if ($base -and (Gravavel (Join-Path $base $nomeApp))) { SeguirEm (Join-Path $base $nomeApp) }
        $programas = Join-Path $env:LOCALAPPDATA "Programs\$nomeApp"  # 3) sem administrador
        if ($env:LOCALAPPDATA -and (Gravavel $programas)) { SeguirEm $programas }
        NaoDeu
    }
    # solto numa pasta com outros arquivos (conta os itens pelo PowerShell; o "find" não funciona no Wine)
    $outros = @(Get-ChildItem -LiteralPath $pasta -Force | Where-Object { $doApp -notcontains $_.Name })
    if ($outros.Count -gt 0 -and -not (Test-Path -LiteralPath (Join-Path $pasta 'degravaia\config.py'))) {
        $nova = Join-Path $pasta $nomeApp
        if (Gravavel $nova) { SeguirEm $nova }
        NaoDeu
    }
}

# antes de baixar: a internet funciona?
try {
    Invoke-WebRequest -UseBasicParsing -Method Head -Uri "${repo}atualizacao.json" -Headers $cabecalho -TimeoutSec 20 | Out-Null
} catch {
    Write-Host ' Sem conexão com a internet. A instalação precisa de internet para baixar os componentes do programa' -ForegroundColor Red
    Write-Host ' (só desta vez). Conecte o computador à internet e rode este arquivo de novo.' -ForegroundColor Red
    exit 1
}

try {
    if (-not (Test-Path -LiteralPath (Join-Path $pasta 'python\python.exe'))) {
        Etapa 'Baixando o Python portátil oficial (python.org, 11 MB)'
        $zip = Join-Path $pasta 'python-portatil.zip'
        Baixar $pythonUrl $zip $pythonSha
        Expand-Archive -Force -LiteralPath $zip -DestinationPath (Join-Path $pasta 'python')
        Remove-Item -LiteralPath $zip
        # liga o pip (import site) e deixa o Python enxergar o codigo do Degrava Lab IA (..)
        Get-ChildItem -LiteralPath (Join-Path $pasta 'python') -Filter '*._pth' | ForEach-Object {
            [IO.File]::WriteAllText($_.FullName, "python314.zip`r`n.`r`nLib\site-packages`r`n..`r`nimport site`r`n")
        }
        Concluida
    }
    if (-not (Test-Path -LiteralPath (Join-Path $pasta 'degravaia\config.py'))) {
        Etapa 'Baixando o Degrava Lab IA (versão mais recente)'
        $agora = [DateTimeOffset]::UtcNow.ToUnixTimeSeconds()
        $m = (Invoke-WebRequest -UseBasicParsing -Uri "${repo}atualizacao.json?t=$agora" -Headers $cabecalho -TimeoutSec 60).Content | ConvertFrom-Json
        if ($m.versao -notmatch '^\d+\.\d+\.\d+$' -or $m.arquivo -notmatch '^[A-Za-z0-9._-]+\.zip$' -or $m.sha256 -notmatch '^[0-9a-f]{64}$') {
            throw 'o atualizacao.json publicado não está no formato esperado'
        }
        $zip = Join-Path $pasta 'degravaia-codigo.zip'
        Baixar "${repo}versoes/$($m.arquivo)" $zip $m.sha256
        $tmp = Join-Path $pasta '.instalacao'
        if (Test-Path -LiteralPath $tmp) { Remove-Item -Recurse -Force -LiteralPath $tmp }
        Expand-Archive -LiteralPath $zip -DestinationPath $tmp
        $origem = Join-Path $tmp 'DegravaIA'
        $config = [IO.File]::ReadAllText((Join-Path $origem 'degravaia\config.py'))
        if ($config -notmatch ('(?m)^VERSAO = "' + [regex]::Escape($m.versao) + '"')) {
            throw 'a versão dentro do pacote não é a anunciada'
        }
        # arquivo por arquivo (o proprio .bat fica: e este que esta rodando)
        Get-ChildItem -LiteralPath $origem -Recurse -File -Force | ForEach-Object {
            $rel = $_.FullName.Substring($origem.Length).TrimStart('\', '/')
            if ($rel -ne [IO.Path]::GetFileName($env:DEGRAVAIA_BAT)) {
                $destino = Join-Path $pasta $rel
                New-Item -ItemType Directory -Force -Path (Split-Path -Parent $destino) | Out-Null
                Copy-Item -Force -LiteralPath $_.FullName -Destination $destino
            }
        }
        Remove-Item -Recurse -Force -LiteralPath $tmp
        Remove-Item -LiteralPath $zip
        Concluida "versão $($m.versao)"
    }
} catch {
    Write-Host 'falhou' -ForegroundColor Red
    Write-Host ''
    Write-Host " Não foi possível baixar: $($_.Exception.Message)" -ForegroundColor Red
    Write-Host ' Confira a conexão com a internet e abra o "Instalar Degrava Lab IA.bat" de novo.'
    Write-Host ' Se o problema continuar, envie um print desta janela para o suporte.'
    exit 1
}
