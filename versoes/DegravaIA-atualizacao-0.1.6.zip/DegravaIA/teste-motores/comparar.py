"""Compara motores de transcrição quanto à literalidade (hesitações, repetições).

Uso:
    python comparar.py --amostras amostras/ [--dispositivo auto|cpu|cuda]

A pasta de amostras deve conter pares  nome.wav  +  nome.txt  (transcrição
literal de referência, feita por humano). Roda tudo localmente.
"""
import argparse
import json
import re
import time
from pathlib import Path

import jiwer
from faster_whisper import WhisperModel

PROMPT_HESITACOES = (
    "Eh... então, né, eu eu acho que, ahn, tipo assim, hum, a gente a gente "
    "foi lá e, eh, né, ficou lá."
)

MOTORES = {
    "whisper-large-v3": ("Systran/faster-whisper-large-v3", None),
    "whisper-large-v3+prompt": ("Systran/faster-whisper-large-v3", PROMPT_HESITACOES),
    # hotwords: o prompt entra em toda janela de 30 s (initial_prompt só vale na primeira)
    "whisper-large-v3+hotwords": ("Systran/faster-whisper-large-v3", ("hotwords", PROMPT_HESITACOES)),
    "whisper-turbo+prompt": ("mobiuslabsgmbh/faster-whisper-large-v3-turbo", PROMPT_HESITACOES),
    "crisperwhisper": ("nyrahealth/faster_CrisperWhisper", None),
}

HESITACOES = {"eh", "ah", "hum", "ahn", "hã", "ãh", "uhum", "hmm", "uh", "éh", "an"}
MULETAS = {"né"}


def normalizar(texto):
    texto = texto.lower()
    texto = re.sub(r"\[.*?\]|\(.*?\)", " ", texto)
    texto = re.sub(r"[^\wà-ü\s]", " ", texto)
    return " ".join(texto.split())


def contar(palavras, conjunto):
    return sum(1 for p in palavras if p in conjunto)


def repeticoes(palavras):
    return sum(1 for a, b in zip(palavras, palavras[1:]) if a == b)


def recall(achados, esperados):
    if esperados == 0:
        return None
    return min(achados, esperados) / esperados


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--amostras", default="amostras")
    ap.add_argument("--dispositivo", default="auto")
    ap.add_argument("--motores", default=",".join(MOTORES))
    ap.add_argument("--saida", default="resultados.json")
    args = ap.parse_args()

    amostras = sorted(Path(args.amostras).glob("*.wav"))
    refs = {a.stem: normalizar(a.with_suffix(".txt").read_text(encoding="utf-8")) for a in amostras}
    duracao_total = 0.0
    resultados = {}

    for nome in args.motores.split(","):
        repo, prompt = MOTORES[nome]
        hotwords = None
        if isinstance(prompt, tuple):
            hotwords, prompt = prompt[1], None
        tipo = "int8_float16" if args.dispositivo == "cuda" else "int8"
        modelo = WhisperModel(repo, device=args.dispositivo, compute_type="int8" if args.dispositivo != "cuda" else tipo)
        hip, inicio, duracao_total = {}, time.time(), 0.0
        for a in amostras:
            segs, info = modelo.transcribe(
                str(a), language="pt", initial_prompt=prompt, hotwords=hotwords, beam_size=5,
                condition_on_previous_text=False, vad_filter=False,
            )
            hip[a.stem] = normalizar(" ".join(s.text for s in segs))
            duracao_total += info.duration
        tempo = time.time() - inicio

        r_txt = [refs[k] for k in hip]
        h_txt = [hip[k] for k in hip]
        rp = " ".join(r_txt).split()
        hp = " ".join(h_txt).split()
        resultados[nome] = {
            "wer_literal": round(jiwer.wer(r_txt, h_txt), 3),
            "hesitacoes_ref": contar(rp, HESITACOES),
            "hesitacoes_hip": contar(hp, HESITACOES),
            "ne_ref": contar(rp, MULETAS),
            "ne_hip": contar(hp, MULETAS),
            "repeticoes_ref": repeticoes(rp),
            "repeticoes_hip": repeticoes(hp),
            "tempo_s": round(tempo, 1),
            "fator_tempo_real": round(tempo / duracao_total, 2),
            "transcricoes": hip,
        }
        print(nome, {k: v for k, v in resultados[nome].items() if k != "transcricoes"}, flush=True)
        del modelo

    Path(args.saida).write_text(json.dumps({"referencias": refs, "motores": resultados},
                                           ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
