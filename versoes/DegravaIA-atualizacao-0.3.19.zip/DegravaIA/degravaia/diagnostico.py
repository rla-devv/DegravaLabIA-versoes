"""Instalação e conferência no PC do usuário.

    python -m degravaia baixar-modelos   baixa uma vez os modelos que faltam (sem token)
    python -m degravaia diagnostico      mostra o que o app encontrou: GPU, ffmpeg, modelos, fonte do PDF

Depois de baixados, os modelos ficam no computador e o app roda sem internet
(o "Degrava Lab.bat" liga o modo offline das bibliotecas).
"""
import os
import platform
import shutil
import sys
from pathlib import Path

from .config import MODELO_DIARIZACAO, MODELO_SEGUNDA_ESCUTA, MODELO_WHISPER, NOME_APP, VERSAO


def _linha(rotulo, ok, detalhe=""):
    print(f"  [{'OK' if ok else '!!'}] {rotulo}{': ' + detalhe if detalhe else ''}")
    return ok


def diagnostico():
    print(f"{NOME_APP} {VERSAO} — diagnóstico")
    tudo = True
    tudo &= _linha("Python", sys.version_info >= (3, 10), f"{platform.python_version()} ({platform.system()})")

    try:
        import ctranslate2

        n = ctranslate2.get_cuda_device_count()
        tudo &= _linha("Whisper (ctranslate2)", True, f"GPU NVIDIA: {'sim, ' + str(n) if n else 'não, usa a CPU'}")
    except Exception as e:
        tudo &= _linha("Whisper (ctranslate2)", False, str(e))

    try:
        import torch

        if torch.cuda.is_available():
            p = torch.cuda.get_device_properties(0)
            det = f"GPU {p.name}, {p.total_memory / 2**30:.1f} GB"
        else:
            det = "sem GPU, usa a CPU"
        tudo &= _linha("wav2vec2 e pyannote (torch)", True, f"{torch.__version__}; {det}")
    except Exception as e:
        tudo &= _linha("wav2vec2 e pyannote (torch)", False, str(e))

    try:
        from .audio import ffmpeg

        tudo &= _linha("ffmpeg", True, ffmpeg())
    except Exception as e:
        tudo &= _linha("ffmpeg", False, str(e))

    try:
        from .exportacao import _fontes_pdf

        tudo &= _linha("Fonte do PDF", True, _fontes_pdf()[0])
    except Exception as e:
        tudo &= _linha("Fonte do PDF", False, str(e))

    for modelo in (MODELO_WHISPER, MODELO_SEGUNDA_ESCUTA, MODELO_DIARIZACAO):
        problemas = problemas_do_modelo(modelo)
        tudo &= _linha(f"Modelo {modelo}", not problemas, "no computador" if not problemas else
                       "; ".join(problemas) + ' (dois cliques em "Degrava Lab.bat" baixam o que falta)')

    offline = os.environ.get("HF_HUB_OFFLINE") == "1"
    _linha("Modo offline das bibliotecas", offline, "ligado" if offline else 'desligado (o "Degrava Lab.bat" liga)')
    print("Tudo certo." if tudo else "Há itens marcados com !! acima.")
    return 0 if tudo else 1


# Os arquivos que cada modelo precisa e o tamanho de cada um na revisão conhecida. Sem conferir o
# tamanho, um download interrompido (3 GB do Whisper) passava por modelo pronto e a importação
# falhava depois com "Unable to open file 'model.bin'". Numa revisão mais nova, só se exige que os
# arquivos existam e não estejam vazios.
ARQUIVOS_MODELO = {
    MODELO_WHISPER: ("edaa852ec7e145841d8ffdb056a99866b5f0a478", {
        "config.json": 2394, "model.bin": 3087284237, "preprocessor_config.json": 340,
        "tokenizer.json": 2480617, "vocabulary.json": 1068114}),
    MODELO_SEGUNDA_ESCUTA: ("823dceb42ebafb67cb046d10957e261e5489b026", {
        "config.json": 1845, "preprocessor_config.json": 214, "pytorch_model.bin": 1262113269,
        "special_tokens_map.json": 85, "tokenizer_config.json": 138, "vocab.json": 421}),
}


def _pasta_do_modelo(modelo, cache=None):
    from huggingface_hub.constants import HF_HUB_CACHE

    return Path(cache or HF_HUB_CACHE) / ("models--" + modelo.replace("/", "--"))


def problemas_do_modelo(modelo, cache=None):
    """[] se o modelo está inteiro na pasta de modelos; senão, o que falta ou está pela metade."""
    pasta = _pasta_do_modelo(modelo, cache)
    try:
        revisao = (pasta / "refs" / "main").read_text("ascii").strip()
    except OSError:
        return ["não foi baixado"]
    if modelo == MODELO_DIARIZACAO:
        conhecida, arquivos = PYANNOTE_REVISAO, {rel: tam for rel, (_sha, tam) in PYANNOTE_ARQUIVOS.items()}
    else:
        conhecida, arquivos = ARQUIVOS_MODELO[modelo]
    problemas = []
    for rel, tamanho in arquivos.items():
        try:
            atual = (pasta / "snapshots" / revisao / rel).stat().st_size  # segue o atalho, se houver
        except OSError:
            problemas.append(f"falta {rel}")
            continue
        if atual == 0 or (revisao == conhecida and atual != tamanho):
            problemas.append(f"{rel} incompleto ({atual:,} de {tamanho:,} bytes)".replace(",", "."))
    return problemas


def _no_computador(modelo, cache=None):
    return not problemas_do_modelo(modelo, cache)


def apagar_incompletos(modelo):
    """Apaga os arquivos do modelo com tamanho errado, para o próximo download trazê-los de novo
    (a biblioteca do Hugging Face não baixa de novo um arquivo que já está na pasta)."""
    pasta = _pasta_do_modelo(modelo)
    try:
        revisao = (pasta / "refs" / "main").read_text("ascii").strip()
    except OSError:
        return
    conhecida, arquivos = ARQUIVOS_MODELO.get(modelo, (None, {}))
    for rel, tamanho in arquivos.items():
        arquivo = pasta / "snapshots" / revisao / rel
        try:
            atual = arquivo.stat().st_size
        except OSError:
            continue
        if atual == 0 or (revisao == conhecida and atual != tamanho):
            real = Path(os.path.realpath(arquivo))
            print(f"  {rel} estava incompleto: será baixado de novo.", flush=True)
            arquivo.unlink(missing_ok=True)
            if real != arquivo:
                real.unlink(missing_ok=True)


def _pastas_com_modelos():
    """Outros lugares deste PC onde os modelos podem já ter sido baixados."""
    from huggingface_hub.constants import HF_HUB_CACHE

    destino = Path(HF_HUB_CACHE).resolve()
    candidatos = [Path.home() / ".cache" / "huggingface" / "hub"]  # pasta padrão do Hugging Face
    raiz = destino.parent.parent  # .../Degrava Lab (quando os modelos ficam em DegravaIA/modelos)
    for base in (raiz.parent, raiz.parent.parent):  # outras cópias do Degrava Lab ao lado desta
        candidatos += list(base.glob("*/modelos/hub")) + list(base.glob("*/*/modelos/hub"))
    vistos = []
    for c in candidatos:
        try:
            c = c.resolve()
        except OSError:
            continue
        if c.is_dir() and c != destino and c not in vistos:
            vistos.append(c)
    return destino, vistos


def _copiar(origem, destino):
    """Copia um modelo já baixado. Segue os atalhos (links simbólicos) da pasta do Hugging Face
    e leva só refs/ e snapshots/ com os arquivos de verdade, o mesmo formato que ele usa no
    Windows sem atalhos. No mesmo disco usa links físicos (não ocupa espaço de novo)."""
    def ligar(a, b):
        real = os.path.realpath(a)  # o arquivo de verdade por trás do atalho
        try:
            os.link(real, b)
        except OSError:
            shutil.copy2(real, b)

    if destino.exists():  # cópia anterior incompleta: refaz do zero (é a pasta do próprio app)
        shutil.rmtree(destino)
    for parte in ("refs", "snapshots"):
        if (origem / parte).is_dir():
            shutil.copytree(origem / parte, destino / parte, symlinks=False, copy_function=ligar)


def reaproveitar_modelos():
    """Antes de baixar, procura os modelos já baixados em outro lugar do PC e copia de lá."""
    destino, origens = _pastas_com_modelos()
    for modelo in (MODELO_WHISPER, MODELO_SEGUNDA_ESCUTA, MODELO_DIARIZACAO):
        if _no_computador(modelo):
            continue
        nome = "models--" + modelo.replace("/", "--")
        for origem in origens:
            if (origem / nome).is_dir() and _no_computador(modelo, origem):  # só cópia inteira
                print(f"Reaproveitando {modelo} já baixado em {origem} …", flush=True)
                _copiar(origem / nome, destino / nome)
                if _no_computador(modelo):
                    break
                shutil.rmtree(destino / nome, ignore_errors=True)  # cópia que não deu certo: baixa


# os arquivos que o faster-whisper usa (faster_whisper.utils.download_model)
ARQUIVOS_WHISPER = ["config.json", "preprocessor_config.json", "model.bin", "tokenizer.json", "vocabulary.*"]


def _gb(n):
    return f"{n / 2**30:.2f}".replace(".", ",")


def baixar_com_andamento(modelo, padroes=None):
    """snapshot_download com uma linha de andamento que se atualiza: GB baixados, velocidade e
    quanto falta (medidos pelo tamanho dos arquivos na pasta do modelo)."""
    import fnmatch
    import threading
    import time

    from huggingface_hub import HfApi, snapshot_download
    from huggingface_hub.constants import HF_HUB_CACHE

    try:
        info = HfApi().model_info(modelo, files_metadata=True)
        total = sum(s.size or 0 for s in info.siblings
                    if padroes is None or any(fnmatch.fnmatch(s.rfilename, p) for p in padroes))
    except Exception:
        total = 0
    pasta = Path(HF_HUB_CACHE) / ("models--" + modelo.replace("/", "--"))
    erro = []

    def baixar():
        try:
            snapshot_download(modelo, allow_patterns=padroes)
        except BaseException as e:  # noqa: BLE001 (repassado abaixo)
            erro.append(e)

    def no_disco():
        try:
            return sum(f.stat().st_size for f in pasta.rglob("*") if f.is_file() and not f.is_symlink())
        except OSError:
            return 0

    inicio_bytes, inicio = no_disco(), time.monotonic()
    tarefa = threading.Thread(target=baixar, daemon=True)
    tarefa.start()
    while tarefa.is_alive():
        tarefa.join(2)
        feito = no_disco()
        passado = time.monotonic() - inicio
        velocidade = (feito - inicio_bytes) / passado if passado > 0 else 0
        linha = f"  {_gb(feito)} GB"
        if total:
            linha += f" de {_gb(total)} GB ({min(100, int(100 * feito / total))}%)"
        if velocidade > 0:
            linha += f" · {velocidade / 2**20:.1f} MB/s".replace(".", ",")
            if total and feito < total:
                falta = (total - feito) / velocidade
                linha += " · falta " + (f"cerca de {int(falta // 60) + 1} min" if falta >= 60 else "menos de 1 min")
        print("\r" + linha.ljust(70), end="", flush=True)
    print("\r" + f"  Pronto: {_gb(no_disco())} GB".ljust(70), flush=True)
    if erro:
        raise erro[0]


# O modelo de interlocutores, copiado sem alterações para o repositório público de versões: no
# Hugging Face ele só sai com token. A licença (CC-BY-4.0) permite redistribuir com o crédito abaixo.
PYANNOTE_REVISAO = "3533c8cf8e369892e6b79ff1bf80f7b0286a54ee"
PYANNOTE_ARQUIVOS = {  # caminho no modelo: (SHA-256, tamanho)
    "README.md": ("2db91f9265bd81f1653ff088b5bff22bf6aebebea03328513af65501643f8a31", 9978),
    "config.yaml": ("5ce2bfa9a938dc132cec1172592d65173cbb8f444ea1e4133f10f9391de155be", 444),
    "embedding/pytorch_model.bin": ("6f10ff60898a1d185fa22e1d11e0bfa8a92efec811f11bca48cb8cafebefd929", 26646242),
    "plda/plda.npz": ("9b77bcd840692710dd3496f62ecfeed8d8e5f002fd991b785079b244eab7d255", 133852),
    "plda/xvec_transform.npz": ("325f1ce8e48f7e55e9c8aa47e05d2766b7c48c4b25b8de8dd751e7a4cc5fbe8f", 134376),
    "segmentation/pytorch_model.bin": ("7ad24338d844fb95985486eb1a464e32d229f6d7a03c9abe60f978bacf3f816e", 5906507),
}
PYANNOTE_PASTA = "modelos/pyannote-community-1"  # no repositório de versões
CREDITO_PYANNOTE = f"""{MODELO_DIARIZACAO}, sem alterações: https://huggingface.co/{MODELO_DIARIZACAO}
Autores: pyannote (Hervé Bredin e colaboradores), https://github.com/pyannote/pyannote-audio
Licença: CC-BY-4.0, https://creativecommons.org/licenses/by/4.0/
"""


def baixar_pyannote():
    """Baixa o modelo de interlocutores do repositório de versões, conferindo cada arquivo, para a
    pasta de modelos no mesmo formato do Hugging Face (o pyannote o encontra ali, sem internet)."""
    from huggingface_hub.constants import HF_HUB_CACHE

    from .atualizacao import baixar_conferido
    from .config import REPO_VERSOES

    pasta = Path(HF_HUB_CACHE) / ("models--" + MODELO_DIARIZACAO.replace("/", "--"))
    for rel, (sha, _tamanho) in PYANNOTE_ARQUIVOS.items():
        baixar_conferido(f"https://raw.githubusercontent.com/{REPO_VERSOES}/main/{PYANNOTE_PASTA}/{rel}",
                         pasta / "snapshots" / PYANNOTE_REVISAO / rel, sha)
    (pasta / "refs").mkdir(parents=True, exist_ok=True)
    (pasta / "refs" / "main").write_text(PYANNOTE_REVISAO, "ascii")  # por último: só agora o modelo "existe"
    (Path(HF_HUB_CACHE).parent / "LICENCA-pyannote.txt").write_text(CREDITO_PYANNOTE, "utf-8")


def baixar_modelos():
    """Baixa os modelos que faltam (ou reaproveita os já baixados). Nenhum pede token:
    o pyannote vem do repositório de versões."""
    # avisos que só assustam: no Windows sem "modo de desenvolvedor" os modelos são guardados como
    # arquivos comuns (sem links simbólicos), e o download é feito sem conta, como deve ser
    os.environ.setdefault("HF_HUB_DISABLE_SYMLINKS_WARNING", "1")
    os.environ.setdefault("HF_HUB_VERBOSITY", "error")
    # download clássico (sem o "xet"): o arquivo cresce na pasta e dá para mostrar o andamento em GB;
    # as barras da biblioteca contam arquivos, e o modelo é um arquivo só de 3 GB (ficaria parada)
    os.environ.setdefault("HF_HUB_DISABLE_XET", "1")
    os.environ.setdefault("HF_HUB_DISABLE_PROGRESS_BARS", "1")
    import warnings

    warnings.filterwarnings("ignore", message=".*symlinks.*")
    warnings.filterwarnings("ignore", message=".*unauthenticated.*")
    from huggingface_hub import snapshot_download

    reaproveitar_modelos()
    for modelo in (MODELO_WHISPER, MODELO_SEGUNDA_ESCUTA):
        apagar_incompletos(modelo)
    if all(_no_computador(m) for m in (MODELO_WHISPER, MODELO_SEGUNDA_ESCUTA, MODELO_DIARIZACAO)):
        print("Os três modelos já estão no computador: nada a baixar.")
        return 0
    # primeiro os dois modelos livres, que não precisam de token
    if not _no_computador(MODELO_WHISPER):
        print("Baixando o modelo de transcrição (Whisper large-v3, cerca de 3 GB). Pode levar de 5 a 30 minutos,")
        print("conforme a internet; a barra abaixo mostra o andamento.", flush=True)
        # os mesmos arquivos que o faster-whisper baixa, mas com a barra de progresso (ele a esconde)
        baixar_com_andamento(MODELO_WHISPER, ARQUIVOS_WHISPER)
    if not _no_computador(MODELO_SEGUNDA_ESCUTA):
        print("Baixando o modelo da segunda escuta (wav2vec2, cerca de 1,3 GB) …", flush=True)
        baixar_com_andamento(MODELO_SEGUNDA_ESCUTA)
    if not _no_computador(MODELO_DIARIZACAO):
        print("Baixando o modelo de interlocutores (pyannote, 32 MB) …", flush=True)
        if os.environ.get("HF_TOKEN"):  # quem desenvolve: direto do Hugging Face
            snapshot_download(MODELO_DIARIZACAO, token=os.environ["HF_TOKEN"])
        else:
            baixar_pyannote()
    faltando = {m: problemas_do_modelo(m) for m in (MODELO_WHISPER, MODELO_SEGUNDA_ESCUTA, MODELO_DIARIZACAO)}
    if any(faltando.values()):
        for modelo, problemas in faltando.items():
            if problemas:
                print(f"O modelo {modelo} não ficou completo: {'; '.join(problemas)}.")
        print("Confira a internet e o espaço livre no disco e rode a instalação de novo: ela continua de onde parou.")
        return 1
    print("Modelos no computador. Daqui em diante o app funciona sem internet.")
    return 0
