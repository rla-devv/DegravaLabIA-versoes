# Teste dos motores — rodada 1 (CPU, int8)

**Amostras:** 12 trechos (117 s) de 12 entrevistas diferentes do corpus público
CORAA-MuPe (fala espontânea em português, transcrição de referência literal).

| Motor | Erro literal | Hesitações (eh/ah) | "né" | Repetições | Tempo (× duração) |
|---|---|---|---|---|---|
| Whisper large-v3 | 29,3% | 0 / 13 | 1 / 5 | 3 / 44 | 1,97× |
| **Whisper large-v3 + prompt** | **23,5%** | 3 / 13 | 6 / 5 ⚠️ | **17 / 44** | 2,36× |
| Whisper turbo + prompt | 30,5% | **9 / 13** | 6 / 5 ⚠️ | 7 / 44 | **1,54×** |
| CrisperWhisper | 136,7% ❌ | 0 / 13 | 0 / 5 | 259 / 44 ❌ | 30,4× |

## Conclusões
1. **Whisper padrão "limpa" a fala**: confirma a ressalva do requisito crítico.
2. **CrisperWhisper está descartado para português.** Ele foi treinado em inglês
   e alemão e entrou em laço em português ("eu eu eu eu…" centenas de vezes),
   além de ser 30× mais lento.
3. **large-v3 + prompt** é o melhor no geral, mas ainda perde a maioria das
   hesitações "eh".
4. ⚠️ **Risco de inserção:** os motores com prompt escreveram palavras ausentes
   da referência (ex.: "né" a mais, "a coisa" no trecho 03). Isso pode ser erro
   do motor ou omissão da referência humana; só ouvindo é possível saber. Para o
   app, reforça os itens 3 e 4 dos requisitos (sugestão + destaque de baixa
   confiança + revisão humana).
5. O erro literal está inflado porque a referência do corpus padroniza formas
   coloquiais ("estava" no lugar de "tava"). Os motores com prompt escrevem
   "tava/pra/tá", que provavelmente é **o que foi dito de fato**.

Detalhe de cada trecho: `resultados.json`.

# Rodada 2: wav2vec2-CORAA (Apache 2.0) e "segunda escuta"

| Configuração | Erro literal | Hesitações | "né" | Repetições | Tempo |
|---|---|---|---|---|---|
| wav2vec2 sozinho | 29,3% | 3 / 13 | 6 / 5 | **24 / 44** | **0,21×** |
| Whisper large-v3 + prompt | 23,5% | 3 / 13 | 6 / 5 | 17 / 44 | 2,36× |
| **Whisper + sugestões do wav2vec2 aceitas** | **22,0%** | 4 / 13 | 6 / 5 | 23 / 44 | +0,21× |

- **Sugestões geradas pela segunda escuta: 7, todas corretas (100%).**
- **O "né" a mais provavelmente é real.** No trecho 10, os dois motores, que
  funcionam de formas diferentes, ouviram de forma independente "a caminha
  **né** às vezes", e a referência humana não tem esse "né". O mais provável é
  omissão do transcritor do corpus, não invenção do Whisper. Só ouvindo para
  confirmar.
- O wav2vec2 ouve mais "eh" do que o placar mostra, mas escreve de forma
  irregular ("eeh", "e", "ea"), e por isso não é bom como texto principal.
- Sozinho, o wav2vec2 erra mais palavras comuns ("bairro" no lugar de
  "barro", "mêmo").

## Recomendação
- **Motor principal:** Whisper large-v3 + prompt de hesitações.
- **Segunda escuta:** wav2vec2-CORAA. É rápido (0,2× a duração), gera
  sugestões de hesitação/repetição para o usuário decidir, e os pontos em
  que os dois motores **discordam** alimentam o destaque de baixa confiança
  (item 4).
- **Memória na GTX 1650:** large-v3 int8 (~2 GB) e wav2vec2 (~1,3 GB) rodam
  em sequência, um de cada vez, e cabem nos 4 GB. A confirmar com
  `nvidia-smi` no seu PC.

Detalhe por trecho: `resultados_rodada2.json`.

# Rodada 3: prompt em áudios longos

O `initial_prompt` do faster-whisper **só vale para a primeira janela de 30 s**
quando `condition_on_previous_text=False` (o código descarta o prompt depois do
primeiro segmento). Os trechos de teste tinham menos de 30 s, então as rodadas
1 e 2 são válidas, mas num depoimento longo o efeito sumiria.

O parâmetro `hotwords` reinsere o mesmo texto **em toda janela**:

| Configuração | Erro literal | Hesitações | "né" | Repetições |
|---|---|---|---|---|
| large-v3 + initial_prompt | 23,5% | 3 / 13 | 6 / 5 | 17 / 44 |
| large-v3 + hotwords | 24,6% | 3 / 13 | 6 / 5 | 15 / 44 |

Resultado equivalente. **O app usa `hotwords`.**

# Rodada 4: identificação de interlocutores (Etapa 1)

**Amostras:** duas "conversas" montadas com falas de entrevistas diferentes do
CORAA-MuPe (`interlocutores.py montar`), cada uma com cerca de 2 min 10 s e o
gabarito de quem fala em cada trecho. O volume de cada fala foi igualado, para
o modelo não separar as pessoas pela altura da gravação.
- **Conversa 2:** mulher de 41 anos + homem de 68 (15 trocas de interlocutor).
- **Conversa 3:** mulher de 20 + mulher de 22 + homem de 45 (17 trocas). É o
  caso difícil: duas vozes femininas jovens.

| Configuração | Palavras na pessoa certa (2 vozes) | (3 vozes) | Erro literal (2 / 3) |
|---|---|---|---|
| Whisper no áudio inteiro, depois pyannote | 93,0% | 83,5% | 29,9% / 16,5% |
| **pyannote primeiro, Whisper por turno de fala** | **97,2%** | 82,2% | **25,5% / 14,8%** |

- **O pyannote acerta as vozes.** Sozinho, nos trechos em que marcou fala, deu
  a voz certa em ~97% do tempo com 2 pessoas e ~86% com 3. As confusões são
  entre as duas mulheres jovens. Sem `--falantes`, ele contou 3 vozes
  sozinho na conversa 3.
- **O problema estava no Whisper rodando no áudio inteiro:**
  - **omitiu uma frase inteira** (00:32, "tinha ruas esburacadas ali, tinha ali
    o viaduto do Chá, né"), que o wav2vec2 ouviu. Para cobrir o buraco,
    esticou o tempo das palavras seguintes, que caíram na pessoa errada;
  - **repetiu uma frase não dita** (01:07, "O que que a gente passou com o
    André?" duas vezes) com as 9 palavras empilhadas no mesmo instante e
    probabilidade alta, o que escaparia do destaque de baixa confiança.
- **Correção adotada (sem ferramenta nova):** o pyannote roda primeiro e o
  Whisper recebe só os turnos de fala (`clip_timestamps` do faster-whisper),
  sem sobreposição entre trechos. A frase omitida voltou, a repetição sumiu e
  todas as 15 trocas da conversa 2 viraram fala nova.
- **Proteções extras:**
  - 3 ou mais palavras seguidas com duração zero ficam marcadas como
    **suspeitas** (destaque na revisão, nunca removidas);
  - palavras que o wav2vec2 ouviu **fora** dos turnos (fala que o pyannote não
    viu e que, portanto, o Whisper não recebeu) geram aviso e ficam guardadas
    para a revisão.
- **Ressalvas do teste:**
  - alguns trechos do corpus marcados como do entrevistado têm a voz do
    **entrevistador** dentro (ex.: "por que você queria fazer científico?"), o
    que derruba artificialmente o placar de 3 vozes;
  - as falas vêm de gravações diferentes, o que facilita a separação em
    relação a uma gravação real única;
  - é preciso confirmar com um áudio real seu.

# Rodada 5: quando uma palavra vira [ininteligível] (Etapa 3, item 3)

**Amostras:** 140 trechos do CORAA-MuPe, 70 de áudio bom e 70 de áudio ruim
(`calibrar_confianca.py`), com 1.831 palavras comparadas à referência humana.
Antes de comparar, igualei as formas coloquiais (tava/estava, pra/para…) e
deixei os números de fora, para não punir o motor por escrever o que foi dito.

- Erro do Whisper: 8,2% no áudio bom e 18,8% no ruim.
- **Quando o Whisper e o wav2vec2 ouvem a mesma palavra, ela está errada só em
  5,6% dos casos**, contra 13,1% no geral. A concordância entre os motores vale
  mais que a nota de certeza.

| Regra | Limite | Viram marcação | Delas, erradas | Erros pegos | Palavras certas escondidas |
|---|---|---|---|---|---|
| só certeza | < 0,20 | 4,3% | 51% | 16,7% | 2,4% |
| só certeza | < 0,40 | 8,0% | 44% | 27,2% | 5,2% |
| **certeza baixa + motores discordam** | **< 0,40** | 3,1% | **81%** | 19,2% | **0,7%** |
| certeza baixa + motores discordam | < 0,50 | 4,0% | 74% | 23,0% | 1,2% |

**Regra adotada:** a palavra sai do texto e vira `[ininteligível HH:MM:SS]` (o
texto dos motores fica como sugestão) quando a certeza é **menor que 0,40 e a
segunda escuta ouviu outra coisa**, ou quando é suspeita de trecho inventado.
Sem segunda escuta (idioma que não seja o português), vale só certeza < 0,05
(73% de acerto).

- **Comparação dos motores:** antes de decidir se concordam, igualo grafias
  diferentes do mesmo som (pra/para, ahn/ah, quê/que) e palavras que o wav2vec2
  grudou ("ebem" = "e bem"). "a" e "e" sozinhos contam como palavras, não
  como hesitação.
- **Ressalva:** a referência do corpus padroniza a fala, então parte do "erro"
  é o motor escrevendo o que foi dito. A precisão real deve ser maior que a da
  tabela.
- **O resto continua com você:** os 81% de erros que a regra não pega seguem
  com o destaque de baixa certeza (item 4) para você ouvir na revisão.

# Rodada 6: a melhoria de áudio (item 6) ajuda a transcrição?

**Amostras:** 50 dos trechos da rodada 5 (10 de áudio bom, 40 de áudio ruim),
transcritos de novo depois de cada nível de melhoria do app (filtros do ffmpeg:
`highpass`, `afftdn`, `loudnorm`; `melhoria.py`).

| Áudio | Trechos | Sem melhoria | Leve | Médio | Forte |
|---|---|---|---|---|---|
| bom | 10 | **11,2%** | 11,8% | 14,2% | 18,9% |
| ruim | 40 | 25,4% | 23,5% | **22,5%** | 27,7% |

Erro literal (menor é melhor). Hesitações escritas no áudio ruim, contra 4
na referência: sem melhoria 4, leve 5, médio **0**, forte 2.

- **Áudio bom:** todo nível piora, e o forte piora muito.
- **Áudio ruim:** leve e médio melhoram 2 a 3 pontos, dentro da variação
  esperada para 40 trechos curtos. O médio apagou todas as hesitações, o que
  vai contra a literalidade. O forte piora.

**Decisão:** quando ligada na importação, a cópia melhorada serve **só para
ouvir** na revisão, com uma chave para alternar com o original. A transcrição
automática continua sobre o áudio original. Para um trecho ruim específico, a
ajuda por trecho (item 11) reanalisa numa cópia melhorada só daquele pedaço, e o
resultado vira sugestão para o usuário decidir.

# Versões do Python (18/10/2026)

O `pip` resolveu os pacotes prontos que um Windows 64 bits baixaria, sem
compilar nada:

| Biblioteca | Python 3.14 | Python 3.15 |
|---|---|---|
| torch | sim | sim |
| torchaudio, torchcodec (áudio da separação de vozes) | sim | **não** |
| ctranslate2 (motor do Whisper), av | sim | **não** |
| onnxruntime (separação de vozes) | sim | **não** |
| demais (pyannote, transformers, exportação) | sim | sim |

No **3.14**, o app inteiro foi testado: instalação, 19 testes automáticos,
diagnóstico, importação real (texto idêntico ao do 3.13) e exportação nos
cinco formatos. O `instalar.py` aceita do 3.10 ao 3.14 e, se faltar, instala
o 3.14. O **3.15** fica para quando essas bibliotecas lançarem versões para
ele; aí basta aumentar o limite no `instalar.py`.
