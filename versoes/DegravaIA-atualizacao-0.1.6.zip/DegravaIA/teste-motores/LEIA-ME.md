# Teste dos motores de transcrição: como repetir no seu PC (Windows)

Tudo roda **offline** depois do primeiro download dos modelos. O seu material
real nunca sai do computador.

## 1. Instalar (uma vez)
1. Instale o **Python 3.11 ou 3.12** (python.org), marcando "Add Python to PATH".
2. Abra o **Prompt de Comando** nesta pasta (`teste-motores`) e rode:
   ```
   python -m venv .venv
   .venv\Scripts\pip install faster-whisper jiwer "av<16"
   ```
3. **Só na máquina com a GTX 1650:** instale o driver NVIDIA atualizado e,
   em seguida:
   ```
   .venv\Scripts\pip install nvidia-cublas-cu12 nvidia-cudnn-cu12==9.*
   ```

## 2. Preparar as amostras
Crie a pasta `minhas-amostras` e coloque nela pares de arquivos:
- `trecho01.wav` (ou .mp3): um trecho de 10 a 30 segundos;
- `trecho01.txt`: a transcrição **literal** feita por você, com todos os
  "eh", "né", repetições etc.

De 10 a 20 trechos variados (áudio bom, ruim, telefone, ambiente) já bastam.

## 3. Rodar
Máquina sem GPU:
```
.venv\Scripts\python comparar.py --amostras minhas-amostras --dispositivo cpu
```
Máquina com GTX 1650:
```
.venv\Scripts\python comparar.py --amostras minhas-amostras --dispositivo cuda
```
Na GTX 1650, abra outro Prompt e rode `nvidia-smi -l 2` durante o teste
para ver a memória de vídeo usada (o limite é 4096 MiB).

## 4. Ler o resultado
Para cada motor, o script imprime:
- `wer_literal`: taxa de erro contra a sua transcrição literal (menor é melhor);
- `hesitacoes_ref / hesitacoes_hip`: quantos "eh/ah/hum" existem e quantos o motor manteve;
- `ne_ref / ne_hip`: o mesmo para "né";
- `repeticoes_ref / repeticoes_hip`: palavras repetidas ("do do do");
- `fator_tempo_real`: 1,0 = leva o mesmo tempo do áudio; 0,5 = metade.

O detalhe de cada transcrição fica em `resultados.json`.
