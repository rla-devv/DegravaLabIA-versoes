@echo off
rem Degrava IA - na primeira vez baixa e instala o que falta (precisa de internet so entao); depois, abre o app.
rem Tudo fica nesta pasta: o Python portatil oficial (python.org) vai para "python"; nada e instalado no Windows.
rem Opcoes: "Degrava IA.bat" instalar | diagnostico | --navegador
cd /d "%~dp0"
if exist "python\python.exe" if exist "degravaia\config.py" goto rodar
echo Degrava IA - primeira vez: baixando o que falta (precisa de internet so agora).
echo.
set "DEGRAVAIA_PASTA=%~dp0"
set "DEGRAVAIA_BAT=%~f0"
powershell -NoProfile -ExecutionPolicy Bypass -Command "$s = [IO.File]::ReadAllText($env:DEGRAVAIA_BAT); iex $s.Substring($s.IndexOf('#' + 'POWERSHELL'))"
if errorlevel 1 goto erro
if not exist "python\python.exe" goto erro
if not exist "degravaia\config.py" goto erro
:rodar
rem num bloco: o cmd le a linha inteira antes de rodar, e uma atualizacao que troque este arquivo nao o atrapalha
("python\python.exe" -m degravaia.abrir %* & exit /b)
:erro
echo.
echo A instalacao nao terminou. Confira a internet e abra o "Degrava IA.bat" de novo.
echo Se continuar, mande um print desta janela.
pause
exit /b 1

#POWERSHELL - daqui para baixo o .bat entrega ao PowerShell (o cmd nunca chega aqui)
# 1. Python portatil oficial (python.org), conferido pelo SHA-256 abaixo (o do arquivo publicado).
# 2. O codigo do Degrava IA: a versao mais nova publicada, pelo mesmo caminho conferido das atualizacoes
#    (atualizacao.json -> pacote com SHA-256 -> versao escrita dentro do pacote).
# Cada download vai para um arquivo .novo e so entra no lugar depois de conferido.
$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
[Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12
$pasta = $env:DEGRAVAIA_PASTA
$repo = 'https://raw.githubusercontent.com/rla-devv/degravaia-versoes/main/'
$pythonUrl = 'https://www.python.org/ftp/python/3.14.8/python-3.14.8-embed-amd64.zip'
$pythonSha = 'a93abe456ab01bd96d7a085b3cdb6566b3063f4241360d114142fbdb07f0a310'
$cabecalho = @{ 'User-Agent' = 'DegravaIA-instalador' }

function Baixar($url, $destino, $sha) {
    $novo = "$destino.novo"
    Invoke-WebRequest -UseBasicParsing -Uri $url -OutFile $novo -Headers $cabecalho
    if ((Get-FileHash -Algorithm SHA256 -LiteralPath $novo).Hash.ToLower() -ne $sha) {
        Remove-Item -LiteralPath $novo
        throw "o arquivo baixado nao confere com o SHA-256 esperado ($url)"
    }
    Move-Item -Force -LiteralPath $novo -Destination $destino
}

try {
    if (-not (Test-Path -LiteralPath (Join-Path $pasta 'python\python.exe'))) {
        Write-Host 'Baixando o Python portatil oficial (python.org, 11 MB)...'
        $zip = Join-Path $pasta 'python-portatil.zip'
        Baixar $pythonUrl $zip $pythonSha
        Expand-Archive -Force -LiteralPath $zip -DestinationPath (Join-Path $pasta 'python')
        Remove-Item -LiteralPath $zip
        # liga o pip (import site) e deixa o Python enxergar o codigo do Degrava IA (..)
        Get-ChildItem -LiteralPath (Join-Path $pasta 'python') -Filter '*._pth' | ForEach-Object {
            [IO.File]::WriteAllText($_.FullName, "python314.zip`r`n.`r`nLib\site-packages`r`n..`r`nimport site`r`n")
        }
    }
    if (-not (Test-Path -LiteralPath (Join-Path $pasta 'degravaia\config.py'))) {
        Write-Host 'Baixando o Degrava IA (versao mais recente)...'
        $agora = [DateTimeOffset]::UtcNow.ToUnixTimeSeconds()
        $m = (Invoke-WebRequest -UseBasicParsing -Uri "${repo}atualizacao.json?t=$agora" -Headers $cabecalho).Content | ConvertFrom-Json
        if ($m.versao -notmatch '^\d+\.\d+\.\d+$' -or $m.arquivo -notmatch '^[A-Za-z0-9._-]+\.zip$' -or $m.sha256 -notmatch '^[0-9a-f]{64}$') {
            throw 'o atualizacao.json publicado nao esta no formato esperado'
        }
        $zip = Join-Path $pasta 'degravaia-codigo.zip'
        Baixar "${repo}versoes/$($m.arquivo)" $zip $m.sha256
        $tmp = Join-Path $pasta '.instalacao'
        if (Test-Path -LiteralPath $tmp) { Remove-Item -Recurse -Force -LiteralPath $tmp }
        Expand-Archive -LiteralPath $zip -DestinationPath $tmp
        $origem = Join-Path $tmp 'DegravaIA'
        $config = [IO.File]::ReadAllText((Join-Path $origem 'degravaia\config.py'))
        if ($config -notmatch ('(?m)^VERSAO = "' + [regex]::Escape($m.versao) + '"')) {
            throw 'a versao dentro do pacote nao e a anunciada'
        }
        # arquivo por arquivo (o proprio .bat fica: e este que esta rodando)
        Get-ChildItem -LiteralPath $origem -Recurse -File -Force | ForEach-Object {
            $rel = $_.FullName.Substring($origem.Length).TrimStart('\', '/')
            if ($rel -ne 'Degrava IA.bat') {
                $destino = Join-Path $pasta $rel
                New-Item -ItemType Directory -Force -Path (Split-Path -Parent $destino) | Out-Null
                Copy-Item -Force -LiteralPath $_.FullName -Destination $destino
            }
        }
        Remove-Item -Recurse -Force -LiteralPath $tmp
        Remove-Item -LiteralPath $zip
        Write-Host "Degrava IA $($m.versao) baixado."
    }
} catch {
    Write-Host ''
    Write-Host "Nao foi possivel baixar: $($_.Exception.Message)"
    exit 1
}
