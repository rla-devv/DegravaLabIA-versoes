"""Degrava IA em janela própria do Windows (o atalho da Área de Trabalho abre este arquivo).

Mesmo modelo do RealceIA:
    atalho "Degrava IA" ─► python\\pythonw.exe degravaia.pyw   (pythonw: sem a janela preta)
        1. abre a janela (pywebview → WebView2, o componente do Edge que vem no Windows 10 e 11)
           mostrando "Abrindo o Degrava IA…";
        2. sobe o servidor do app em segundo plano, só neste computador (127.0.0.1);
        3. quando ele fica pronto, a janela carrega a tela;
        4. fechou a janela → encerra o servidor e o programa.
    Enquanto aberto, o ícone fica na bandeja do sistema (perto do relógio), com
    "Abrir o Degrava IA" e "Fechar o Degrava IA"; um clique traz a janela para a frente.

As mensagens vão para registro.txt. Se o servidor cair, ele é aberto de novo sozinho (e a
tela se reconecta); depois de uma atualização, abre a versão nova.
Sem o pywebview ou sem o WebView2, ou com --navegador, abre como antes: janela preta e
navegador (abrir.py).
"""
import os
import subprocess
import sys
import threading
import time
from pathlib import Path
from urllib.request import urlopen

sys.path.insert(0, str(Path(__file__).resolve().parent))
from abrir import GRUPO_PROPRIO, REINICIAR, abrir_registro, anotar  # noqa: E402
from instalar import AQUI, ambiente_nvidia, python_do_app  # noqa: E402

PORTA = 8765
ENDERECO = f"http://127.0.0.1:{PORTA}/"
SEM_CONSOLE = 0x08000000 if os.name == "nt" else 0  # CREATE_NO_WINDOW: o servidor não abre janela preta
DADOS_JANELA = AQUI / "dados-janela"  # tema, guia fechado… (o que a página guarda no navegador)

ESTILO = """<style>html,body{height:100%;margin:0;background:#09142c;color:#e6f0ee;
font-family:"Segoe UI",system-ui,sans-serif}body{display:grid;place-items:center}
.caixa{text-align:center;max-width:560px;padding:24px}.logo{width:112px;height:112px;margin:0 auto 10px;
display:block}.giro{width:28px;height:28px;margin:18px auto 0;border-radius:50%;
border:3px solid #1c3354;border-top-color:#5af0ff;animation:g 1s linear infinite}
@keyframes g{to{transform:rotate(360deg)}}p{color:#9fb3c8;line-height:1.5}code{color:#5af0ff}</style>"""
def _logo():
    """O ícone do app embutido na página (a janela ainda não tem servidor para buscá-lo)."""
    import base64

    try:
        dados = (AQUI / "degravaia" / "web" / "icone.png").read_bytes()
        return f'<img class="logo" alt="" src="data:image/png;base64,{base64.b64encode(dados).decode()}">'
    except OSError:
        return ""


LOGO = _logo()
CARREGANDO = f"""<!doctype html><meta charset="utf-8">{ESTILO}<div class="caixa">{LOGO}
<h2>Abrindo o Degrava IA…</h2><p>Tudo roda no seu computador. Nenhum dado é enviado para a internet.</p>
<div class="giro"></div></div>"""


def pagina_de_erro(texto):
    return f"""<!doctype html><meta charset="utf-8">{ESTILO}<div class="caixa">{LOGO}
<h2>Não foi possível abrir o Degrava IA</h2><p>{texto}</p>
<p>O detalhe está no arquivo <code>registro.txt</code>, na pasta do Degrava IA:<br><code>{AQUI}</code></p>
<p>Feche esta janela e tente de novo. Se continuar, envie o registro.txt para o suporte.</p></div>"""


def no_ar():
    try:
        with urlopen(ENDERECO + "api/projetos", timeout=1) as r:
            return r.status == 200
    except Exception:
        return False


class Servidor:
    """Roda `python -m degravaia revisar` sem janela, grava a saída no registro e o reabre se
    cair ou se uma atualização pedir (mesma lógica do abrir.py)."""

    def __init__(self, registro):
        self.registro = registro
        self.proc = None
        self.fechando = False
        self.desistiu = False

    def iniciar(self):
        threading.Thread(target=self._vigiar, daemon=True).start()

    def _rodar(self):
        self.proc = subprocess.Popen(
            [str(python_do_app()), "-u", "-m", "degravaia", "revisar", "--nao-abrir", "--porta", str(PORTA)],
            env=dict(ambiente_nvidia(), DEGRAVAIA_JANELA="1"), cwd=AQUI, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True,
            encoding="utf-8", errors="replace", creationflags=GRUPO_PROPRIO | SEM_CONSOLE)
        for linha in self.proc.stdout:
            self.registro.write(f"{time.strftime('%Y-%m-%d %H:%M:%S')} {linha}")
            self.registro.flush()
        return self.proc.wait()

    def _vigiar(self):
        quedas = []
        while not self.fechando:
            codigo = self._rodar()
            if self.fechando:
                return
            if codigo == REINICIAR:
                anotar(self.registro, "Abrindo a versão nova…")
                continue
            quedas = [t for t in quedas if time.time() - t < 600] + [time.time()]
            anotar(self.registro, f"O programa da tela parou (código {codigo}).")
            if len(quedas) > 5:
                anotar(self.registro, "Parou várias vezes seguidas; desistindo.")
                self.desistiu = True
                return
            time.sleep(2)

    def parar(self):
        self.fechando = True
        if self.proc and self.proc.poll() is None:
            if os.name == "nt":  # a árvore toda: inclusive uma importação em andamento (processo filho)
                subprocess.run(["taskkill", "/T", "/F", "/PID", str(self.proc.pid)], capture_output=True,
                               creationflags=SEM_CONSOLE)
            else:
                self.proc.terminate()
            try:
                self.proc.wait(timeout=5)
            except subprocess.TimeoutExpired:
                self.proc.kill()


def atualizar_atalhos(registro):
    """Refaz os atalhos que existem com o nome e o ícone atuais (até a 0.2.7 o atalho se chamava
    "DegravaIA"; até a 0.2.9 o ícone era outro arquivo). Atalho apagado pela pessoa não volta."""
    try:
        from instalar import criar_atalhos

        feitos = criar_atalhos(so_os_existentes=True)
        anotar(registro, f"Atalhos atualizados: {len(feitos)}.")
    except Exception as erro:
        anotar(registro, f"Não foi possível atualizar os atalhos: {erro}")


def modo_navegador():
    """Como antes: janela preta + navegador padrão (abrir.py)."""
    novo_console = subprocess.CREATE_NEW_CONSOLE if os.name == "nt" else 0
    subprocess.Popen([str(python_do_app()), str(AQUI / "abrir.py"), "--navegador"], cwd=AQUI,
                     creationflags=novo_console)


def principal():
    os.chdir(AQUI)
    if "--navegador" in sys.argv:
        return modo_navegador()
    try:
        import webview
    except ImportError:
        return modo_navegador()

    registro = abrir_registro()
    anotar(registro, "=== Degrava IA aberto (janela própria)")
    if os.name == "nt":  # app próprio na barra de tarefas (senão o Windows agrupa como "Python", com o ícone dele)
        try:
            import ctypes

            ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID("RLAdev.DegravaIA")
        except Exception:
            pass
    if os.name == "nt":
        threading.Thread(target=atualizar_atalhos, args=(registro,), daemon=True).start()
    servidor = None
    if not no_ar():  # se já houver um Degrava IA aberto, esta janela usa o mesmo servidor
        servidor = Servidor(registro)
        servidor.iniciar()

    webview.settings["ALLOW_DOWNLOADS"] = True  # documentos exportados
    webview.settings["OPEN_EXTERNAL_LINKS_IN_BROWSER"] = True  # "Doar pelo Mercado Pago" abre no navegador
    from instalar import ICONE as icone
    janela = webview.create_window("Degrava IA", html=CARREGANDO, width=1400, height=900, min_size=(1000, 680),
                                   background_color="#09142c")

    bandeja = {}

    def icone_e_bandeja():
        """No Windows (pythonnet, que vem com o pywebview): o ícone na bandeja do sistema, com menu.
        O ícone da janela e da barra de tarefas o pywebview já põe (parâmetro icon do start)."""
        try:
            from System import Action
            from System.Drawing import Icon
            from System.Windows.Forms import (ContextMenuStrip, FormWindowState, MouseButtons, NotifyIcon,
                                              SystemInformation, ToolStripMenuItem)

            formulario = janela.native

            def mostrar(*_):
                formulario.Show()
                if formulario.WindowState == FormWindowState.Minimized:
                    formulario.WindowState = FormWindowState.Normal
                formulario.Activate()

            def ao_clicar(_origem, evento):
                if evento.Button == MouseButtons.Left:
                    mostrar()

            def montar():  # na linha de execução da janela, como o Windows exige
                try:
                    formulario.Icon = Icon(str(icone))
                except Exception as erro:  # o pywebview já pôs o ícone; isto só reforça
                    anotar(registro, f"Ícone da janela: {erro}")
                icone_bandeja = NotifyIcon()
                icone_bandeja.Icon = Icon(str(icone), SystemInformation.SmallIconSize)  # o tamanho da bandeja
                icone_bandeja.Text = "Degrava IA"
                menu = ContextMenuStrip()
                abrir = ToolStripMenuItem("Abrir o Degrava IA")
                abrir.Click += mostrar
                fechar = ToolStripMenuItem("Fechar o Degrava IA")
                fechar.Click += lambda *_: formulario.Close()
                menu.Items.Add(abrir)
                menu.Items.Add(fechar)
                icone_bandeja.ContextMenuStrip = menu
                icone_bandeja.MouseClick += ao_clicar
                icone_bandeja.Visible = True
                bandeja["icone"] = icone_bandeja
                anotar(registro, "Ícone na bandeja do sistema: ativo.")

            formulario.Invoke(Action(montar))
        except Exception as erro:
            anotar(registro, f"Ícone na bandeja do sistema: indisponível ({erro})")

    def tirar_da_bandeja():  # sem isto, o ícone fica "fantasma" na bandeja até passar o mouse
        icone_bandeja = bandeja.pop("icone", None)
        if icone_bandeja is not None:
            try:
                icone_bandeja.Visible = False
                icone_bandeja.Dispose()
            except Exception:
                pass

    janela.events.shown += icone_e_bandeja
    janela.events.closed += tirar_da_bandeja

    def esperar_servidor():
        limite = time.time() + 180
        while time.time() < limite:
            if no_ar():
                janela.load_url(ENDERECO)
                return
            if servidor and servidor.desistiu:
                break
            time.sleep(0.5)
        anotar(registro, "A tela não ficou pronta.")
        janela.load_html(pagina_de_erro("O programa da tela não respondeu."))

    try:
        DADOS_JANELA.mkdir(exist_ok=True)
        webview.start(esperar_servidor, gui="edgechromium" if os.name == "nt" else None, private_mode=False,
                      storage_path=str(DADOS_JANELA), icon=str(icone))
    except Exception as erro:  # sem WebView2 (raro no Windows 10/11): cai para o navegador
        anotar(registro, f"Janela própria indisponível ({erro}); abrindo no navegador.")
        if servidor:
            servidor.parar()
        registro.close()
        return modo_navegador()
    tirar_da_bandeja()
    anotar(registro, "Janela fechada.")
    if servidor:
        servidor.parar()
    registro.close()


if __name__ == "__main__":
    principal()
